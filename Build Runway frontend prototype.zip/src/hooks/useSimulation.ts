import { useDeferredValue, useMemo } from 'react'
import type { AppState, Decision, Derived, SimulationResult } from '../types/finance'
import { simulate } from '../lib/finance/simulate'
import { useDebounced } from './useDebounced'

export function useSimulation(state: AppState, decision: Decision | null, base: Derived): { result: SimulationResult | null; pending: boolean } {
  const debounced = useDebounced(decision, 120)
  const deferred = useDeferredValue(debounced)
  const result = useMemo(() => (deferred ? simulate(state, deferred, base) : null), [state, deferred, base])
  return { result, pending: decision !== deferred }
}
