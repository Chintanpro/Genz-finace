import { useEffect, useRef, useState } from 'react'
import { useReducedMotion } from './useReducedMotion'

/** Tweens a number over 400ms ease-out; instant with reduced motion. */
export function useCountUp(target: number, ms = 400): number {
  const reduced = useReducedMotion()
  const [v, setV] = useState(target)
  const from = useRef(target)
  useEffect(() => {
    if (reduced) {
      from.current = target
      setV(target)
      return
    }
    const start = performance.now()
    const a = from.current
    let raf = 0
    const step = (now: number) => {
      const t = Math.min(1, (now - start) / ms)
      const e = 1 - Math.pow(1 - t, 3)
      const cur = a + (target - a) * e
      setV(cur)
      from.current = cur
      if (t < 1) raf = requestAnimationFrame(step)
    }
    raf = requestAnimationFrame(step)
    return () => cancelAnimationFrame(raf)
  }, [target, ms, reduced])
  return v
}

/** Returns the latest change for a value, cleared after 4 seconds. */
export function useRecentDelta(value: number, ms = 4000): number {
  const prev = useRef(value)
  const [delta, setDelta] = useState(0)
  useEffect(() => {
    const d = value - prev.current
    prev.current = value
    if (Math.round(d) === 0) return
    setDelta(d)
    const t = window.setTimeout(() => setDelta(0), ms)
    return () => window.clearTimeout(t)
  }, [value, ms])
  return delta
}
