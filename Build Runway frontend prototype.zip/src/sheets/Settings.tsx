import { useEffect, useState } from 'react'
import { FastForward, ListChecks, RotateCcw } from 'lucide-react'
import { Button, RadioGroup, SwitchField, useTheme } from '@figma/astraui'
import { useStore } from '../state/store'
import { formatINR } from '../lib/finance/format'
import { FORECAST } from '../lib/finance/forecast'
import { SEED } from '../lib/finance/rng'
import { runSelfChecks } from '../lib/finance/selfChecks'
import { riskLabel } from '../components/RiskChip'
import Range from '../components/ui/Range'
import Sheet from '../components/ui/Sheet'

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <section className="flex flex-col gap-md border-b border-border-secondary pb-lg last:border-b-0">
      <span className="text-label font-semibold text-text-primary">{title}</span>
      {children}
    </section>
  )
}

export default function Settings({ open, onClose }: { open: boolean; onClose: () => void }) {
  const { state, mutate, reset, advance } = useStore()
  const { setTheme } = useTheme()
  const [reserve, setReserve] = useState(state.settings.reserve)
  const [jump, setJump] = useState(1)
  const [checks, setChecks] = useState<{ name: string; pass: boolean }[] | null>(null)
  const cd = state.settings.currentDay
  const left = state.settings.cycleDays - cd
  useEffect(() => setReserve(state.settings.reserve), [state.settings.reserve])
  useEffect(() => {
    const t = state.settings.theme
    const sys = window.matchMedia?.('(prefers-color-scheme: dark)').matches ? 'dark' : 'light'
    setTheme(t === 'system' ? sys : t)
  }, [state.settings.theme, setTheme])
  const run = () => {
    const r = runSelfChecks(state)
    r.forEach((c) => console.log(`${c.pass ? 'PASS' : 'FAIL'} ${c.name}`))
    setChecks(r)
  }
  return (
    <Sheet open={open} onClose={onClose} title="Settings" size="large" footer={<Button variant="primary" onClick={onClose}>Done</Button>}>
      <Section title="Theme">
        <RadioGroup name="theme" value={state.settings.theme} onChange={(v) => mutate((s) => void (s.settings.theme = v as 'light' | 'dark' | 'system'), 'Theme updated.')}
          options={[{ value: 'system', label: 'Match my device' }, { value: 'light', label: 'Light' }, { value: 'dark', label: 'Dark' }]} />
      </Section>
      <Section title="Safety reserve">
        <span className="flex justify-between text-label-sm text-text-secondary">Kept aside, never counted as free to spend <span className="tabular font-semibold text-text-primary">{formatINR(reserve)}</span></span>
        <Range label="Safety reserve" min={0} max={2000} step={50} value={reserve} onChange={setReserve} valueText={formatINR(reserve)} />
        <Button variant="neutral" size="small" className="self-start" disabled={reserve === state.settings.reserve} onClick={() => mutate((s) => void (s.settings.reserve = reserve), 'Reserve updated.')}>Save reserve</Button>
      </Section>
      <Section title="Forecast defaults">
        <SwitchField key={`inc-${state.incomes.map((i) => i.countInBaseline).join()}`} label="Count expected income" description="Expected money lands in simulations at its confidence."
          defaultSelected={state.incomes.some((i) => i.status === 'expected' && i.countInBaseline)}
          onChange={(on) => mutate((s) => s.incomes.forEach((i) => { if (i.status === 'expected') i.countInBaseline = on }), on ? 'Expected income counted.' : 'Expected income left out.')} />
      </Section>
      <Section title="Demo controls">
        <div className="flex flex-wrap gap-sm">
          <Button variant="neutral" size="small" iconStart={<FastForward size={16} />} disabled={cd > state.settings.cycleDays} onClick={() => advance(1)}>Next day</Button>
          <Button variant="neutral" size="small" iconStart={<RotateCcw size={16} />} onClick={reset}>Reset demo</Button>
          <Button variant="neutral" size="small" iconStart={<ListChecks size={16} />} onClick={run}>Run self-checks</Button>
        </div>
        {left > 0 && (
          <div className="flex flex-col gap-xs">
            <span className="flex justify-between text-label-sm text-text-secondary">Jump forward <span className="tabular font-semibold text-text-primary">{jump} day{jump === 1 ? '' : 's'}, to Day {Math.min(30, cd + jump)}</span></span>
            <Range label="Days to jump" min={1} max={left + 1} value={Math.min(jump, left + 1)} onChange={setJump} />
            <Button variant="neutral" size="small" className="self-start" onClick={() => advance(jump)}>Jump forward</Button>
          </div>
        )}
        {checks && (
          <ul className="flex flex-col gap-xs text-label-sm">
            {checks.map((c) => <li key={c.name} className={c.pass ? 'text-text-primary' : 'text-danger'}>{c.pass ? 'PASS' : 'FAIL'} · {c.name}</li>)}
          </ul>
        )}
      </Section>
      <Section title="Decision log">
        {state.decisionLog.length === 0 && <p className="text-label-sm text-text-secondary">No decisions committed yet.</p>}
        {[...state.decisionLog].reverse().map((e) => (
          <div key={e.id} className="flex flex-col gap-xs rounded-corner-md bg-bg-faint p-md text-label-sm">
            <span className="font-medium text-text-primary">Day {e.day} · {e.decision.kind.replace(/_/g, ' ')}</span>
            <span className="tabular text-text-secondary">
              Allowance {formatINR(e.before.dailyAllowance)} to {formatINR(e.after.dailyAllowance)} · risk {riskLabel(e.before.riskLevel)} to {riskLabel(e.after.riskLevel)} · health {e.before.healthScore} to {e.after.healthScore}
            </span>
          </div>
        ))}
      </Section>
      <Section title="About this prototype">
        <p className="text-label-sm text-text-secondary">
          Illustrative data only, no real accounts. Forecasts run {FORECAST.runs} simulated months with a fixed seed ({SEED}) so every comparison uses the same random draws.
          Daily spend is lognormal around your recent pace (sigma {FORECAST.sigma}); surprises hit with {Math.round(FORECAST.surpriseP * 1000) / 10}% chance a day, median {formatINR(FORECAST.surpriseMedian)}.
          Goal transfers are skipped when they would break your reserve, lowest priority first.
        </p>
      </Section>
    </Sheet>
  )
}
