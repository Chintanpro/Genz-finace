import { Button } from '@figma/astraui'
import { useStore } from '../state/store'
import { resultFrom, rippleLines } from '../lib/finance/simulate'
import ImpactGrid from '../components/ImpactGrid'
import Sheet from '../components/ui/Sheet'

export default function Ripple({ open, onClose }: { open: boolean; onClose: () => void }) {
  const { ripple } = useStore()
  if (!ripple) return null
  const result = resultFrom(ripple.prev, ripple.entry.decision, ripple.before, ripple.after)
  const { biggest, lines } = rippleLines(ripple.prev, ripple.next, ripple.before, ripple.after)
  return (
    <Sheet open={open} onClose={onClose} title="Here's what moved" footer={<Button variant="primary" onClick={onClose}>Done</Button>}>
      <div className="flex flex-col gap-xs rounded-corner-lg bg-bg-faint p-lg">
        <span className="text-label-sm font-semibold text-text-primary">Biggest mover</span>
        <p className="text-label-sm text-text-secondary">{biggest}</p>
      </div>
      <ImpactGrid result={result} preview={false} />
      {lines.length > 0 && (
        <div className="flex flex-col gap-sm">
          <span className="text-label-sm font-semibold text-text-primary">What else changed</span>
          <ul className="flex list-disc flex-col gap-xs pl-xl text-label-sm text-text-secondary">
            {lines.map((l) => <li key={l}>{l}</li>)}
          </ul>
        </div>
      )}
    </Sheet>
  )
}
