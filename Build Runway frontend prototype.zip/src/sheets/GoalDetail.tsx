import { useEffect, useState } from 'react'
import { Button, SwitchField, cn } from '@figma/astraui'
import type { Decision } from '../types/finance'
import { useStore } from '../state/store'
import { clampAmount, formatINR, weeksLabel } from '../lib/finance/format'
import AmountInput from '../components/AmountInput'
import DeltaChip from '../components/DeltaChip'
import Range from '../components/ui/Range'
import Sheet from '../components/ui/Sheet'

export default function GoalDetail({ goalId, onClose }: { goalId: string | null; onClose: () => void }) {
  const { state, derived, setPreview, sim, commit } = useStore()
  const goal = state.goals.find((g) => g.id === goalId)
  const status = derived.goals.find((g) => g.id === goalId)
  const [weekly, setWeekly] = useState(goal?.weekly ?? 0)
  const [paused, setPaused] = useState(goal?.paused ?? false)
  const [add, setAdd] = useState(0)
  const [mode, setMode] = useState<'plan' | 'add'>('plan')
  useEffect(() => {
    setWeekly(goal?.weekly ?? 0)
    setPaused(goal?.paused ?? false)
    setAdd(0)
    setMode('plan')
  }, [goalId]) // eslint-disable-line react-hooks/exhaustive-deps
  const decision: Decision | null = !goal ? null : mode === 'add' ? (add > 0 ? { kind: 'goal_add_money', goalId: goal.id, amount: add } : null) : { kind: 'goal_adjust', goalId: goal.id, weekly, paused }
  const key = JSON.stringify(decision)
  useEffect(() => {
    setPreview(decision)
    return () => setPreview(null)
  }, [key]) // eslint-disable-line react-hooks/exhaustive-deps
  if (!goal || !status) return null
  const after = sim?.after.goals.find((g) => g.id === goal.id)
  const cd = state.settings.currentDay
  const close = () => { setPreview(null); onClose() }
  return (
    <Sheet open onClose={close} title={goal.name}
      footer={<><Button variant="neutral" onClick={close}>Close</Button><Button variant="primary" disabled={!decision} onClick={() => decision && commit(decision)}>{mode === 'add' ? 'Add money now' : 'Update goal plan'}</Button></>}>
      <p className="tabular text-label text-text-primary">{formatINR(status.saved)} of {formatINR(status.target)} saved · ETA {weeksLabel(status.etaDay === null ? null : status.etaDay - cd)}</p>
      <div className="flex gap-sm">
        <Button variant={mode === 'plan' ? 'neutral' : 'subtle'} size="small" onClick={() => setMode('plan')} aria-pressed={mode === 'plan'}>Weekly plan</Button>
        <Button variant={mode === 'add' ? 'neutral' : 'subtle'} size="small" onClick={() => setMode('add')} aria-pressed={mode === 'add'}>Add money now</Button>
      </div>
      {mode === 'plan' ? (
        <>
          <div className="flex flex-col gap-xs">
            <span className="flex justify-between text-label-sm font-medium text-text-primary">Weekly amount <span className="tabular">{formatINR(weekly)}</span></span>
            <Range label="Weekly amount" min={0} max={500} step={10} value={weekly} onChange={(v) => setWeekly(clampAmount(v))} valueText={formatINR(weekly)} />
            <span className="text-label-sm text-text-secondary">Needed per week to hit the deadline: {formatINR(status.requiredWeekly)}</span>
          </div>
          <SwitchField key={goal.id} label="Pause this goal" description="Contributions stop until you resume." defaultSelected={goal.paused} onChange={setPaused} />
        </>
      ) : (
        <AmountInput value={add} onChange={setAdd} max={2000} quick={[100, 200, 500]} />
      )}
      {sim && decision && (
        <div className="preview-edge flex flex-wrap items-center gap-md rounded-corner-md p-md text-label-sm text-text-primary">
          <span>Daily allowance {formatINR(sim.after.dailyAllowance)}</span>
          <DeltaChip delta={sim.after.dailyAllowance - sim.before.dailyAllowance} />
          <span>ETA {after?.status === 'paused' ? 'on hold' : weeksLabel(after?.etaDay == null ? null : after.etaDay - cd)}</span>
        </div>
      )}
      <div className="flex flex-col gap-sm">
        <span className="text-label-sm font-semibold text-text-primary">This cycle's contributions</span>
        <ul className="flex flex-wrap gap-sm">
          {status.schedule.map((s) => (
            <li key={s.day} className={cn('rounded-corner-full px-md py-xs text-video-title font-medium', s.state === 'paid' ? 'bg-money-goals text-on-money' : s.state === 'skipped' ? 'bg-bg-subtle text-text-secondary line-through' : 'border border-border-primary text-text-primary')}>
              Day {s.day} · {s.state}
            </li>
          ))}
        </ul>
      </div>
    </Sheet>
  )
}
