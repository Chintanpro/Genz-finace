import { Button } from '@figma/astraui'
import type { SegmentKey } from '../types/finance'
import { useStore } from '../state/store'
import { formatINR } from '../lib/finance/format'
import { postedTx, scheduled } from '../lib/finance/ledger'
import Sheet from '../components/ui/Sheet'

const ABOUT: Record<SegmentKey, string> = {
  spent: 'Everything you have spent this cycle, including surprises and late fees.',
  paidBills: 'Bills and subscriptions already paid this cycle.',
  saved: 'Money moved into your goals this cycle.',
  locked: 'Bills, renewals and goal transfers still to come. It is spoken for.',
  reserve: 'A cushion you keep untouched so a bad week does not become a bad month.',
  free: 'What is genuinely yours to spend for the rest of the cycle.',
}

export default function SegmentExplainer({ segKey, onClose }: { segKey: string | null; onClose: () => void }) {
  const { state, derived, openTestDrive, openSheet } = useStore()
  if (!segKey) return null
  const key = segKey as SegmentKey
  const seg = derived.moneyMap.find((s) => s.key === key)
  const posted = postedTx(state)
  const items: { label: string; meta: string; amount: number }[] =
    key === 'spent' ? posted.filter((t) => ['expense', 'surprise', 'late_fee'].includes(t.kind)).sort((a, b) => b.amount - a.amount).slice(0, 8).map((t) => ({ label: t.label, meta: `Day ${t.day}`, amount: t.amount }))
    : key === 'paidBills' ? posted.filter((t) => t.kind === 'bill' || t.kind === 'subscription').map((t) => ({ label: t.label, meta: `Paid Day ${t.day}`, amount: t.amount }))
    : key === 'saved' ? posted.filter((t) => t.kind === 'goal_transfer').map((t) => ({ label: t.label, meta: `Day ${t.day}`, amount: t.amount }))
    : key === 'locked' ? scheduled(state).map((s) => ({ label: s.name, meta: `Due Day ${s.day}`, amount: s.amount }))
    : []
  return (
    <Sheet open onClose={onClose} title={seg?.label ?? 'Segment'}
      footer={
        key === 'free' || key === 'spent' ? <Button variant="primary" onClick={() => openTestDrive()}>Test drive this</Button>
        : key === 'locked' ? <Button variant="primary" onClick={() => openSheet({ kind: 'segment', key: 'free' })}>See free to spend</Button>
        : key === 'reserve' ? <Button variant="neutral" onClick={() => openSheet({ kind: 'settings' })}>Change reserve</Button>
        : <Button variant="neutral" onClick={onClose}>Close</Button>
      }>
      <span className="tabular text-numeral-l font-semibold tracking-display text-text-primary">{formatINR(seg?.amount ?? 0)}</span>
      <p className="text-label text-text-secondary">{ABOUT[key]}</p>
      {key === 'free' && <p className="text-label-sm text-text-secondary">That is {formatINR(derived.dailyAllowance)} a day for {derived.daysLeft} days.{derived.freeToSpend < 0 ? ` Right now you are short by ${formatINR(-derived.freeToSpend)}.` : ''}</p>}
      {items.length > 0 && (
        <ul className="flex flex-col">
          {items.map((it, i) => (
            <li key={`${it.label}-${i}`} className="flex items-center justify-between gap-md border-b border-border-secondary py-sm last:border-b-0">
              <span className="flex flex-col"><span className="text-label-sm text-text-primary">{it.label}</span><span className="text-video-title text-text-secondary">{it.meta}</span></span>
              <span className="tabular text-label-sm font-semibold text-text-primary">{formatINR(it.amount)}</span>
            </li>
          ))}
        </ul>
      )}
    </Sheet>
  )
}
