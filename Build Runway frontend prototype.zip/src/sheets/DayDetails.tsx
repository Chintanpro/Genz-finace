import { Button } from '@figma/astraui'
import { useStore } from '../state/store'
import { itemsOnDay } from '../state/selectors'
import { formatINR } from '../lib/finance/format'
import Sheet from '../components/ui/Sheet'

export default function DayDetails({ day, onClose }: { day: number | null; onClose: () => void }) {
  const { state, derived, openTestDrive } = useStore()
  if (day === null) return null
  const cd = state.settings.currentDay
  const due = itemsOnDay(state, day)
  const tx = state.transactions.filter((t) => t.day === day && t.day <= cd)
  const pace = derived.discretionaryPool / state.settings.cycleDays
  const spend = derived.dailySpend[day - 1] ?? 0
  return (
    <Sheet open onClose={onClose} title={day === cd ? `Today, Day ${day}` : `Day ${day}`}
      footer={day >= cd ? <Button variant="primary" onClick={() => openTestDrive({ kind: 'purchase', label: '', amount: 250, day, category: 'fun', necessity: 'want', payment: 'now' })}>Test drive a purchase on this day</Button> : <Button variant="neutral" onClick={onClose}>Close</Button>}>
      {day <= cd && (
        <p className="text-label text-text-primary">
          Spent <span className="tabular font-semibold">{formatINR(spend)}</span> against a daily pace of {formatINR(pace)}{spend > pace ? `, over by ${formatINR(spend - pace)}.` : '.'}
        </p>
      )}
      {due.length > 0 && (
        <div className="flex flex-col gap-sm">
          <span className="text-label-sm font-semibold text-text-primary">Due this day</span>
          {due.map((d) => (
            <div key={`${d.id}-${d.day}`} className="flex justify-between text-label-sm"><span className="text-text-primary">{d.name}</span><span className="tabular font-semibold text-text-primary">{formatINR(d.amount)}</span></div>
          ))}
        </div>
      )}
      {tx.length > 0 && (
        <div className="flex flex-col gap-sm">
          <span className="text-label-sm font-semibold text-text-primary">Activity</span>
          {tx.map((t) => (
            <div key={t.id} className="flex justify-between text-label-sm"><span className="text-text-primary">{t.label}</span><span className="tabular text-text-secondary">{t.kind === 'income' ? '+' : '−'}{formatINR(t.amount)}</span></div>
          ))}
        </div>
      )}
      {due.length === 0 && tx.length === 0 && <p className="text-label-sm text-text-secondary">Nothing scheduled or logged for this day.</p>}
    </Sheet>
  )
}
