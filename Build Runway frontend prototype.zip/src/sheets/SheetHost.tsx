import { useStore } from '../state/store'
import CycleWrap from './CycleWrap'
import DayDetails from './DayDetails'
import GoalDetail from './GoalDetail'
import LifeHappens from './LifeHappens'
import LogExpense from './LogExpense'
import Ripple from './Ripple'
import SegmentExplainer from './SegmentExplainer'
import Settings from './Settings'
import TxDetail from './TxDetail'

export default function SheetHost() {
  const { sheet, closeSheet } = useStore()
  const k = sheet?.kind
  return (
    <>
      <LogExpense open={k === 'log'} onClose={closeSheet} />
      <LifeHappens open={k === 'life'} onClose={closeSheet} />
      <Ripple open={k === 'ripple'} onClose={closeSheet} />
      <Settings open={k === 'settings'} onClose={closeSheet} />
      <CycleWrap open={k === 'wrap'} onClose={closeSheet} />
      <SegmentExplainer segKey={sheet?.kind === 'segment' ? sheet.key : null} onClose={closeSheet} />
      <DayDetails day={sheet?.kind === 'day' ? sheet.day : null} onClose={closeSheet} />
      <GoalDetail goalId={sheet?.kind === 'goal' ? sheet.goalId : null} onClose={closeSheet} />
      <TxDetail txId={sheet?.kind === 'tx' ? sheet.txId : null} onClose={closeSheet} />
    </>
  )
}
