import { useMemo, useState } from 'react'
import { Delete } from 'lucide-react'
import { Button, InputField } from '@figma/astraui'
import type { Category } from '../types/finance'
import { useStore } from '../state/store'
import { addExpense } from '../lib/finance/apply'
import { deriveFinancialState } from '../lib/finance/derive'
import { clampAmount, formatINR } from '../lib/finance/format'
import { categoryLabel } from '../lib/finance/insights'
import { CATEGORIES } from '../lib/finance/ledger'
import Chip from '../components/ui/Chip'
import Pressable from '../components/ui/Pressable'
import Sheet from '../components/ui/Sheet'

const KEYS = ['1', '2', '3', '4', '5', '6', '7', '8', '9', '00', '0', 'del']

export default function LogExpense({ open, onClose }: { open: boolean; onClose: () => void }) {
  const { state, derived, logExpense } = useStore()
  const [raw, setRaw] = useState('')
  const [category, setCategory] = useState<Category>('food')
  const [want, setWant] = useState(false)
  const [note, setNote] = useState('')
  const amount = clampAmount(Number(raw || 0))
  const after = useMemo(
    () => (amount > 0 ? deriveFinancialState(addExpense(state, { amount, label: note, category, necessity: want ? 'want' : 'need' }), { full: false, runs: 100 }) : null),
    [state, amount, note, category, want],
  )
  const press = (k: string) => setRaw((r) => (k === 'del' ? r.slice(0, -1) : (r + k).replace(/^0+/, '').slice(0, 5)))
  const submit = () => {
    logExpense({ amount, label: note || `${categoryLabel(category)} spend`, category, necessity: want ? 'want' : 'need' })
    setRaw('')
    setNote('')
    onClose()
  }
  const left = after?.leftToday ?? derived.leftToday
  return (
    <Sheet open={open} onClose={onClose} title="Log expense"
      footer={<><Button variant="neutral" onClick={onClose}>Cancel</Button><Button variant="primary" disabled={amount <= 0} onClick={submit}>Log expense</Button></>}>
      <div className="flex flex-col items-center gap-xs rounded-corner-lg bg-bg-faint p-xl" aria-live="polite">
        <span className="tabular text-numeral-l font-semibold tracking-display text-text-primary">{formatINR(amount)}</span>
        <span className="text-label-sm text-text-secondary">
          {amount > 0 ? (left < 0 ? `Over today by ${formatINR(-left)}` : `Leaves ${formatINR(left)} today`) : 'Today only'}
          {after && ` · new allowance ${formatINR(after.dailyAllowance)} a day`}
        </span>
      </div>
      <div className="grid grid-cols-3 gap-sm" role="group" aria-label="Amount keypad">
        {KEYS.map((k) => (
          <Pressable key={k} onClick={() => press(k)} aria-label={k === 'del' ? 'Delete digit' : k} className="flex h-12 items-center justify-center rounded-corner-md bg-bg-subtle text-heading font-medium text-text-primary hover:bg-bg-hover">
            {k === 'del' ? <Delete size={20} aria-hidden /> : k}
          </Pressable>
        ))}
      </div>
      <div className="flex flex-wrap gap-sm" role="group" aria-label="Category">
        {CATEGORIES.map((c) => <Chip key={c} selected={category === c} onClick={() => setCategory(c)}>{categoryLabel(c)}</Chip>)}
      </div>
      <div className="flex gap-sm" role="group" aria-label="Need or want">
        <Chip selected={!want} onClick={() => setWant(false)}>Need</Chip>
        <Chip selected={want} onClick={() => setWant(true)}>Want</Chip>
      </div>
      <InputField label="Note" placeholder="Optional, like canteen lunch" value={note} onChange={setNote} />
    </Sheet>
  )
}
