import { useMemo, useState } from 'react'
import { Zap } from 'lucide-react'
import { Button } from '@figma/astraui'
import type { Decision } from '../types/finance'
import { useStore } from '../state/store'
import { absorbPlaybook } from '../lib/finance/alternatives'
import { formatINR, formatPct } from '../lib/finance/format'
import { mulberry32, SEED } from '../lib/finance/rng'
import { simulate } from '../lib/finance/simulate'
import { SURPRISES } from '../screens/DecisionForm'
import RiskChip from '../components/RiskChip'
import Sheet from '../components/ui/Sheet'

export default function LifeHappens({ open, onClose }: { open: boolean; onClose: () => void }) {
  const { state, derived, commit } = useStore()
  const [shock, setShock] = useState<Decision & { kind: 'surprise' } | null>(null)
  const cd = state.settings.currentDay
  const surpriseMe = () => {
    const rand = mulberry32(SEED + cd * 31 + state.decisionLog.length * 7 + (shock ? 1 : 0))
    const pick = SURPRISES[Math.floor(rand() * SURPRISES.length)]
    setShock({ kind: 'surprise', label: pick.label, amount: pick.amount, day: cd })
  }
  const options = useMemo(
    () => (shock ? absorbPlaybook(state, shock).map((o) => ({ ...o, result: simulate(state, o.decision, derived, false) })) : []),
    [shock, state, derived],
  )
  return (
    <Sheet open={open} onClose={() => { setShock(null); onClose() }} title="Life happens" size="large"
      footer={<Button variant={shock ? 'neutral' : 'primary'} iconStart={<Zap size={16} />} onClick={surpriseMe}>{shock ? 'Try another' : 'Surprise me'}</Button>}>
      {!shock && <p className="text-label text-text-secondary">See how a surprise would land and pick how to absorb it. Nothing changes until you apply an option.</p>}
      {shock && (
        <>
          <div className="preview-edge flex flex-col gap-xs rounded-corner-lg p-xl">
            <span className="text-label-sm text-text-secondary">Plot twist</span>
            <span className="text-title font-semibold tracking-display text-text-primary">{shock.label}, {formatINR(shock.amount)} today</span>
          </div>
          <ol className="flex flex-col gap-md">
            {options.map((o, i) => {
              const slips = o.result.goalSlips.filter((s) => s.days > 0).length
              return (
                <li key={o.label} className="flex flex-col gap-md rounded-corner-lg bg-bg-faint p-lg">
                  <div className="flex items-start justify-between gap-md">
                    <div className="flex flex-col gap-xs">
                      <span className="text-label font-semibold text-text-primary">{i + 1}. {o.label}</span>
                      <span className="text-label-sm text-text-secondary">{o.detail}</span>
                    </div>
                    <RiskChip level={o.result.after.risk.level} />
                  </div>
                  <div className="flex flex-wrap items-center justify-between gap-md">
                    <span className="tabular text-label-sm text-text-secondary">
                      {formatINR(o.result.after.dailyAllowance)} a day · {formatPct(o.result.after.forecast.pBelowZero)} chance of running out · {slips ? `${slips} goal${slips === 1 ? '' : 's'} slip` : 'no goal slips'}
                    </span>
                    <Button variant="neutral" size="small" onClick={() => { commit(o.decision); setShock(null) }}>Apply this</Button>
                  </div>
                </li>
              )
            })}
          </ol>
        </>
      )}
    </Sheet>
  )
}
