import { Button } from '@figma/astraui'
import { useStore } from '../state/store'
import { formatINR } from '../lib/finance/format'
import { APP_NAME } from '../lib/finance/seed'
import HealthRing from '../components/HealthRing'
import Sheet from '../components/ui/Sheet'

export default function CycleWrap({ open, onClose }: { open: boolean; onClose: () => void }) {
  const { state, derived, reset } = useStore()
  const log = state.decisionLog
  const lessons = [...log]
    .sort((a, b) => Math.abs(b.after.healthScore - b.before.healthScore) - Math.abs(a.after.healthScore - a.before.healthScore))
    .slice(0, 3)
    .map((e) => `${e.decision.kind.replace('_', ' ')} on Day ${e.day} moved health by ${e.after.healthScore - e.before.healthScore} points.`)
  const first = log[0]?.before.healthScore
  return (
    <Sheet open={open} onClose={onClose} title="Cycle complete" footer={<><Button variant="neutral" onClick={onClose}>Close</Button><Button variant="primary" onClick={() => { reset(); onClose() }}>Start the demo again</Button></>}>
      <div className="flex items-center gap-lg rounded-corner-lg bg-money-free p-xl text-on-money">
        <HealthRing score={derived.health.score} size="md" />
        <div className="flex flex-col gap-xs">
          <span className="text-label-sm">{APP_NAME} · 30 days</span>
          <span className="tabular text-title font-semibold tracking-display">Finished with {formatINR(derived.wallet)}</span>
          <span className="text-label-sm">Health {first !== undefined ? `${first} to ` : ''}{derived.health.score}, {derived.health.band}</span>
        </div>
      </div>
      <ul className="flex flex-col gap-xs">
        {derived.goals.map((g) => <li key={g.id} className="tabular flex justify-between text-label-sm text-text-primary"><span>{g.name}</span><span>{formatINR(g.saved)} of {formatINR(g.target)}</span></li>)}
      </ul>
      <div className="flex flex-col gap-xs">
        <span className="text-label-sm font-semibold text-text-primary">Lessons from your decisions</span>
        {lessons.length ? lessons.map((l) => <p key={l} className="text-label-sm text-text-secondary">{l}</p>) : <p className="text-label-sm text-text-secondary">No decisions logged this cycle. Next time, test drive one before you spend.</p>}
      </div>
    </Sheet>
  )
}
