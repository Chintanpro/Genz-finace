import { useEffect, useState } from 'react'
import { Button, InputField } from '@figma/astraui'
import { useStore } from '../state/store'
import { formatINR } from '../lib/finance/format'
import AmountInput from '../components/AmountInput'
import Sheet from '../components/ui/Sheet'

export default function TxDetail({ txId, onClose }: { txId: string | null; onClose: () => void }) {
  const { state, updateTx, deleteTx } = useStore()
  const tx = state.transactions.find((t) => t.id === txId)
  const [label, setLabel] = useState(tx?.label ?? '')
  const [amount, setAmount] = useState(tx?.amount ?? 0)
  useEffect(() => { setLabel(tx?.label ?? ''); setAmount(tx?.amount ?? 0) }, [txId]) // eslint-disable-line react-hooks/exhaustive-deps
  if (!tx) return null
  const editable = tx.kind === 'expense' || tx.kind === 'surprise'
  return (
    <Sheet open onClose={onClose} title={tx.label}
      footer={<>
        <Button variant="neutral" onClick={() => { deleteTx(tx.id); onClose() }}>Delete</Button>
        {editable && <Button variant="primary" disabled={amount <= 0} onClick={() => { updateTx({ ...tx, label, amount }); onClose() }}>Save changes</Button>}
      </>}>
      <p className="text-label-sm text-text-secondary">Day {tx.day} · {formatINR(tx.amount)}{tx.auto ? ' · posted automatically' : ''}. Deleting recomputes everything.</p>
      {editable && (
        <>
          <InputField label="Label" value={label} onChange={setLabel} />
          <AmountInput value={amount} onChange={setAmount} />
        </>
      )}
    </Sheet>
  )
}
