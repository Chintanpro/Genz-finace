import { createContext, useCallback, useContext, useEffect, useMemo, useReducer, useRef, useState, type ReactNode } from 'react'
import type { AppState, Decision, Derived, LogEntry, SimulationResult, Transaction } from '../types/finance'
import { addExpense, applyDecision, newId } from '../lib/finance/apply'
import { deriveFinancialState } from '../lib/finance/derive'
import { createSeedState } from '../lib/finance/seed'
import { snapshotOf } from '../lib/finance/simulate'
import { advanceDay } from '../lib/finance/timeMachine'
import { useSimulation } from '../hooks/useSimulation'
import { loadState, saveState } from './persist'
import { reducer } from './reducer'

export type TabId = 'today' | 'money' | 'drive' | 'goals' | 'health'
export type Sheet =
  | { kind: 'log' }
  | { kind: 'life' }
  | { kind: 'ripple' }
  | { kind: 'segment'; key: string }
  | { kind: 'day'; day: number }
  | { kind: 'settings' }
  | { kind: 'goal'; goalId: string }
  | { kind: 'tx'; txId: string }
  | { kind: 'wrap' }
  | null

export interface ToastItem {
  id: string
  message: string
  undo?: AppState
  tone?: 'default' | 'warning'
}

export interface Ripple {
  entry: LogEntry
  before: Derived
  after: Derived
  prev: AppState
  next: AppState
}

const VERBS: Record<Decision['kind'], string> = {
  purchase: 'Purchase logged.',
  subscription_add: 'Subscription added.',
  subscription_cancel: 'Subscription cancelled.',
  goal_adjust: 'Goal plan updated.',
  surprise: 'Surprise expense added.',
  income: 'Income added.',
  lifestyle_cut: 'Spending cut applied.',
  goal_withdraw: 'Money moved from goal.',
  goal_add_money: 'Money added to goal.',
  commitment_defer: 'Bill moved.',
  combo: 'Plan applied.',
}

interface Store {
  state: AppState
  derived: Derived
  tab: TabId
  setTab: (t: TabId) => void
  dots: Set<TabId>
  preview: Decision | null
  setPreview: (d: Decision | null) => void
  sim: SimulationResult | null
  simPending: boolean
  commit: (d: Decision) => void
  logExpense: (tx: Omit<Transaction, 'id' | 'kind' | 'day'>) => void
  updateTx: (tx: Transaction) => void
  deleteTx: (id: string) => void
  mutate: (fn: (s: AppState) => void, message: string) => void
  reset: () => void
  advance: (days: number) => void
  undo: (toastId: string) => void
  sheet: Sheet
  openSheet: (s: Sheet) => void
  closeSheet: () => void
  openTestDrive: (preset?: Decision) => void
  tdPreset: { decision: Decision; nonce: number } | null
  ripple: Ripple | null
  toasts: ToastItem[]
  dismissToast: (id: string) => void
  cycleComplete: boolean
}

const Ctx = createContext<Store | null>(null)

function changedTabs(a: Derived, b: Derived, sa: AppState, sb: AppState): TabId[] {
  const out: TabId[] = []
  if (Math.round(a.leftToday) !== Math.round(b.leftToday) || a.freeToSpend !== b.freeToSpend) out.push('today')
  if (sa.transactions.length !== sb.transactions.length || JSON.stringify(sa.subscriptions) !== JSON.stringify(sb.subscriptions) || JSON.stringify(sa.incomes) !== JSON.stringify(sb.incomes) || JSON.stringify(sa.commitments) !== JSON.stringify(sb.commitments)) out.push('money')
  if (JSON.stringify(a.goals) !== JSON.stringify(b.goals)) out.push('goals')
  if (a.health.score !== b.health.score || a.risk.level !== b.risk.level) out.push('health')
  return out
}

export function StoreProvider({ children }: { children: ReactNode }) {
  const [state, dispatch] = useReducer(reducer, undefined, loadState)
  const derived = useMemo(() => deriveFinancialState(state), [state])
  const [tab, setTabRaw] = useState<TabId>('today')
  const [dots, setDots] = useState<Set<TabId>>(new Set())
  const [preview, setPreview] = useState<Decision | null>(null)
  const [sheet, setSheet] = useState<Sheet>(null)
  const [tdPreset, setTdPreset] = useState<Store['tdPreset']>(null)
  const [ripple, setRipple] = useState<Ripple | null>(null)
  const [toasts, setToasts] = useState<ToastItem[]>([])
  const [cycleComplete, setCycleComplete] = useState(false)
  const { result: sim, pending: simPending } = useSimulation(state, preview, derived)
  const stateRef = useRef(state)
  stateRef.current = state
  const derivedRef = useRef(derived)
  derivedRef.current = derived

  useEffect(() => saveState(state), [state])

  const setTab = useCallback((t: TabId) => {
    setTabRaw(t)
    setDots((d) => {
      if (!d.has(t)) return d
      const n = new Set(d)
      n.delete(t)
      return n
    })
    if (t !== 'drive') setPreview(null)
  }, [])

  const toast = useCallback((message: string, undo?: AppState, tone?: ToastItem['tone']) => {
    const id = newId('toast')
    setToasts((t) => [...t.slice(-2), { id, message, undo, tone }])
    window.setTimeout(() => setToasts((t) => t.filter((x) => x.id !== id)), undo ? 10000 : 5000)
  }, [])

  const apply = useCallback(
    (next: AppState, message: string, entry?: LogEntry, showRipple?: { before: Derived; after: Derived }) => {
      const prev = stateRef.current
      const before = derivedRef.current
      const after = showRipple?.after ?? deriveFinancialState(next)
      dispatch({ type: 'commit', next, entry })
      const changed = changedTabs(before, after, prev, next)
      setDots((d) => new Set([...d, ...changed.filter((c) => c !== tab)]))
      toast(message, prev)
    },
    [tab, toast],
  )

  const commit = useCallback(
    (d: Decision) => {
      const prev = stateRef.current
      const before = derivedRef.current
      const next = applyDecision(prev, d)
      const after = deriveFinancialState(next)
      const entry: LogEntry = { id: newId('log'), decision: d, day: prev.settings.currentDay, before: snapshotOf(before), after: snapshotOf(after) }
      apply(next, VERBS[d.kind], entry, { before, after })
      setPreview(null)
      setRipple({ entry, before, after, prev, next })
      setSheet({ kind: 'ripple' })
    },
    [apply],
  )

  const mutate = useCallback(
    (fn: (s: AppState) => void, message: string) => {
      const next = structuredClone(stateRef.current)
      fn(next)
      apply(next, message)
    },
    [apply],
  )

  const logExpense: Store['logExpense'] = useCallback(
    (tx) => apply(addExpense(stateRef.current, { amount: tx.amount, label: tx.label, category: tx.category ?? 'other', necessity: tx.necessity ?? 'need' }), 'Expense logged.'),
    [apply],
  )
  const updateTx = useCallback((tx: Transaction) => mutate((s) => void (s.transactions = s.transactions.map((t) => (t.id === tx.id ? tx : t))), 'Entry updated.'), [mutate])
  const deleteTx = useCallback((id: string) => mutate((s) => void (s.transactions = s.transactions.filter((t) => t.id !== id)), 'Entry deleted.'), [mutate])

  const undo = useCallback((toastId: string) => {
    setToasts((ts) => {
      const t = ts.find((x) => x.id === toastId)
      if (t?.undo) dispatch({ type: 'replace', state: t.undo })
      return ts.filter((x) => x.id !== toastId)
    })
    setSheet((s) => (s?.kind === 'ripple' ? null : s))
  }, [])

  const reset = useCallback(() => {
    dispatch({ type: 'replace', state: createSeedState() })
    setPreview(null)
    setDots(new Set())
    setCycleComplete(false)
    toast('Demo reset to Day 12.')
  }, [toast])

  const advance = useCallback(
    (days: number) => {
      let s = stateRef.current
      const events: string[] = []
      let done = false
      for (let i = 0; i < days && !done; i++) {
        const r = advanceDay(s)
        s = r.state
        events.push(...r.events)
        done = r.cycleComplete
      }
      dispatch({ type: 'replace', state: s })
      setDots(new Set<TabId>(['today', 'money', 'goals', 'health']))
      events.slice(-3).forEach((e) => toast(e, undefined, 'warning'))
      if (done) {
        setCycleComplete(true)
        setSheet({ kind: 'wrap' })
      } else toast(`Moved to Day ${s.settings.currentDay}.`)
    },
    [toast],
  )

  const openTestDrive = useCallback(
    (preset?: Decision) => {
      setSheet(null)
      if (preset) setTdPreset({ decision: preset, nonce: Date.now() })
      setTab('drive')
    },
    [setTab],
  )

  const value: Store = {
    state, derived, tab, setTab, dots, preview, setPreview, sim, simPending, commit, logExpense, updateTx, deleteTx, mutate,
    reset, advance, undo, sheet, openSheet: setSheet, closeSheet: () => setSheet(null), openTestDrive, tdPreset, ripple,
    toasts, dismissToast: (id) => setToasts((t) => t.filter((x) => x.id !== id)), cycleComplete,
  }
  return <Ctx.Provider value={value}>{children}</Ctx.Provider>
}

export function useStore(): Store {
  const s = useContext(Ctx)
  if (!s) throw new Error('useStore outside StoreProvider')
  return s
}
