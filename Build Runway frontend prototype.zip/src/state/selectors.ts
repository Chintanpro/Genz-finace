import type { AppState, Decision, Derived } from '../types/finance'
import { scheduled, type ScheduledItem } from '../lib/finance/ledger'

export interface DayCell {
  day: number
  state: 'past' | 'today' | 'future' | 'next'
  spend: number
  fill: number
  over: boolean
  bills: boolean
  subs: boolean
  goals: boolean
  trial: boolean
  income: boolean
  preview: boolean
}

export const previewDay = (d: Decision | null, cd: number): number | null => {
  if (!d) return null
  if (d.kind === 'purchase' || d.kind === 'surprise' || d.kind === 'income') return d.day
  if (d.kind === 'subscription_add') return d.startDay + d.trialDays
  if (d.kind === 'combo') return previewDay(d.parts[0] ?? null, cd)
  return cd
}

export function monthCells(state: AppState, derived: Derived, preview: Decision | null): DayCell[] {
  const { currentDay: cd, cycleDays } = state.settings
  const items = scheduled(state)
  const pace = derived.discretionaryPool / cycleDays
  const pd = previewDay(preview, cd)
  return Array.from({ length: cycleDays }, (_, i) => {
    const day = i + 1
    const at = items.filter((x) => x.day === day)
    const spend = derived.dailySpend[i] ?? 0
    const ratio = pace > 0 ? spend / pace : 0
    return {
      day,
      state: day < cd ? 'past' : day === cd ? 'today' : 'future',
      spend,
      fill: Math.min(1.5, ratio) / 1.5,
      over: ratio > 1,
      bills: at.some((x) => x.type === 'bill'),
      subs: at.some((x) => x.type === 'subscription' && !x.trial),
      goals: at.some((x) => x.type === 'goal'),
      trial: at.some((x) => x.type === 'subscription' && x.trial),
      income: state.incomes.some((inc) => inc.status === 'expected' && inc.day === day),
      preview: pd === day,
    }
  })
}

export function comingUp(state: AppState, horizon = 7): ScheduledItem[] {
  const cd = state.settings.currentDay
  return scheduled(state).filter((x) => x.day >= cd && x.day < cd + horizon)
}

export function itemsOnDay(state: AppState, day: number): ScheduledItem[] {
  return scheduled(state).filter((x) => x.day === day)
}
