import type { AppState } from '../types/finance'
import { createSeedState } from '../lib/finance/seed'

const KEY = 'runway:v1'
let memory: string | null = null

export function loadState(): AppState {
  try {
    const raw = window.localStorage.getItem(KEY) ?? memory
    if (raw) {
      const parsed = JSON.parse(raw) as AppState
      if (parsed?.settings && Array.isArray(parsed.transactions)) return { ...parsed, cuts: parsed.cuts ?? [] }
    }
  } catch {
    /* fall through to seed */
  }
  return createSeedState()
}

export function saveState(state: AppState): void {
  const raw = JSON.stringify(state)
  memory = raw
  try {
    window.localStorage.setItem(KEY, raw)
  } catch {
    /* in-memory fallback already set */
  }
}
