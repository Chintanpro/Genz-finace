import type { AppState, LogEntry } from '../types/finance'

export type Action = { type: 'replace'; state: AppState } | { type: 'commit'; next: AppState; entry?: LogEntry }

export function reducer(state: AppState, action: Action): AppState {
  switch (action.type) {
    case 'replace':
      return action.state
    case 'commit':
      return action.entry ? { ...action.next, decisionLog: [...state.decisionLog, action.entry] } : action.next
  }
}
