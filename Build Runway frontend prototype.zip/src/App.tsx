import { ThemeProvider } from '@figma/astraui'
import { StoreProvider, useStore } from './state/store'
import AppHeader from './components/AppHeader'
import ImpactPanel from './components/ImpactPanel'
import ImpactRibbon from './components/ImpactRibbon'
import TabBar, { Rail } from './components/TabBar'
import ToastHost from './components/ToastHost'
import Goals from './screens/Goals'
import Health from './screens/Health'
import Money from './screens/Money'
import TestDrive from './screens/TestDrive'
import Today from './screens/Today'
import SheetHost from './sheets/SheetHost'

function Shell() {
  const { tab, setTab, dots, state, derived, sim, preview, openSheet, toasts, undo, dismissToast } = useStore()
  const live = preview ? sim : null
  return (
    <div className="flex min-h-screen w-full overflow-x-clip bg-brand-tertiary">
      <Rail tab={tab} dots={dots} onTab={setTab} onSettings={() => openSheet({ kind: 'settings' })} />
      <div className="flex min-w-0 flex-1 justify-center gap-2xl">
        <div className="flex w-full min-w-0 max-w-main flex-col">
          <AppHeader day={state.settings.currentDay} cycleDays={state.settings.cycleDays} onSettings={() => openSheet({ kind: 'settings' })} />
          <ImpactRibbon derived={derived} after={live?.after} />
          <main className="flex-1 px-xl pt-lg pb-28 lg:px-2xl lg:pb-2xl">
            {tab === 'today' && <Today />}
            {tab === 'money' && <Money />}
            {tab === 'drive' && <TestDrive />}
            {tab === 'goals' && <Goals />}
            {tab === 'health' && <Health />}
          </main>
        </div>
        <ImpactPanel derived={derived} sim={live} onHealth={() => setTab('health')} />
      </div>
      <TabBar tab={tab} dots={dots} onTab={setTab} />
      <SheetHost />
      <ToastHost toasts={toasts} onUndo={undo} onDismiss={dismissToast} />
    </div>
  )
}

export default function App() {
  return (
    <ThemeProvider>
      <StoreProvider>
        <Shell />
      </StoreProvider>
    </ThemeProvider>
  )
}
