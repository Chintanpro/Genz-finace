import type { AppState, GoalStatus } from '../../types/finance'
import { goalSaved } from './ledger'
import { GOAL_DAYS } from './seed'

const HORIZON_CYCLES = 24

export function goalStatuses(state: AppState, paid: Map<string, boolean>): GoalStatus[] {
  const { currentDay: cd, cycleDays } = state.settings
  return [...state.goals]
    .sort((a, b) => a.priority - b.priority)
    .map((g) => {
      const saved = goalSaved(state, g.id, g.savedBeforeCycle)
      const requiredWeekly = Math.max(0, g.target - saved) / Math.max(1, (g.deadlineDay - cd) / 7)
      const schedule: GoalStatus['schedule'] = GOAL_DAYS.filter((d) => d <= cycleDays).map((d) => {
        const posted = state.transactions.some((t) => t.kind === 'goal_transfer' && t.sourceId === g.id && t.day === d && t.auto)
        if (posted) return { day: d, state: 'paid' }
        if (d < cd || g.paused || g.weekly <= 0) return { day: d, state: 'skipped' }
        return { day: d, state: paid.get(`${g.id}:${d}`) === false ? 'skipped' : 'scheduled' }
      })
      let etaDay: number | null = null
      let s = saved
      if (s >= g.target) etaDay = cd
      else if (!g.paused && g.weekly > 0) {
        for (const item of schedule)
          if (item.state === 'scheduled' && item.day >= cd) {
            s += g.weekly
            if (s >= g.target) {
              etaDay = item.day
              break
            }
          }
        for (let c = 1; etaDay === null && c <= HORIZON_CYCLES; c++)
          for (const d of GOAL_DAYS) {
            s += g.weekly
            if (s >= g.target) {
              etaDay = c * cycleDays + d
              break
            }
          }
      }
      const status: GoalStatus['status'] =
        saved >= g.target ? 'done' : g.paused ? 'paused' : g.weekly >= requiredWeekly ? 'on_track' : g.weekly >= 0.6 * requiredWeekly ? 'behind' : 'off_track'
      return { id: g.id, name: g.name, saved, target: g.target, weekly: g.weekly, requiredWeekly: Math.round(requiredWeekly), status, etaDay, schedule }
    })
}

/** Slip in days; a goal that loses its date counts as a 999-day slip. */
export function slipDays(before: number | null, after: number | null): number {
  if (before === after) return 0
  if (after === null) return 999
  if (before === null) return -999
  return after - before
}
