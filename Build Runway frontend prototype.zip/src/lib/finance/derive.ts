import type { AppState, Category, Derived, Segment } from '../../types/finance'
import { expectedGoalPayments, maxAbsorbable, runForecast, type ForecastInput } from './forecast'
import { goalStatuses } from './goals'
import { computeHealth } from './health'
import { buildInsights } from './insights'
import { CATEGORIES, riskLevelOf, dailySpend, expectedDailyOf, postedTx, safeDiv, scheduled, sum, walletOf } from './ledger'

export interface DeriveOptions {
  full?: boolean
  runs?: number
}

export function deriveFinancialState(state: AppState, opts: DeriveOptions = { full: true }): Derived {
  const { currentDay: cd, cycleDays, budget, reserve, categorySplit } = state.settings
  const posted = postedTx(state)
  const wallet = walletOf(state)
  const spentToday = sum(posted.filter((t) => t.kind === 'expense' && t.day === cd).map((t) => t.amount))
  const daysLeft = Math.max(1, cycleDays - cd + 1)
  const sched = scheduled(state)
  const by = (type: string) => sum(sched.filter((s) => s.type === type).map((s) => s.amount))
  const locked = { commitments: by('bill'), subscriptions: by('subscription'), goals: by('goal'), planned: by('planned'), total: 0 }
  locked.total = locked.commitments + locked.subscriptions + locked.goals + locked.planned
  const freeToSpend = wallet - locked.total - reserve
  const dailyAllowance = Math.max(0, freeToSpend) / daysLeft
  const dayStartAllowance = Math.max(0, freeToSpend + spentToday) / daysLeft
  const leftToday = dayStartAllowance - spentToday

  const kindSum = (kinds: string[]) => sum(posted.filter((t) => kinds.includes(t.kind)).map((t) => t.amount))
  const withdrawals = sum(posted.filter((t) => t.kind === 'income' && state.goals.some((g) => g.id === t.sourceId)).map((t) => t.amount))
  const savedNet = kindSum(['goal_transfer']) - withdrawals
  const moneyMap: Segment[] = [
    { key: 'spent', label: 'Spent', amount: kindSum(['expense', 'surprise', 'late_fee']) },
    { key: 'paidBills', label: 'Paid bills', amount: kindSum(['bill', 'subscription']) },
    { key: 'saved', label: 'Saved to goals', amount: savedNet },
    { key: 'locked', label: 'Locked in ahead', amount: locked.total },
    { key: 'reserve', label: 'Safety reserve', amount: Math.min(reserve, Math.max(0, wallet - locked.total)) },
    { key: 'free', label: 'Free to spend', amount: Math.max(0, freeToSpend) },
  ]
  const moneyTotal = kindSum(['income']) - withdrawals

  const expectedDaily = expectedDailyOf(state)
  const commitmentTotal = sum(state.commitments.map((c) => c.amount))
  const subscriptionTotal = kindSum(['subscription']) + locked.subscriptions
  const goalScheduledTotal = kindSum(['goal_transfer']) + locked.goals
  const discretionaryPool = Math.max(0, budget - commitmentTotal - subscriptionTotal - goalScheduledTotal - reserve)
  const categoryPace = {} as Derived['categoryPace']
  for (const c of CATEGORIES) {
    const b = discretionaryPool * (categorySplit[c] ?? 0)
    categoryPace[c as Category] = {
      budget: Math.round(b),
      pace: Math.round(safeDiv(b * cd, cycleDays)),
      spent: sum(posted.filter((t) => t.kind === 'expense' && t.category === c).map((t) => t.amount)),
    }
  }

  const habitToday = sum(posted.filter((t) => t.kind === 'expense' && t.day === cd && !t.oneOff).map((t) => t.amount))
  const fin: ForecastInput = { state, wallet, expectedDaily, spentToday: habitToday }
  const forecast = runForecast(fin, opts.runs)
  const level = riskLevelOf(forecast.pBelowZero, wallet)
  const risk = { level, index: Math.min(100, Math.round(forecast.pBelowZero * 200)) }
  const goals = goalStatuses(state, expectedGoalPayments(fin))
  const ds = dailySpend(state)
  const health = computeHealth({
    state, wallet, lockedTotal: locked.total, expectedDaily, daysLeft, discretionaryPool, riskIndex: risk.index, dailySpend: ds,
    commitmentTotal, subscriptionTotal, goalScheduledTotal,
    requiredWeekly: Object.fromEntries(goals.map((g) => [g.id, g.requiredWeekly])),
  })

  const derived: Derived = {
    wallet, spentToday, daysLeft, dayStartAllowance, dailyAllowance, leftToday, locked, reserve, freeToSpend,
    moneyMap, moneyTotal, expectedDaily, discretionaryPool, categoryPace, forecast, risk, goals,
    health: { score: health.score, band: health.band, parts: health.parts },
    maxAbsorbable: opts.full ? maxAbsorbable(fin) : 0,
    insights: [],
    wantsShare: health.wantsShare,
    subscriptionCycleTotal: subscriptionTotal,
    commitmentCycleTotal: commitmentTotal,
    dailySpend: ds,
  }
  if (opts.full) derived.insights = buildInsights(state, derived)
  if (import.meta.env?.DEV && freeToSpend >= 0) {
    const total = sum(moneyMap.map((s) => s.amount))
    console.assert(total === moneyTotal, `Money Map ${total} != ${moneyTotal}`)
  }
  return derived
}
