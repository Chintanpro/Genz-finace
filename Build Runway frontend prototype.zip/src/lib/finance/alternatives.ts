import type { Alternative, AppState, Decision, Derived } from '../../types/finance'
import { applyDecision } from './apply'
import { deriveFinancialState } from './derive'
import { goalSaved } from './ledger'
import { verdictOf } from './simulate'

const USAGE_RANK = { low: 0, medium: 1, high: 2 }

export function lowestUsageSub(state: AppState) {
  return [...state.subscriptions]
    .filter((s) => s.status === 'active' || s.status === 'trial')
    .sort((a, b) => USAGE_RANK[a.usage] - USAGE_RANK[b.usage] || b.amount - a.amount)[0]
}

/** Absorb playbook for a surprise expense (used by Test drive and Life happens). */
export function absorbPlaybook(state: AppState, surprise: Decision & { kind: 'surprise' }): { label: string; detail: string; decision: Decision }[] {
  const goalsLowFirst = [...state.goals].filter((g) => !g.paused).sort((a, b) => b.priority - a.priority)
  const flex = state.commitments.find((c) => c.flexible && c.status === 'upcoming')
  const opts: { label: string; detail: string; decision: Decision }[] = [
    { label: 'Use the reserve only', detail: 'Keep every plan as is and let the safety reserve take the hit.', decision: surprise },
  ]
  if (goalsLowFirst.length) {
    const pause = goalsLowFirst.slice(0, 2)
    opts.push({
      label: `Pause ${pause.map((g) => g.name).join(' and ')}`,
      detail: 'Goal contributions stop from the lowest priority up, until you resume them.',
      decision: { kind: 'combo', label: 'Pause low-priority goals', parts: [surprise, ...pause.map((g): Decision => ({ kind: 'goal_adjust', goalId: g.id, weekly: g.weekly, paused: true }))] },
    })
  }
  opts.push({
    label: 'Trim wants 30% for 7 days',
    detail: 'Fewer deliveries and outings for a week.',
    decision: { kind: 'combo', label: 'Trim wants', parts: [surprise, { kind: 'lifestyle_cut', category: 'wants', percent: 30, days: 7 }] },
  })
  if (flex)
    opts.push({
      label: `Push ${flex.name} back 5 days`,
      detail: 'It is marked flexible, so moving it should not add a late fee.',
      decision: { kind: 'combo', label: 'Defer a flexible bill', parts: [surprise, { kind: 'commitment_defer', commitmentId: flex.id, days: 5 }] },
    })
  return opts
}

function candidates(state: AppState, d: Decision, before: Derived): { label: string; decision: Decision }[] {
  const cd = state.settings.currentDay
  const out: { label: string; decision: Decision }[] = []
  if (d.kind === 'purchase' && d.day <= state.settings.cycleDays) {
    let waitDay = 31
    const quickBefore = deriveFinancialState(state, { full: false, runs: 150 })
    for (let day = Math.max(cd, d.day) + 1; day <= state.settings.cycleDays; day += 2) {
      const a = deriveFinancialState(applyDecision(state, { ...d, day }), { full: false, runs: 150 })
      if (verdictOf(quickBefore, a).level === 'go') {
        waitDay = day
        break
      }
    }
    out.push({ label: waitDay > 30 ? 'Wait until next cycle' : `Wait until Day ${waitDay}`, decision: { ...d, day: waitDay } })
    out.push({ label: 'Trim it to 70% of the price', decision: { ...d, amount: Math.round(d.amount * 0.7) } })
    const words = d.label.toLowerCase().split(/\W+/).filter((w) => w.length > 2)
    const goal = state.goals.find((g) => words.some((w) => g.name.toLowerCase().includes(w)))
    if (goal) {
      const part = Math.min(Math.round(d.amount / 2), goalSaved(state, goal.id, goal.savedBeforeCycle))
      if (part > 0) out.push({ label: `Fund part from ${goal.name}`, decision: { kind: 'combo', label: d.label, parts: [d, { kind: 'goal_withdraw', goalId: goal.id, amount: part }] } })
    }
    const sub = lowestUsageSub(state)
    if (sub)
      out.push({
        label: `Offset: cancel ${sub.name.split(',')[0]} and trim wants 20%`,
        decision: { kind: 'combo', label: d.label, parts: [d, { kind: 'subscription_cancel', subId: sub.id }, { kind: 'lifestyle_cut', category: 'wants', percent: 20 }] },
      })
  }
  if (d.kind === 'subscription_add') {
    if (d.trialDays > 0 || d.startDay + d.trialDays <= 30)
      out.push({ label: 'Start so the first charge lands next cycle', decision: { ...d, startDay: Math.max(d.startDay, 31 - d.trialDays) } })
    out.push({ label: 'Pick a cheaper plan at 60%', decision: { ...d, amount: Math.round(d.amount * 0.6) } })
    const sub = lowestUsageSub(state)
    if (sub) out.push({ label: `Swap: cancel ${sub.name.split(',')[0]}`, decision: { kind: 'combo', label: d.name, parts: [d, { kind: 'subscription_cancel', subId: sub.id }] } })
  }
  if (d.kind === 'surprise') out.push(...absorbPlaybook(state, d).slice(1))
  return out
}

export function generateAlternatives(state: AppState, d: Decision, before: Derived, orig: Derived): Alternative[] {
  const score = (x: Derived) => x.health.score - x.forecast.pBelowZero * 100
  return candidates(state, d, before)
    .map((c) => {
      const after = deriveFinancialState(applyDecision(state, c.decision), { full: false })
      return { ...c, after, verdictLevel: verdictOf(before, after).level }
    })
    .filter((a) => a.after.forecast.pBelowZero < orig.forecast.pBelowZero - 0.001 || a.after.health.score > orig.health.score)
    .sort((a, b) => score(b.after) - score(a.after))
    .slice(0, 3)
}
