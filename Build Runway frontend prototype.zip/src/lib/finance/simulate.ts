import type { AppState, Decision, Derived, SimulationResult, Snapshot, VerdictLevel } from '../../types/finance'
import { generateAlternatives } from './alternatives'
import { applyDecision, decisionAmount, isOutsideCycle } from './apply'
import { deriveFinancialState } from './derive'
import { formatINR, formatPct } from './format'
import { slipDays } from './goals'
import { scheduled } from './ledger'

export function snapshotOf(d: Derived): Snapshot {
  return {
    wallet: d.wallet, dailyAllowance: Math.round(d.dailyAllowance), closingP50: d.forecast.p50, riskLevel: d.risk.level,
    pBelowZero: d.forecast.pBelowZero, healthScore: d.health.score,
    goalEtas: Object.fromEntries(d.goals.map((g) => [g.id, g.etaDay ?? 9999])),
  }
}

export function goalSlipsOf(before: Derived, after: Derived) {
  return after.goals
    .map((g) => ({ goalId: g.id, days: slipDays(before.goals.find((b) => b.id === g.id)?.etaDay ?? null, g.etaDay) }))
    .filter((s) => s.days !== 0)
}

export function verdictOf(before: Derived, after: Derived): { level: VerdictLevel; headline: string; reason: string } {
  const worsened = after.forecast.pBelowZero - before.forecast.pBelowZero
  const healthDrop = before.health.score - after.health.score
  const slips = goalSlipsOf(before, after).filter((s) => s.days > 0)
  const unpayable = after.wallet - after.locked.total < 0 && before.wallet - before.locked.total >= 0
  const zero = after.forecast.expectedZeroDay ?? 30
  if (after.wallet < 0 || unpayable || (after.risk.level === 'critical' && worsened > 0.02))
    return {
      level: 'nope', headline: 'Not now.',
      reason: after.wallet < 0 ? `This puts you ${formatINR(-after.wallet)} in the red today.` : unpayable ? 'This leaves an upcoming bill without enough money behind it.' : 'This breaks your safety reserve today.',
    }
  if ((after.risk.level === 'high' && worsened > 0.02) || healthDrop >= 8)
    return { level: 'think', headline: 'Think twice.', reason: `In ${formatPct(after.forecast.pBelowZero)} of simulated months you run out by Day ${zero}.` }
  if (worsened > 0.02 || healthDrop >= 3 || slips.length > 0 || after.leftToday < 0) {
    let cost: string
    const s = slips[0]
    if (s) {
      const name = after.goals.find((g) => g.id === s.goalId)?.name ?? 'A goal'
      cost = s.days >= 999 ? `${name} loses its finish date` : `${name} slips ${s.days} day${s.days === 1 ? '' : 's'}`
    } else if (after.leftToday < 0) cost = `you'd be over today's allowance by ${formatINR(-after.leftToday)}`
    else if (worsened > 0.02) cost = `your chance of running out goes from ${formatPct(before.forecast.pBelowZero)} to ${formatPct(after.forecast.pBelowZero)}`
    else cost = `your health score drops ${healthDrop} points`
    return { level: 'tweak', headline: 'Okay, with a tweak.', reason: `Doable, but ${cost}.` }
  }
  return { level: 'go', headline: 'Go for it.', reason: `This fits, and you'd still have ${formatINR(after.dailyAllowance)} a day.` }
}

const TIPS: Partial<Record<Decision['kind'], string>> = {
  goal_adjust: 'Goals fund from the top of the list first, so the highest priority keeps its date longest.',
  income: 'Expected income only counts toward the forecast. Your allowance moves once it lands.',
  lifestyle_cut: 'Cuts only change the forecast, not money already spent. Small, specific cuts tend to stick.',
}

export function simulate(state: AppState, decision: Decision, base?: Derived, withAlternatives = true): SimulationResult {
  const before = base ?? deriveFinancialState(state)
  const after = deriveFinancialState(applyDecision(state, decision))
  const outsideCycle = isOutsideCycle(decision, state.settings.cycleDays)
  const amount = decisionAmount(decision, state)
  const per = outsideCycle ? state.settings.budget / state.settings.cycleDays : before.dailyAllowance
  const verdict = verdictOf(before, after)
  return {
    before, after, verdict, outsideCycle,
    costInAllowanceDays: per > 0 ? amount / per : amount > 0 ? Infinity : 0,
    goalSlips: goalSlipsOf(before, after),
    alternatives: withAlternatives ? generateAlternatives(state, decision, before, after) : [],
    tip: TIPS[decision.kind],
  }
}

export function resultFrom(state: AppState, decision: Decision, before: Derived, after: Derived): SimulationResult {
  const per = before.dailyAllowance
  const amount = decisionAmount(decision, state)
  return {
    before, after, verdict: verdictOf(before, after), outsideCycle: isOutsideCycle(decision, state.settings.cycleDays),
    costInAllowanceDays: per > 0 ? amount / per : 0, goalSlips: goalSlipsOf(before, after), alternatives: [],
  }
}

/** Plain-language summary of what a committed change moved. */
export function rippleLines(prev: AppState, next: AppState, before: Derived, after: Derived): { biggest: string; lines: string[] } {
  const lines: string[] = []
  for (const s of goalSlipsOf(before, after)) {
    const name = after.goals.find((g) => g.id === s.goalId)?.name ?? 'A goal'
    if (s.days >= 999) lines.push(`${name} goal is on hold, so it has no finish date.`)
    else if (s.days <= -999) lines.push(`${name} goal has a finish date again.`)
    else lines.push(s.days > 0 ? `${name} goal slips ${s.days} days.` : `${name} goal arrives ${-s.days} days sooner.`)
  }
  const key = (x: { id: string; day: number }) => `${x.id}:${x.day}`
  const nextItems = new Set(scheduled(next).map(key))
  const prevItems = new Set(scheduled(prev).map(key))
  for (const it of scheduled(prev)) if (!nextItems.has(key(it)) && it.type !== 'goal') lines.push(`Day ${it.day} ${it.trial ? 'trial conversion' : it.type === 'bill' ? 'bill' : 'renewal'} for ${it.name.split(',')[0]} removed.`)
  for (const it of scheduled(next)) if (!prevItems.has(key(it)) && it.type !== 'goal') lines.push(`${it.name.split(',')[0]} now lands on Day ${it.day}.`)
  const moves = [
    { v: Math.abs(after.dailyAllowance - before.dailyAllowance) * 10, s: `Your daily allowance moved by ${formatINR(Math.abs(after.dailyAllowance - before.dailyAllowance))}, because free to spend changed by ${formatINR(Math.abs(after.freeToSpend - before.freeToSpend))} across ${after.daysLeft} days.` },
    { v: Math.abs(after.forecast.pBelowZero - before.forecast.pBelowZero) * 3000, s: `Your chance of running out went from ${formatPct(before.forecast.pBelowZero)} to ${formatPct(after.forecast.pBelowZero)}.` },
    { v: Math.abs(after.health.score - before.health.score) * 30, s: `Your health score went from ${before.health.score} to ${after.health.score}.` },
    { v: Math.abs(after.forecast.p50 - before.forecast.p50), s: `Your likely month-end balance moved to ${formatINR(after.forecast.p50)}.` },
  ].sort((a, b) => b.v - a.v)
  return { biggest: moves[0].v > 0 ? moves[0].s : 'Nothing this cycle moved. The change sits outside this cycle or matches your current plan.', lines: lines.slice(0, 5) }
}
