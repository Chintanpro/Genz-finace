import type { AppState, Decision } from '../../types/finance'
import { clampAmount } from './format'

let seq = 0
export const newId = (prefix: string) => `${prefix}-${Date.now().toString(36)}-${(seq++).toString(36)}`

function applyInto(s: AppState, d: Decision): void {
  const { currentDay: cd, cycleDays } = s.settings
  switch (d.kind) {
    case 'purchase': {
      if (d.day > cycleDays || d.day < cd) return
      const amount = clampAmount(d.amount)
      s.transactions.push({ id: newId('p'), day: d.day, label: d.label || 'Purchase', kind: 'expense', amount, category: d.category, necessity: d.necessity, oneOff: true })
      return
    }
    case 'subscription_add': {
      const renewDay = Math.max(cd, d.startDay) + d.trialDays
      s.subscriptions.push({
        id: newId('s'), name: d.name || 'New subscription', amount: clampAmount(d.amount), renewDay,
        status: d.trialDays > 0 ? 'trial' : 'active', usage: 'medium',
        note: d.trialDays > 0 ? `Converts to paid on ${renewDay > cycleDays ? 'next cycle' : `Day ${renewDay}`}` : undefined,
      })
      return
    }
    case 'subscription_cancel': {
      const sub = s.subscriptions.find((x) => x.id === d.subId)
      if (sub) sub.status = 'cancelled'
      return
    }
    case 'goal_adjust': {
      const g = s.goals.find((x) => x.id === d.goalId)
      if (g) {
        g.weekly = clampAmount(d.weekly)
        g.paused = d.paused
      }
      return
    }
    case 'surprise': {
      if (d.day > cycleDays || d.day < cd) return
      s.transactions.push({ id: newId('x'), day: d.day, label: d.label || 'Surprise expense', kind: 'surprise', amount: clampAmount(d.amount) })
      return
    }
    case 'income': {
      if (d.day > cycleDays || d.day < cd) return
      const id = newId('i')
      const received = d.day === cd && d.confidence >= 1
      s.incomes.push({ id, name: 'Extra income', amount: clampAmount(d.amount), day: d.day, status: received ? 'received' : 'expected', confidence: d.confidence, countInBaseline: true })
      if (received) s.transactions.push({ id: `tx-${id}`, day: d.day, label: 'Extra income', kind: 'income', amount: clampAmount(d.amount), sourceId: id })
      return
    }
    case 'lifestyle_cut': {
      const toDay = d.days ? Math.min(cycleDays, cd + d.days - 1) : cycleDays
      s.cuts.push({ id: newId('cut'), category: d.category, percent: Math.min(60, Math.max(0, d.percent)), fromDay: cd, toDay })
      return
    }
    case 'goal_withdraw': {
      const g = s.goals.find((x) => x.id === d.goalId)
      if (g && d.amount > 0) s.transactions.push({ id: newId('w'), day: cd, label: `From ${g.name} goal`, kind: 'income', amount: clampAmount(d.amount), sourceId: g.id })
      return
    }
    case 'goal_add_money': {
      const g = s.goals.find((x) => x.id === d.goalId)
      if (g && d.amount > 0) s.transactions.push({ id: newId('t'), day: cd, label: `To ${g.name}`, kind: 'goal_transfer', amount: clampAmount(d.amount), sourceId: g.id })
      return
    }
    case 'commitment_defer': {
      const c = s.commitments.find((x) => x.id === d.commitmentId)
      if (c) {
        c.dueDay = Math.min(cycleDays, c.dueDay + d.days)
        c.status = 'deferred'
      }
      return
    }
    case 'combo':
      d.parts.forEach((p) => applyInto(s, p))
  }
}

/** Pure: returns a new state with the decision applied. */
export function applyDecision(state: AppState, d: Decision): AppState {
  const s = structuredClone(state)
  applyInto(s, d)
  return s
}

export function decisionAmount(d: Decision, state: AppState): number {
  switch (d.kind) {
    case 'purchase':
    case 'surprise':
      return clampAmount(d.amount)
    case 'subscription_add':
      return clampAmount(d.amount)
    case 'combo':
      return d.parts.reduce((a, p) => a + decisionAmount(p, state), 0)
    default:
      return 0
  }
}

export function isOutsideCycle(d: Decision, cycleDays: number): boolean {
  if (d.kind === 'purchase' || d.kind === 'surprise' || d.kind === 'income') return d.day > cycleDays
  if (d.kind === 'subscription_add') return d.startDay + d.trialDays > cycleDays
  return false
}

export interface ExpenseInput {
  amount: number
  label: string
  category: import('../../types/finance').Category
  necessity: 'need' | 'want'
}

/** Today's logged expense (counts toward the daily habit, unlike Test drive one-offs). */
export function addExpense(state: AppState, e: ExpenseInput): AppState {
  const s = structuredClone(state)
  s.transactions.push({ id: newId('e'), day: s.settings.currentDay, label: e.label || 'Expense', kind: 'expense', amount: clampAmount(e.amount), category: e.category, necessity: e.necessity })
  return s
}
