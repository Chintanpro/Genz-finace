import type { AppState, Category, Derived, Insight } from '../../types/finance'
import { formatINR } from './format'
import { CATEGORIES, RISK_ORDER, discretionary, sum } from './ledger'

const CAT_LABEL: Record<Category, string> = { food: 'Food', transport: 'Transport', fun: 'Fun', shopping: 'Shopping', health: 'Health', other: 'Other' }
export const categoryLabel = (c: Category) => CAT_LABEL[c]

export function buildInsights(state: AppState, d: Derived): Insight[] {
  const cd = state.settings.currentDay
  const out: Insight[] = []
  for (const s of state.subscriptions) {
    const n = s.renewDay - cd
    if (s.status === 'trial' && n >= 0 && n <= 5)
      out.push({
        id: `trial-${s.id}`, tone: 'warn', severity: 90,
        headline: `${s.name.split(',')[0]} trial converts in ${n} day${n === 1 ? '' : 's'} for ${formatINR(s.amount)}`,
        detail: 'Cancel before it converts and the full price stays with you this cycle.',
        preset: { kind: 'subscription_cancel', subId: s.id },
      })
  }
  for (const s of state.subscriptions)
    if (s.usage === 'low' && s.status === 'active')
      out.push({
        id: `lowuse-${s.id}`, tone: 'tip', severity: 50,
        headline: `${s.name.split(',')[0]}: ${s.note ? s.note.toLowerCase() : 'barely used'}, ${formatINR(s.amount)} a month`,
        detail: 'Cancelling stops future renewals. Nothing already paid is refunded.',
        preset: { kind: 'subscription_cancel', subId: s.id },
      })
  for (const c of CATEGORIES) {
    const p = d.categoryPace[c]
    if (p.pace > 0 && p.spent > p.pace * 1.2)
      out.push({
        id: `pace-${c}`, tone: 'warn', severity: 70,
        headline: `${CAT_LABEL[c]} is running ${Math.round((p.spent / p.pace - 1) * 100)}% over pace`,
        detail: `${formatINR(p.spent)} spent against a pace of ${formatINR(p.pace)} by today.`,
        preset: { kind: 'lifestyle_cut', category: c, percent: 30 },
      })
  }
  if (d.wantsShare > 0.5) {
    const wants = discretionary(state).filter((t) => t.necessity === 'want')
    const top = CATEGORIES.map((c) => ({ c, v: sum(wants.filter((t) => t.category === c).map((t) => t.amount)) })).sort((a, b) => b.v - a.v)[0]
    out.push({
      id: 'wants', tone: 'tip', severity: 60,
      headline: `Wants are ${Math.round(d.wantsShare * 100)}% of your spending`,
      detail: `${CAT_LABEL[top.c]} wants are the biggest slice. A short cut there frees the most room.`,
      preset: { kind: 'lifestyle_cut', category: top.c, percent: 30 },
    })
  }
  const freeShare = d.freeToSpend / Math.max(1, state.settings.budget)
  for (const g of d.goals)
    if ((g.status === 'behind' || g.status === 'off_track') && freeShare > 0.25) {
      const boost = Math.max(10, Math.ceil((g.requiredWeekly - g.weekly) / 10) * 10)
      out.push({
        id: `boost-${g.id}`, tone: 'tip', severity: 40,
        headline: `Boost ${g.name} by ${formatINR(boost)} a week`,
        detail: `You have room this cycle, and ${formatINR(g.requiredWeekly)} a week hits the deadline.`,
        preset: { kind: 'goal_adjust', goalId: g.id, weekly: Math.min(500, g.weekly + boost), paused: false },
      })
    }
  if (d.maxAbsorbable < 1000)
    out.push({
      id: 'shock', tone: 'warn', severity: 65,
      headline: `A surprise bigger than ${formatINR(d.maxAbsorbable)} would likely put you in the red`,
      detail: 'Stress test a ₹1,200 surprise to see which goals would slip first.',
      preset: { kind: 'surprise', label: 'Dental visit', amount: 1200, day: cd },
    })
  const last = state.decisionLog[state.decisionLog.length - 1]
  if (last && RISK_ORDER.indexOf(last.after.riskLevel) < RISK_ORDER.indexOf(last.before.riskLevel))
    out.push({ id: 'riskwin', tone: 'win', severity: 80, headline: `Your risk dropped to ${last.after.riskLevel}`, detail: 'Your last change made running out less likely.' })
  return out.sort((a, b) => b.severity - a.severity)
}
