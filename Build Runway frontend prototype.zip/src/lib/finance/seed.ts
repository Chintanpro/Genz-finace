import type { AppState, Category, Transaction } from '../../types/finance'

export const APP_NAME = 'Runway'
export const GOAL_DAYS = [1, 8, 15, 22, 29]

const expenseRows: [number, string, Category, number, 'need' | 'want'][] = [
  [1, 'Grocery and snacks top-up', 'food', 280, 'need'],
  [1, 'Cab to campus in the rain', 'transport', 110, 'need'],
  [2, 'Canteen lunch', 'food', 70, 'need'],
  [3, 'Biryani delivery', 'food', 240, 'want'],
  [3, 'Movie night', 'fun', 220, 'want'],
  [4, 'Thrifted jacket', 'shopping', 350, 'want'],
  [5, 'Cafe catch-up', 'food', 130, 'want'],
  [5, 'Auto rides', 'transport', 50, 'need'],
  [6, 'Canteen and chai', 'food', 80, 'need'],
  [7, 'Pharmacy', 'health', 90, 'need'],
  [8, 'Canteen lunch', 'food', 70, 'need'],
  [9, 'Birthday dinner split', 'fun', 300, 'want'],
  [10, 'Late-night delivery', 'food', 190, 'want'],
  [11, 'Auto and chai', 'transport', 60, 'need'],
  [12, 'Chai and snacks', 'food', 40, 'need'],
]

export function createSeedState(): AppState {
  const state: AppState = {
    settings: {
      budget: 10000,
      cycleDays: 30,
      currentDay: 12,
      reserve: 500,
      categorySplit: { food: 0.45, fun: 0.2, shopping: 0.14, transport: 0.1, health: 0.05, other: 0.06 },
      theme: 'system',
      surprises: true,
    },
    incomes: [
      { id: 'i1', name: 'Monthly allowance (stipend + pocket money)', amount: 10000, day: 1, status: 'received', confidence: 1, countInBaseline: true },
      { id: 'i2', name: 'Weekend design gig', amount: 1200, day: 19, status: 'expected', confidence: 0.6, countInBaseline: false },
    ],
    commitments: [
      { id: 'c1', name: 'Metro pass', amount: 600, dueDay: 2, status: 'paid', lateFee: 50 },
      { id: 'c2', name: 'Mobile recharge', amount: 299, dueDay: 4, status: 'paid', lateFee: 0 },
      { id: 'c3', name: 'Wi-Fi share', amount: 250, dueDay: 15, status: 'upcoming', lateFee: 50, flexible: true },
      { id: 'c4', name: 'Course material, instalment 2 of 3', amount: 400, dueDay: 20, status: 'upcoming', lateFee: 50 },
      { id: 'c5', name: 'Pay-later sneakers, instalment 2 of 3', amount: 500, dueDay: 22, status: 'upcoming', lateFee: 50 },
    ],
    subscriptions: [
      { id: 's1', name: 'Music app, student plan', amount: 59, renewDay: 7, status: 'active', usage: 'high' },
      { id: 's2', name: 'Video app premium, student plan', amount: 79, renewDay: 14, status: 'active', usage: 'high' },
      { id: 's3', name: 'AI writing app, free trial', amount: 399, renewDay: 16, status: 'trial', usage: 'low', note: 'Converts to paid on Day 16' },
      { id: 's4', name: 'Streaming, mobile plan', amount: 149, renewDay: 21, status: 'active', usage: 'medium' },
      { id: 's5', name: 'Shared prime bundle split', amount: 150, renewDay: 25, status: 'active', usage: 'medium' },
      { id: 's6', name: 'Fitness app', amount: 199, renewDay: 27, status: 'active', usage: 'low', note: 'Unused for 3 weeks' },
    ],
    goals: [
      { id: 'g1', name: 'Emergency buffer', target: 2000, savedBeforeCycle: 700, weekly: 100, deadlineDay: 100, priority: 1, paused: false },
      { id: 'g2', name: 'Earbuds', target: 2500, savedBeforeCycle: 300, weekly: 100, deadlineDay: 120, priority: 2, paused: false },
      { id: 'g3', name: 'Weekend trip', target: 3000, savedBeforeCycle: 0, weekly: 50, deadlineDay: 180, priority: 3, paused: false },
    ],
    cuts: [],
    transactions: [],
    decisionLog: [],
  }
  const tx: Transaction[] = []
  for (const inc of state.incomes)
    if (inc.status === 'received') tx.push({ id: `tx-${inc.id}`, day: inc.day, label: inc.name, kind: 'income', amount: inc.amount, sourceId: inc.id, auto: true })
  expenseRows.forEach(([day, label, category, amount, necessity], i) =>
    tx.push({ id: `e${i + 1}`, day, label, kind: 'expense', amount, category, necessity }),
  )
  const cd = state.settings.currentDay
  for (const c of state.commitments)
    if (c.dueDay <= cd) tx.push({ id: `tx-${c.id}`, day: c.dueDay, label: c.name, kind: 'bill', amount: c.amount, sourceId: c.id, auto: true })
  for (const s of state.subscriptions)
    if (s.renewDay <= cd) tx.push({ id: `tx-${s.id}`, day: s.renewDay, label: s.name, kind: 'subscription', amount: s.amount, sourceId: s.id, auto: true })
  for (const d of GOAL_DAYS)
    if (d <= cd)
      for (const g of state.goals)
        tx.push({ id: `tx-${g.id}-${d}`, day: d, label: `To ${g.name}`, kind: 'goal_transfer', amount: g.weekly, sourceId: g.id, auto: true })
  state.transactions = tx.sort((a, b) => a.day - b.day)
  return state
}
