export const SEED = 20261011

export function mulberry32(seed: number): () => number {
  let a = seed >>> 0
  return () => {
    a = (a + 0x6d2b79f5) >>> 0
    let t = a
    t = Math.imul(t ^ (t >>> 15), t | 1)
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61)
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296
  }
}

export const DRAWS_PER_DAY = 6
export const MAX_RUNS = 500
export const MAX_DAYS = 31

let table: Float64Array | null = null

/** Common random numbers: one fixed table shared by every baseline and scenario. */
export function drawTable(): Float64Array {
  if (table) return table
  const rand = mulberry32(SEED)
  const t = new Float64Array(MAX_RUNS * MAX_DAYS * DRAWS_PER_DAY)
  for (let i = 0; i < t.length; i++) t[i] = Math.max(1e-9, rand())
  table = t
  return t
}

export function draw(run: number, day: number, k: number): number {
  return drawTable()[(run * MAX_DAYS + Math.min(day, MAX_DAYS - 1)) * DRAWS_PER_DAY + k]
}

export function normal(u1: number, u2: number): number {
  return Math.sqrt(-2 * Math.log(u1)) * Math.cos(2 * Math.PI * u2)
}
