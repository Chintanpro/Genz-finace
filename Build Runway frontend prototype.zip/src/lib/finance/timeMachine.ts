import type { AppState } from '../../types/finance'
import { newId } from './apply'
import { expectedDailyOf, walletOf } from './ledger'
import { GOAL_DAYS } from './seed'

export interface AdvanceResult {
  state: AppState
  events: string[]
  cycleComplete: boolean
}

/** Close today and open the next day, auto-posting what falls due. */
export function advanceDay(prev: AppState): AdvanceResult {
  const s = structuredClone(prev)
  const events: string[] = []
  const cd = s.settings.currentDay
  if (!s.transactions.some((t) => t.kind === 'expense' && t.day === cd))
    s.transactions.push({ id: newId('typ'), day: cd, label: 'Typical day', kind: 'expense', amount: Math.round(expectedDailyOf(s)), category: 'food', necessity: 'need', simulated: true })
  if (cd >= s.settings.cycleDays) return { state: s, events, cycleComplete: true }
  const n = cd + 1
  s.settings.currentDay = n
  for (const inc of s.incomes)
    if (inc.status === 'expected' && inc.day === n && inc.confidence >= 0.6) {
      inc.status = 'received'
      s.transactions.push({ id: `tx-${inc.id}`, day: n, label: inc.name, kind: 'income', amount: inc.amount, sourceId: inc.id, auto: true })
      events.push(`${inc.name} landed.`)
    }
  for (const c of s.commitments) {
    if ((c.status !== 'upcoming' && c.status !== 'deferred') || c.dueDay !== n) continue
    if (walletOf(s) >= c.amount) {
      c.status = 'paid'
      s.transactions.push({ id: `tx-${c.id}`, day: n, label: c.name, kind: 'bill', amount: c.amount, sourceId: c.id, auto: true })
    } else {
      c.status = 'failed'
      if (c.lateFee > 0) s.transactions.push({ id: newId('fee'), day: n, label: `Late fee: ${c.name}`, kind: 'late_fee', amount: c.lateFee, sourceId: c.id, auto: true })
      events.push(`Missed ${c.name}. ₹${c.lateFee} late fee added.`)
    }
  }
  for (const sub of s.subscriptions) {
    if ((sub.status !== 'active' && sub.status !== 'trial') || sub.renewDay !== n) continue
    if (walletOf(s) >= sub.amount) {
      sub.status = 'active'
      sub.note = undefined
      s.transactions.push({ id: `tx-${sub.id}`, day: n, label: sub.name, kind: 'subscription', amount: sub.amount, sourceId: sub.id, auto: true })
    } else {
      sub.status = 'paused'
      events.push(`${sub.name} paused. Not enough to renew.`)
    }
  }
  if (GOAL_DAYS.includes(n))
    for (const g of [...s.goals].sort((a, b) => a.priority - b.priority)) {
      if (g.paused || g.weekly <= 0) continue
      if (walletOf(s) - g.weekly >= s.settings.reserve)
        s.transactions.push({ id: `tx-${g.id}-${n}`, day: n, label: `To ${g.name}`, kind: 'goal_transfer', amount: g.weekly, sourceId: g.id, auto: true })
      else events.push(`${g.name} contribution skipped to protect your reserve.`)
    }
  return { state: s, events, cycleComplete: false }
}
