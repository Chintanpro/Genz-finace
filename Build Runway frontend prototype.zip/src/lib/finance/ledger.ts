import type { RiskLevel, AppState, Category, Transaction, TxKind } from '../../types/finance'
import { GOAL_DAYS } from './seed'

export const CATEGORIES: Category[] = ['food', 'transport', 'fun', 'shopping', 'health', 'other']
const OUTFLOWS: TxKind[] = ['expense', 'bill', 'subscription', 'goal_transfer', 'surprise', 'late_fee']

export const isOutflow = (t: Transaction) => OUTFLOWS.includes(t.kind)
export const sum = (xs: number[]) => xs.reduce((a, b) => a + b, 0)
export const clamp01 = (x: number) => (Number.isFinite(x) ? Math.min(1, Math.max(0, x)) : 0)
export const safeDiv = (a: number, b: number) => (b === 0 || !Number.isFinite(b) ? 0 : a / b)

export function postedTx(state: AppState): Transaction[] {
  return state.transactions.filter((t) => t.day <= state.settings.currentDay)
}

export function walletOf(state: AppState): number {
  return sum(postedTx(state).map((t) => (t.kind === 'income' ? t.amount : isOutflow(t) ? -t.amount : 0)))
}

export interface ScheduledItem {
  day: number
  amount: number
  type: 'bill' | 'subscription' | 'goal' | 'planned'
  id: string
  name: string
  priority?: number
  trial?: boolean
}

function goalPosted(state: AppState, goalId: string, day: number) {
  return state.transactions.some((t) => t.kind === 'goal_transfer' && t.sourceId === goalId && t.day === day && t.auto)
}

/** Every outflow still to come in this cycle, from today onward. */
export function scheduled(state: AppState): ScheduledItem[] {
  const { currentDay: cd, cycleDays } = state.settings
  const out: ScheduledItem[] = []
  for (const c of state.commitments)
    if ((c.status === 'upcoming' || c.status === 'deferred') && c.dueDay <= cycleDays)
      out.push({ day: Math.max(cd, c.dueDay), amount: c.amount, type: 'bill', id: c.id, name: c.name })
  for (const s of state.subscriptions) {
    if (s.status !== 'active' && s.status !== 'trial') continue
    if (s.renewDay < cd || s.renewDay > cycleDays) continue
    if (state.transactions.some((t) => t.kind === 'subscription' && t.sourceId === s.id)) continue
    out.push({ day: s.renewDay, amount: s.amount, type: 'subscription', id: s.id, name: s.name, trial: s.status === 'trial' })
  }
  for (const g of state.goals) {
    if (g.paused || g.weekly <= 0) continue
    for (const d of GOAL_DAYS)
      if (d >= cd && d <= cycleDays && !goalPosted(state, g.id, d))
        out.push({ day: d, amount: g.weekly, type: 'goal', id: g.id, name: g.name, priority: g.priority })
  }
  for (const t of state.transactions)
    if (t.day > cd && t.day <= cycleDays && isOutflow(t))
      out.push({ day: t.day, amount: t.amount, type: 'planned', id: t.id, name: t.label })
  return out.sort((a, b) => a.day - b.day || (a.priority ?? 0) - (b.priority ?? 0))
}

export function discretionary(state: AppState): Transaction[] {
  return postedTx(state).filter((t) => t.kind === 'expense')
}

export function dailySpend(state: AppState, habitOnly = false): number[] {
  const days = Array.from({ length: state.settings.cycleDays }, () => 0)
  for (const t of discretionary(state)) if (!habitOnly || !t.oneOff) if (t.day >= 1 && t.day <= days.length) days[t.day - 1] += t.amount
  return days
}

export function expectedDailyOf(state: AppState): number {
  const cd = state.settings.currentDay
  const ds = dailySpend(state, true)
  const last7 = ds.slice(Math.max(0, cd - 7), cd)
  const cycle = ds.slice(0, cd)
  const avg = (xs: number[]) => safeDiv(sum(xs), xs.length)
  return Math.max(60, 0.6 * avg(last7) + 0.4 * avg(cycle))
}

export function categoryShares(state: AppState): Record<Category | 'wants', number> {
  const d = discretionary(state)
  const total = sum(d.map((t) => t.amount))
  const out = { wants: safeDiv(sum(d.filter((t) => t.necessity === 'want').map((t) => t.amount)), total) } as Record<Category | 'wants', number>
  for (const c of CATEGORIES) out[c] = safeDiv(sum(d.filter((t) => t.category === c).map((t) => t.amount)), total)
  return out
}

/** Multiplier on expected daily spend from active lifestyle cuts. */
export function cutFactor(state: AppState, shares: Record<Category | 'wants', number>, day: number): number {
  let f = 1
  for (const c of state.cuts) if (day >= c.fromDay && day <= c.toDay) f -= (c.percent / 100) * shares[c.category]
  return Math.max(0.2, f)
}

export function goalSaved(state: AppState, goalId: string, savedBefore: number): number {
  const tx = postedTx(state)
  const ins = sum(tx.filter((t) => t.kind === 'goal_transfer' && t.sourceId === goalId).map((t) => t.amount))
  const outs = sum(tx.filter((t) => t.kind === 'income' && t.sourceId === goalId).map((t) => t.amount))
  return savedBefore + ins - outs
}

export function riskLevelOf(pBelowZero: number, wallet: number): RiskLevel {
  if (wallet < 0 || pBelowZero >= 0.5) return 'critical'
  if (pBelowZero < 0.08) return 'low'
  if (pBelowZero < 0.25) return 'watch'
  return 'high'
}

export const RISK_ORDER: RiskLevel[] = ['low', 'watch', 'high', 'critical']

