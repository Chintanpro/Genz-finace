import type { AppState, Forecast } from '../../types/finance'
import { categoryShares, cutFactor, scheduled, type ScheduledItem } from './ledger'
import { draw, MAX_RUNS, normal } from './rng'

export const FORECAST = { runs: MAX_RUNS, sigma: 0.5, surpriseP: 0.015, surpriseMedian: 600, surpriseSigma: 0.6, surpriseMin: 150, surpriseMax: 3000 }

export interface ForecastInput {
  state: AppState
  wallet: number
  expectedDaily: number
  spentToday: number
}

interface RunResult {
  path: number[]
  firstNeg: number | null
  goalPaid: Map<string, boolean>
}

function runOnce(inp: ForecastInput, items: ScheduledItem[], run: number, extraToday: number, deterministic: boolean): RunResult {
  const { state } = inp
  const { currentDay: cd, cycleDays, reserve, surprises } = state.settings
  const shares = categoryShares(state)
  const mu = (m: number) => Math.log(Math.max(1, m)) - (FORECAST.sigma * FORECAST.sigma) / 2
  let bal = inp.wallet - extraToday
  let firstNeg: number | null = bal < 0 ? cd : null
  const path: number[] = []
  const goalPaid = new Map<string, boolean>()
  for (let d = cd; d <= cycleDays; d++) {
    for (const inc of state.incomes)
      if (inc.status === 'expected' && inc.countInBaseline && inc.day === d) {
        const lands = deterministic ? inc.confidence >= 0.5 : draw(run, d, 5) < inc.confidence
        if (lands) bal += inc.amount
      }
    for (const it of items) {
      if (it.day !== d) continue
      if (it.type === 'goal') {
        const pay = bal - it.amount >= reserve
        goalPaid.set(`${it.id}:${d}`, pay)
        if (pay) bal -= it.amount
      } else bal -= it.amount
    }
    const m = inp.expectedDaily * cutFactor(state, shares, d)
    let x = deterministic ? m : Math.exp(mu(m) + FORECAST.sigma * normal(draw(run, d, 0), draw(run, d, 1)))
    if (d === cd) x = Math.max(0, x - inp.spentToday)
    bal -= x
    if (!deterministic && surprises && draw(run, d, 2) < FORECAST.surpriseP) {
      const s = Math.exp(Math.log(FORECAST.surpriseMedian) + FORECAST.surpriseSigma * normal(draw(run, d, 3), draw(run, d, 4)))
      bal -= Math.min(FORECAST.surpriseMax, Math.max(FORECAST.surpriseMin, s))
    }
    if (bal < 0 && firstNeg === null) firstNeg = d
    path.push(bal)
  }
  return { path, firstNeg, goalPaid }
}

const pct = (sorted: number[], p: number) => sorted[Math.min(sorted.length - 1, Math.max(0, Math.floor(p * (sorted.length - 1))))] ?? 0

export function runForecast(inp: ForecastInput, runs = FORECAST.runs, extraToday = 0): Forecast {
  const items = scheduled(inp.state)
  const { currentDay: cd, reserve } = inp.state.settings
  const results: RunResult[] = []
  for (let r = 0; r < runs; r++) results.push(runOnce(inp, items, r, extraToday, false))
  const days = results[0]?.path.length ?? 0
  const path = []
  for (let i = 0; i < days; i++) {
    const col = results.map((r) => r.path[i]).sort((a, b) => a - b)
    path.push({ day: cd + i, p10: Math.round(pct(col, 0.1)), p50: Math.round(pct(col, 0.5)), p90: Math.round(pct(col, 0.9)) })
  }
  const closing = results.map((r) => r.path[days - 1] ?? inp.wallet).sort((a, b) => a - b)
  const fails = results.filter((r) => r.firstNeg !== null).map((r) => r.firstNeg as number).sort((a, b) => a - b)
  return {
    p10: Math.round(pct(closing, 0.1)),
    p50: Math.round(pct(closing, 0.5)),
    p90: Math.round(pct(closing, 0.9)),
    pBelowZero: fails.length / Math.max(1, runs),
    pBelowReserve: closing.filter((c) => c < reserve).length / Math.max(1, runs),
    expectedZeroDay: fails.length ? pct(fails, 0.5) : undefined,
    path,
  }
}

/** Deterministic expected path, used for goal ETAs and paid/skipped contributions. */
export function expectedGoalPayments(inp: ForecastInput): Map<string, boolean> {
  return runOnce(inp, scheduled(inp.state), 0, 0, true).goalPaid
}

export function maxAbsorbable(inp: ForecastInput): number {
  let lo = 0
  let hi = 5000
  if (runForecast(inp, 200, 0).pBelowZero >= 0.5) return 0
  if (runForecast(inp, 200, hi).pBelowZero < 0.5) return hi
  while (hi - lo > 25) {
    const mid = Math.round((lo + hi) / 2)
    if (runForecast(inp, 200, mid).pBelowZero < 0.5) lo = mid
    else hi = mid
  }
  return Math.floor(lo / 50) * 50
}
