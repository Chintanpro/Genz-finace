const fmt = new Intl.NumberFormat('en-IN', { maximumFractionDigits: 0 })

export function formatINR(n: number): string {
  const v = Math.round(n)
  return `${v < 0 ? '−' : ''}₹${fmt.format(Math.abs(v))}`
}

export function formatSigned(n: number): string {
  const v = Math.round(n)
  if (v === 0) return '₹0'
  return `${v > 0 ? '+' : '−'}₹${fmt.format(Math.abs(v))}`
}

export function formatPct(p: number): string {
  return `${Math.round(p * 100)}%`
}

export function clampAmount(n: number): number {
  if (!Number.isFinite(n)) return 0
  return Math.min(50000, Math.max(0, Math.round(n)))
}

export function dayLabel(day: number, cycleDays = 30): string {
  return day > cycleDays ? 'Next cycle' : `Day ${day}`
}

export function weeksLabel(days: number | null): string {
  if (days === null) return 'No date yet'
  if (days <= 0) return 'Reached'
  const w = Math.round(days / 7)
  if (w <= 1) return days <= 7 ? `about ${days} days` : 'about a week'
  if (w > 52) return 'over a year'
  return `about ${w} weeks`
}
