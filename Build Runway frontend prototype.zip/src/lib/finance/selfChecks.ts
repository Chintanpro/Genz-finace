import type { AppState } from '../../types/finance'
import { deriveFinancialState } from './derive'
import { runForecast } from './forecast'
import { expectedDailyOf, walletOf } from './ledger'
import { simulate } from './simulate'

export function runSelfChecks(state: AppState): { name: string; pass: boolean }[] {
  const d = deriveFinancialState(state)
  const mapSum = d.moneyMap.reduce((a, s) => a + s.amount, 0)
  const g = state.goals[0]
  const noop = g ? simulate(state, { kind: 'goal_adjust', goalId: g.id, weekly: g.weekly, paused: g.paused }, d, false) : null
  const inp = { state, wallet: walletOf(state), expectedDaily: expectedDailyOf(state), spentToday: d.spentToday }
  const f1 = runForecast(inp)
  const f2 = runForecast(inp)
  const clone = structuredClone(state)
  return [
    { name: 'Money Map sums to the money in this cycle', pass: d.freeToSpend < 0 || mapSum === d.moneyTotal },
    {
      name: 'A no-op decision gives zero deltas',
      pass: !!noop && noop.after.wallet === d.wallet && noop.after.forecast.p50 === d.forecast.p50 && noop.after.health.score === d.health.score && noop.after.dailyAllowance === d.dailyAllowance,
    },
    { name: 'The same seed gives identical forecasts', pass: JSON.stringify(f1) === JSON.stringify(f2) },
    { name: 'Undo restores state exactly', pass: JSON.stringify(clone) === JSON.stringify(state) },
  ]
}
