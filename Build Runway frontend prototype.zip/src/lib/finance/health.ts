import type { AppState, HealthPart } from '../../types/finance'
import { clamp01, discretionary, safeDiv, sum } from './ledger'

export const HEALTH_WEIGHTS: Record<HealthPart, number> = {
  runway: 0.25,
  discipline: 0.2,
  commitment_load: 0.15,
  savings_momentum: 0.2,
  risk_resilience: 0.15,
  consistency: 0.05,
}

export const HEALTH_LABELS: Record<HealthPart, { label: string; hint: string }> = {
  runway: { label: 'Runway', hint: 'Money left after what is locked in, against your usual pace.' },
  discipline: { label: 'Spending mix', hint: 'Fewer wants and a pace close to plan move this up.' },
  commitment_load: { label: 'Commitment load', hint: 'Bills and subscriptions as a share of the budget.' },
  savings_momentum: { label: 'Savings momentum', hint: 'Weekly goal amounts against what deadlines need.' },
  risk_resilience: { label: 'Risk resilience', hint: 'How rarely simulated months run out of money.' },
  consistency: { label: 'Consistency', hint: 'Days you stayed within your daily plan.' },
}

export function healthBand(score: number): string {
  if (score < 40) return 'Rough patch'
  if (score < 60) return 'Shaky'
  if (score < 75) return 'Steady'
  if (score < 90) return 'Strong'
  return 'Excellent'
}

export interface HealthInput {
  state: AppState
  wallet: number
  lockedTotal: number
  expectedDaily: number
  daysLeft: number
  discretionaryPool: number
  riskIndex: number
  dailySpend: number[]
  commitmentTotal: number
  subscriptionTotal: number
  goalScheduledTotal: number
  requiredWeekly: Record<string, number>
}

export function computeHealth(h: HealthInput) {
  const { state } = h
  const { budget, cycleDays, currentDay } = state.settings
  const disc = discretionary(state)
  const discTotal = sum(disc.map((t) => t.amount))
  const wantsShare = safeDiv(sum(disc.filter((t) => t.necessity === 'want').map((t) => t.amount)), discTotal)
  const dailyPlan = safeDiv(h.discretionaryPool, cycleDays)
  const avgDaily = safeDiv(sum(disc.filter((t) => !t.oneOff).map((t) => t.amount)), currentDay)
  const pw: Record<number, number> = { 1: 0.5, 2: 0.3, 3: 0.2 }
  const momentumA = sum(
    state.goals.map((g) => {
      const req = h.requiredWeekly[g.id] ?? 0
      const ratio = g.paused ? 0 : req <= 0 ? 1 : Math.min(1, g.weekly / req)
      return (pw[g.priority] ?? 0) * ratio
    }),
  )
  const parts: Record<HealthPart, number> = {
    runway: clamp01((safeDiv(h.wallet - h.lockedTotal, h.expectedDaily * h.daysLeft) - 0.6) / 0.8) * 100,
    discipline: (clamp01((0.7 - wantsShare) / 0.35) * 100 + clamp01((1.5 - safeDiv(avgDaily, dailyPlan)) / 0.6) * 100) / 2,
    commitment_load: clamp01((0.6 - safeDiv(h.commitmentTotal + h.subscriptionTotal, budget)) / 0.3) * 100,
    savings_momentum: (momentumA * 100 + clamp01(safeDiv(h.goalScheduledTotal, budget) / 0.15) * 100) / 2,
    risk_resilience: 100 - h.riskIndex,
    consistency: safeDiv(h.dailySpend.slice(0, currentDay).filter((x) => x <= dailyPlan).length, currentDay) * 100,
  }
  for (const k of Object.keys(parts) as HealthPart[]) parts[k] = Math.round(parts[k])
  const score = Math.round(sum((Object.keys(parts) as HealthPart[]).map((k) => parts[k] * HEALTH_WEIGHTS[k])))
  return { score, band: healthBand(score), parts, wantsShare }
}
