import { useState } from 'react'
import { Search } from 'lucide-react'
import { Badge, Button, InputField, Tabs, cn } from '@figma/astraui'
import type { Category } from '../types/finance'
import { useStore } from '../state/store'
import { formatINR, formatPct } from '../lib/finance/format'
import { categoryLabel } from '../lib/finance/insights'
import { CATEGORIES } from '../lib/finance/ledger'
import EmptyState from '../components/EmptyState'
import TransactionRow from '../components/TransactionRow'
import Card from '../components/ui/Card'
import Chip from '../components/ui/Chip'
import Heading from '../components/ui/Heading'
import LockedIn from './LockedIn'
import IncomeTab from './IncomeTab'

function Activity() {
  const { state, derived, openSheet } = useStore()
  const [cat, setCat] = useState<Category | 'all'>('all')
  const [nec, setNec] = useState<'all' | 'need' | 'want'>('all')
  const [q, setQ] = useState('')
  const cd = state.settings.currentDay
  const rows = state.transactions
    .filter((t) => t.day <= cd)
    .filter((t) => (cat === 'all' ? true : t.category === cat))
    .filter((t) => (nec === 'all' ? true : t.necessity === nec))
    .filter((t) => t.label.toLowerCase().includes(q.toLowerCase()))
  const days = [...new Set(rows.map((r) => r.day))].sort((a, b) => b - a)
  return (
    <div className="flex flex-col gap-xl pt-lg">
      <Card title="Category pace" subtitle="Spent so far against where your plan says you should be by today.">
        <ul className="flex flex-col gap-md">
          {CATEGORIES.map((c) => {
            const p = derived.categoryPace[c]
            const ratio = p.pace > 0 ? p.spent / p.pace : 0
            const over = ratio > 1.2
            return (
              <li key={c} className="flex flex-col gap-xs">
                <span className="flex items-center justify-between gap-md text-label-sm">
                  <span className="flex items-center gap-sm text-text-primary">{categoryLabel(c)} {over && <Badge label="over pace" variant="danger" />}</span>
                  <span className="tabular text-text-secondary">{formatINR(p.spent)} of {formatINR(p.pace)}</span>
                </span>
                <span className="relative h-2 overflow-hidden rounded-corner-full bg-bg-subtle" aria-hidden>
                  <span className={cn('absolute inset-y-0 left-0 rounded-corner-full', over ? 'bg-money-danger' : 'bg-money-locked')} style={{ width: `${Math.min(100, (ratio / 1.5) * 100)}%` }} />
                  <span className="absolute inset-y-0 w-0.5 bg-text-primary" style={{ left: `${100 / 1.5}%` }} />
                </span>
              </li>
            )
          })}
        </ul>
      </Card>
      <section className="flex flex-col gap-lg rounded-corner-lg bg-surface-bg p-xl" aria-label="Ledger">
        <InputField label="Search" placeholder="Search activity" prefix={<Search size={16} />} value={q} onChange={setQ} />
        <div className="scrollbar-none -mx-xl flex gap-sm overflow-x-auto px-xl" role="group" aria-label="Filter by category">
          <Chip selected={cat === 'all'} onClick={() => setCat('all')}>All</Chip>
          {CATEGORIES.map((c) => <Chip key={c} selected={cat === c} onClick={() => setCat(c)}>{categoryLabel(c)}</Chip>)}
        </div>
        <div className="flex gap-sm" role="group" aria-label="Filter by need or want">
          {(['all', 'need', 'want'] as const).map((n) => <Chip key={n} selected={nec === n} onClick={() => setNec(n)}>{n === 'all' ? 'Needs and wants' : n === 'need' ? 'Needs' : 'Wants'}</Chip>)}
        </div>
        {days.length === 0 && <EmptyState icon={<Search size={20} />} title="No matches" body="Try a different filter or search term." />}
        {days.map((day) => (
          <div key={day} className="flex flex-col gap-xs">
            <span className="text-video-title font-semibold text-text-secondary">{day === cd ? 'Today' : `Day ${day}`}</span>
            {rows.filter((r) => r.day === day).map((tx) => <TransactionRow key={tx.id} tx={tx} onOpen={() => openSheet({ kind: 'tx', txId: tx.id })} />)}
          </div>
        ))}
      </section>
    </div>
  )
}

export default function Money() {
  const { derived, state, openSheet } = useStore()
  return (
    <div className="flex flex-col gap-lg">
      <div className="flex items-start justify-between gap-md">
        <div className="flex flex-col gap-xs">
          <Heading level={1}>Money</Heading>
          <p className="text-label-sm text-text-secondary">
            Wallet {formatINR(derived.wallet)} · locked in ahead {formatINR(derived.locked.total)} ({formatPct(derived.locked.total / state.settings.budget)})
          </p>
        </div>
        <Button variant="neutral" size="small" onClick={() => openSheet({ kind: 'log' })}>Log expense</Button>
      </div>
      <Tabs tabs={[
        { id: 'activity', label: 'Activity', content: <Activity /> },
        { id: 'locked', label: 'Locked in', content: <LockedIn /> },
        { id: 'income', label: 'Income', content: <IncomeTab /> },
      ]} />
    </div>
  )
}
