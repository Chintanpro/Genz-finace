import { useEffect, useMemo, useState } from 'react'
import { motion } from 'motion/react'
import { Lightbulb } from 'lucide-react'
import { Button, Modal } from '@figma/astraui'
import type { Decision } from '../types/finance'
import { useStore } from '../state/store'
import AlternativeCard from '../components/AlternativeCard'
import ImpactGrid from '../components/ImpactGrid'
import MoneyMap from '../components/MoneyMap'
import PreviewBanner from '../components/PreviewBanner'
import VerdictBanner from '../components/VerdictBanner'
import Chip from '../components/ui/Chip'
import Heading from '../components/ui/Heading'
import DecisionForm, { toDecision, type FormState, type Kind } from './DecisionForm'

const KINDS: { id: Kind; label: string; cta: string }[] = [
  { id: 'purchase', label: 'Purchase', cta: 'Log this purchase' },
  { id: 'subscription_add', label: 'New subscription', cta: 'Add subscription' },
  { id: 'subscription_cancel', label: 'Cancel subscription', cta: 'Cancel subscription' },
  { id: 'goal_adjust', label: 'Goal plan', cta: 'Update goal plan' },
  { id: 'surprise', label: 'Surprise', cta: 'Add surprise expense' },
  { id: 'income', label: 'Income', cta: 'Add income' },
  { id: 'lifestyle_cut', label: 'Spending cut', cta: 'Apply spending cut' },
]

export default function TestDrive() {
  const { state, derived, setPreview, sim, simPending, commit, tdPreset } = useStore()
  const cd = state.settings.currentDay
  const blank = useMemo<FormState>(() => {
    const g = state.goals[0]
    return {
      label: '', amount: 0, day: cd, category: 'fun', necessity: 'want', subName: '', trialDays: 0,
      subId: state.subscriptions.find((s) => s.status === 'trial')?.id ?? '', goalId: g?.id ?? '', weekly: g?.weekly ?? 0, paused: g?.paused ?? false,
      confidence: 0.6, cutCategory: 'wants', percent: 30,
    }
  }, [state, cd])
  const [kind, setKind] = useState<Kind>('purchase')
  const [f, setF] = useState<FormState>(blank)
  const [override, setOverride] = useState<{ label: string; decision: Decision } | null>(null)
  const [confirm, setConfirm] = useState(false)
  const [pulse, setPulse] = useState(0)
  const set = (p: Partial<FormState>) => {
    setOverride(null)
    setF((x) => ({ ...x, ...p }))
  }

  useEffect(() => {
    if (!tdPreset) return
    const d = tdPreset.decision
    setOverride(null)
    const g = (id: string) => state.goals.find((x) => x.id === id)
    if (d.kind === 'purchase') { setKind('purchase'); setF({ ...blank, label: d.label, amount: d.amount, day: d.day, category: d.category, necessity: d.necessity }) }
    else if (d.kind === 'subscription_cancel') { setKind(d.kind); setF({ ...blank, subId: d.subId }) }
    else if (d.kind === 'goal_adjust') { setKind(d.kind); setF({ ...blank, goalId: d.goalId, weekly: d.weekly, paused: d.paused || false }); void g }
    else if (d.kind === 'surprise') { setKind(d.kind); setF({ ...blank, label: d.label, amount: d.amount, day: d.day }) }
    else if (d.kind === 'income') { setKind(d.kind); setF({ ...blank, amount: d.amount, day: d.day, confidence: d.confidence }) }
    else if (d.kind === 'lifestyle_cut') { setKind(d.kind); setF({ ...blank, cutCategory: d.category, percent: d.percent }) }
    else if (d.kind === 'subscription_add') { setKind(d.kind); setF({ ...blank, subName: d.name, amount: d.amount, day: d.startDay, trialDays: d.trialDays }) }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [tdPreset])

  const decision = override?.decision ?? toDecision(kind, f, state)
  const key = JSON.stringify(decision)
  useEffect(() => {
    setPreview(decision)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [key])
  useEffect(() => () => setPreview(null), [setPreview])

  const cancel = () => {
    setOverride(null)
    setF(blank)
    setPreview(null)
  }
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => e.key === 'Escape' && !document.querySelector('[role="dialog"]') && cancel()
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  })

  const meta = KINDS.find((k) => k.id === kind)!
  const live = sim && decision && JSON.stringify(decision) === key ? sim : null
  const doCommit = () => {
    if (!decision) return
    setPulse((p) => p + 1)
    commit(decision)
    setConfirm(false)
    setOverride(null)
    setF(blank)
  }
  const onCta = () => (live?.verdict.level === 'nope' ? setConfirm(true) : doCommit())
  const pastDay = (decision?.kind === 'purchase' || decision?.kind === 'surprise' || decision?.kind === 'income') && decision.day < cd

  return (
    <div className="flex flex-col gap-xl pb-24 lg:pb-0">
      <div className="flex flex-col gap-xs">
        <Heading level={1}>Test drive</Heading>
        <p className="text-label-sm text-text-secondary">Try a decision first. Nothing is saved until you commit.</p>
      </div>
      <div className="scrollbar-none -mx-xl flex gap-sm overflow-x-auto px-xl lg:mx-0 lg:flex-wrap lg:px-0" role="group" aria-label="Decision type">
        {KINDS.map((k) => (
          <Chip key={k.id} selected={kind === k.id} onClick={() => { setKind(k.id); setOverride(null); setF(blank) }}>{k.label}</Chip>
        ))}
      </div>
      <section className="flex flex-col gap-lg rounded-corner-lg bg-surface-bg p-xl" aria-label={`${meta.label} inputs`}>
        <DecisionForm kind={kind} f={f} set={set} state={state} derived={derived} />
        {override && <p className="preview-edge rounded-corner-md px-md py-sm text-label-sm text-text-primary">Trying: {override.label}</p>}
        {pastDay && <p className="text-label-sm text-danger">Pick a day between {cd} and 30.</p>}
      </section>

      {decision && <PreviewBanner onCancel={cancel} outside={live?.outsideCycle} />}
      {decision && !live && <div className="h-24 animate-pulse rounded-corner-lg bg-bg-subtle" aria-label="Simulating" />}
      {live && (
        <div className={simPending ? 'opacity-60 transition-opacity' : 'transition-opacity'}>
          <div className="flex flex-col gap-xl">
            <VerdictBanner {...live.verdict} />
            <section className="flex flex-col gap-md rounded-corner-lg bg-surface-bg p-xl lg:hidden">
              <Heading level={3}>What moves</Heading>
              <ImpactGrid result={live} />
              <MoneyMap derived={live.before} after={live.after} compact />
            </section>
            {live.alternatives.length > 0 && (
              <section className="flex flex-col gap-md" aria-label="Alternatives">
                <Heading level={3}>Other ways to do this</Heading>
                {live.alternatives.map((a) => <AlternativeCard key={a.label} alt={a} before={live.before} onTry={() => setOverride({ label: a.label, decision: a.decision })} />)}
              </section>
            )}
            {live.tip && (
              <p className="flex items-start gap-sm rounded-corner-lg bg-bg-faint p-lg text-label-sm text-text-secondary">
                <Lightbulb size={18} className="shrink-0 text-text-primary" aria-hidden /> {live.tip}
              </p>
            )}
          </div>
        </div>
      )}
      {!decision && (
        <p className="rounded-corner-lg bg-bg-faint p-xl text-label-sm text-text-secondary">Set an amount or pick an option to see how it ripples through your month.</p>
      )}

      <div className="fixed inset-x-0 bottom-16 z-20 bg-brand-tertiary px-xl py-md lg:static lg:bg-transparent lg:p-0">
        <div className="relative mx-auto flex max-w-main justify-end gap-sm">
          <Button variant="subtle" onClick={cancel} disabled={!decision}>Clear</Button>
          <span className="relative">
            <Button variant="primary" onClick={onCta} disabled={!decision || !live || pastDay}>{meta.cta}</Button>
            {pulse > 0 && (
              <motion.span key={pulse} aria-hidden className="pointer-events-none absolute inset-0 rounded-corner-full border-2 border-money-preview" initial={{ scale: 1, opacity: 0.9 }} animate={{ scale: 1.6, opacity: 0 }} transition={{ duration: 0.6 }} />
            )}
          </span>
        </div>
      </div>

      <Modal isOpen={confirm} onClose={() => setConfirm(false)} title="This one is risky" size="small"
        footer={<><Button variant="neutral" onClick={() => setConfirm(false)}>Go back</Button><Button variant="primary" onClick={doCommit}>I understand</Button></>}>
        <p className="text-label text-text-secondary">{live?.verdict.reason} You can still go ahead, and Undo is there for 10 seconds.</p>
      </Modal>
    </div>
  )
}
