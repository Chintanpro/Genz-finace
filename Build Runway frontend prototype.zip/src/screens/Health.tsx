import { useState } from 'react'
import { Button, SwitchField, cn } from '@figma/astraui'
import type { Decision, HealthPart, RiskLevel } from '../types/finance'
import { useStore } from '../state/store'
import { scheduled } from '../lib/finance/ledger'
import { formatINR, formatPct } from '../lib/finance/format'
import { HEALTH_LABELS, HEALTH_WEIGHTS } from '../lib/finance/health'
import ForecastFan from '../components/ForecastFan'
import HealthRing from '../components/HealthRing'
import InsightCard from '../components/InsightCard'
import RiskChip from '../components/RiskChip'
import Card from '../components/ui/Card'
import Heading from '../components/ui/Heading'
import Pressable from '../components/ui/Pressable'

const BANDS: { level: RiskLevel; cls: string; label: string }[] = [
  { level: 'low', cls: 'bg-risk-low', label: 'Low' },
  { level: 'watch', cls: 'bg-risk-watch', label: 'Watch' },
  { level: 'high', cls: 'bg-risk-high', label: 'High' },
  { level: 'critical', cls: 'bg-risk-critical', label: 'Critical' },
]

export default function Health() {
  const { state, derived: d, openTestDrive, mutate } = useStore()
  const [, force] = useState(0)
  const cd = state.settings.currentDay
  const parts = Object.keys(HEALTH_WEIGHTS) as HealthPart[]
  const weakest = [...parts].sort((a, b) => d.health.parts[a] * HEALTH_WEIGHTS[b] - d.health.parts[b] * HEALTH_WEIGHTS[a])[0]
  const presets: Record<HealthPart, Decision | undefined> = {
    runway: { kind: 'lifestyle_cut', category: 'wants', percent: 20 },
    discipline: { kind: 'lifestyle_cut', category: 'wants', percent: 30 },
    commitment_load: state.subscriptions.find((s) => s.usage === 'low' && s.status !== 'cancelled') ? { kind: 'subscription_cancel', subId: state.subscriptions.find((s) => s.usage === 'low' && s.status !== 'cancelled')!.id } : undefined,
    savings_momentum: state.goals[0] ? { kind: 'goal_adjust', goalId: state.goals[0].id, weekly: state.goals[0].weekly + 50, paused: false } : undefined,
    risk_resilience: { kind: 'surprise', label: 'Dental visit', amount: 1200, day: cd },
    consistency: { kind: 'purchase', label: 'Chai', amount: 50, day: cd, category: 'food', necessity: 'need', payment: 'now' },
  }
  const lever = d.insights.find((i) => i.id === 'wants')
  const riskPct = d.forecast.pBelowZero
  const outflowDays = [...new Set(scheduled(state).map((s) => s.day))]
  const expected = state.incomes.filter((i) => i.status === 'expected')
  return (
    <div className="flex flex-col gap-xl">
      <Heading level={1}>Health</Heading>
      <section className="flex flex-col items-center gap-lg rounded-corner-lg bg-surface-bg p-2xl text-center sm:flex-row sm:text-left">
        <HealthRing score={d.health.score} band={d.health.band} size="lg" />
        <div className="flex flex-col gap-sm">
          <span className="text-title font-semibold tracking-display text-text-primary">{d.health.band}</span>
          <p className="text-label text-text-secondary">
            {lever ? `${lever.headline}. Trimming wants is your single biggest lever.` : `${HEALTH_LABELS[weakest].label} is the part with the most room to grow.`}
          </p>
        </div>
      </section>
      <Card title="What makes up your score">
        <ul className="flex flex-col">
          {parts.map((k) => (
            <li key={k}>
              <Pressable onClick={() => presets[k] && openTestDrive(presets[k])} className="flex min-h-touch w-full flex-col gap-xs border-b border-border-secondary py-md">
                <span className="flex items-center justify-between gap-md text-label-sm">
                  <span className="font-medium text-text-primary">{HEALTH_LABELS[k].label}</span>
                  <span className="tabular text-text-secondary"><span className="font-semibold text-text-primary">{d.health.parts[k]}</span> · weight {Math.round(HEALTH_WEIGHTS[k] * 100)}%</span>
                </span>
                <span className="h-2 overflow-hidden rounded-corner-full bg-bg-subtle" aria-hidden>
                  <span className="block h-full rounded-corner-full bg-money-goals" style={{ width: `${d.health.parts[k]}%` }} />
                </span>
                <span className="text-video-title text-text-secondary">{HEALTH_LABELS[k].hint}</span>
              </Pressable>
            </li>
          ))}
        </ul>
      </Card>
      <Card title="Risk" action={<RiskChip level={d.risk.level} />}>
        <div className="flex gap-0.5" role="img" aria-label={`Risk gauge: ${d.risk.level}`}>
          {BANDS.map((b) => (
            <span key={b.level} className={cn('flex h-10 flex-1 items-center justify-center text-video-title font-semibold first:rounded-l-corner-md last:rounded-r-corner-md', b.cls, b.level === 'critical' ? 'text-on-brand' : 'text-on-money', b.level !== d.risk.level && 'opacity-35')}>
              {b.label}
            </span>
          ))}
        </div>
        <p className="text-label text-text-primary">In about {formatPct(riskPct)} of simulated months you run out before Day 30.</p>
        {d.forecast.expectedZeroDay && riskPct >= 0.08 && <p className="text-label-sm text-text-secondary">You'd likely run out around Day {d.forecast.expectedZeroDay}.</p>}
      </Card>
      <Card title="Forecast" subtitle={`Likely to end around ${formatINR(d.forecast.p50)}, range ${formatINR(d.forecast.p10)} to ${formatINR(d.forecast.p90)}.`}>
        <ForecastFan forecast={d.forecast} reserve={d.reserve} today={cd} outflowDays={outflowDays} />
        <div className="grid grid-cols-1 gap-md sm:grid-cols-2">
          <SwitchField key={`s-${state.settings.surprises}`} label="Surprises" description="Random one-off costs in simulations." defaultSelected={state.settings.surprises}
            onChange={(on) => { mutate((s) => void (s.settings.surprises = on), on ? 'Surprises on.' : 'Surprises off.'); force((x) => x + 1) }} />
          <SwitchField key={`i-${expected.map((e) => e.countInBaseline).join()}`} label="Count expected income" description="Expected money lands at its confidence." defaultSelected={expected.some((e) => e.countInBaseline)}
            onChange={(on) => mutate((s) => s.incomes.forEach((i) => { if (i.status === 'expected') i.countInBaseline = on }), on ? 'Expected income counted.' : 'Expected income left out.')} />
        </div>
      </Card>
      <Card title="Shock absorber">
        <div className="h-3 overflow-hidden rounded-corner-full bg-bg-subtle" aria-hidden>
          <span className="block h-full rounded-corner-full bg-money-locked" style={{ width: `${Math.min(100, (d.maxAbsorbable / 5000) * 100)}%` }} />
        </div>
        <p className="text-label text-text-primary">A surprise up to <span className="tabular font-semibold">{formatINR(d.maxAbsorbable)}</span> today and you still more likely than not finish in the black.</p>
        <Button variant="neutral" className="self-start" onClick={() => openTestDrive({ kind: 'surprise', label: 'Dental visit', amount: 1200, day: cd })}>Stress test</Button>
      </Card>
      <Card title="Insights">
        {d.insights.length === 0 ? <p className="text-label-sm text-text-secondary">No rules are firing right now.</p> : d.insights.map((i) => <InsightCard key={i.id} insight={i} onTry={i.preset ? () => openTestDrive(i.preset) : undefined} />)}
      </Card>
    </div>
  )
}
