import { PiggyBank } from 'lucide-react'
import { useStore } from '../state/store'
import EmptyState from '../components/EmptyState'
import GoalCard from '../components/GoalCard'
import Heading from '../components/ui/Heading'

export default function Goals() {
  const { state, derived, openSheet } = useStore()
  return (
    <div className="flex flex-col gap-xl">
      <div className="flex flex-col gap-xs">
        <Heading level={1}>Goals</Heading>
        <p className="text-label-sm text-text-secondary">If money gets tight, goals slip from the bottom of this list first.</p>
      </div>
      {derived.goals.length === 0 ? (
        <EmptyState icon={<PiggyBank size={24} />} title="Pick something to save for. We'll show what it costs your daily allowance." />
      ) : (
        <div className="flex flex-col gap-md">
          {derived.goals.map((g, i) => (
            <GoalCard key={g.id} goal={g} priority={i + 1} currentDay={state.settings.currentDay} onOpen={() => openSheet({ kind: 'goal', goalId: g.id })} />
          ))}
        </div>
      )}
    </div>
  )
}
