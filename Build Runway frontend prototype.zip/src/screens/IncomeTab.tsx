import { Badge, Button, SwitchField } from '@figma/astraui'
import { useStore } from '../state/store'
import { formatINR, formatPct } from '../lib/finance/format'
import Card from '../components/ui/Card'

export default function IncomeTab() {
  const { state, mutate, openTestDrive } = useStore()
  const received = state.incomes.filter((i) => i.status === 'received')
  const expected = state.incomes.filter((i) => i.status === 'expected')
  return (
    <div className="flex flex-col gap-xl pt-lg">
      <Card title="Received">
        {received.map((i) => (
          <div key={i.id} className="flex items-center justify-between gap-md">
            <span className="flex flex-col gap-xs">
              <span className="text-label-sm font-medium text-text-primary">{i.name}</span>
              <span className="text-video-title text-text-secondary">Day {i.day}</span>
            </span>
            <span className="tabular text-label-sm font-semibold text-text-primary">{formatINR(i.amount)}</span>
          </div>
        ))}
      </Card>
      <Card title="Expected" subtitle="Expected money never raises your allowance until it lands." action={<Button variant="neutral" size="small" onClick={() => openTestDrive({ kind: 'income', amount: 1000, day: state.settings.currentDay, confidence: 0.6 })}>Add income</Button>}>
        {expected.length === 0 && <p className="text-label-sm text-text-secondary">Nothing expected right now.</p>}
        {expected.map((i) => (
          <div key={i.id} className="flex flex-col gap-sm rounded-corner-md bg-bg-faint p-lg">
            <div className="flex items-center justify-between gap-md">
              <span className="flex flex-col gap-xs">
                <span className="text-label-sm font-medium text-text-primary">{i.name}</span>
                <span className="flex items-center gap-sm text-video-title text-text-secondary">Day {i.day} <Badge label={`${formatPct(i.confidence)} likely`} variant="secondary" /></span>
              </span>
              <span className="tabular text-label-sm font-semibold text-text-primary">{formatINR(i.amount)}</span>
            </div>
            <SwitchField
              key={`${i.id}-${i.countInBaseline}`}
              label="Count in forecast"
              description="Lands in simulated months at its confidence."
              defaultSelected={i.countInBaseline}
              onChange={(on) => mutate((s) => { const x = s.incomes.find((y) => y.id === i.id); if (x) x.countInBaseline = on }, on ? 'Counted in forecast.' : 'Left out of forecast.')}
            />
          </div>
        ))}
      </Card>
    </div>
  )
}
