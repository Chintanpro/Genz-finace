import { CalendarDays, CarFront, Flag, Receipt, Sparkles, Zap } from 'lucide-react'
import { Badge, Button, cn } from '@figma/astraui'
import { useStore } from '../state/store'
import { comingUp, monthCells } from '../state/selectors'
import { formatINR, formatPct } from '../lib/finance/format'
import Amount from '../components/Amount'
import EmptyState from '../components/EmptyState'
import ForecastFan from '../components/ForecastFan'
import HealthRing from '../components/HealthRing'
import InsightCard from '../components/InsightCard'
import MoneyMap from '../components/MoneyMap'
import MonthStrip from '../components/MonthStrip'
import RiskChip from '../components/RiskChip'
import Card from '../components/ui/Card'
import Heading from '../components/ui/Heading'
import Pressable from '../components/ui/Pressable'

const TYPE_LABEL = { bill: 'Bill', subscription: 'Subscription', goal: 'Goal transfer', planned: 'Planned' }

export default function Today() {
  const { state, derived: d, preview, openSheet, openTestDrive, setTab } = useStore()
  const cd = state.settings.currentDay
  const upcoming = comingUp(state).slice(0, 5)
  const over = d.leftToday < 0
  return (
    <div className="flex flex-col gap-xl">
      {d.wallet < 0 && (
        <div role="alert" className="flex items-center justify-between gap-md rounded-corner-lg bg-money-danger p-xl text-on-brand">
          <span className="text-label font-semibold">You're {formatINR(-d.wallet)} in the red. Test drive a fix below.</span>
          <Button variant="neutral" size="small" onClick={() => openTestDrive({ kind: 'lifestyle_cut', category: 'wants', percent: 30 })}>
            Test drive
          </Button>
        </div>
      )}
      <section className="flex flex-col gap-lg rounded-corner-lg bg-surface-bg p-xl lg:p-2xl" aria-labelledby="left-today">
        <div className="flex items-start justify-between gap-lg">
          <div className="flex min-w-0 flex-col gap-sm">
            <span id="left-today" className="text-label text-text-secondary">{over ? 'Over today by' : 'Left today'}</span>
            <Amount value={over ? -d.leftToday : d.leftToday} className={cn('text-numeral-xl font-semibold tracking-display', over ? 'text-danger' : 'text-text-primary')} iconSize={32} />
            <span className="text-label text-text-secondary">
              <span className="tabular font-semibold text-text-primary">{formatINR(d.dailyAllowance)}</span> a day for the next {d.daysLeft} days
            </span>
          </div>
          <Pressable onClick={() => setTab('health')} className="flex shrink-0 flex-col items-end gap-sm rounded-corner-md p-xs" aria-label={`Risk ${d.risk.level}, health ${d.health.score}. Open Health`}>
            <RiskChip level={d.risk.level} />
            <HealthRing score={d.health.score} band={d.health.band} />
          </Pressable>
        </div>
        {d.spentToday === 0 && <p className="text-label-sm text-text-secondary">Nothing logged today. Log an expense and watch your allowance update.</p>}
      </section>

      <section className="flex flex-col gap-lg rounded-corner-lg bg-surface-bg p-xl" aria-labelledby="mm-title">
        <div className="flex items-baseline justify-between gap-md">
          <Heading level={3} id="mm-title">Where your {formatINR(d.moneyTotal)} is</Heading>
          <span className="text-label-sm text-text-secondary">Tap a block</span>
        </div>
        <MoneyMap derived={d} onSegment={(key) => openSheet({ kind: 'segment', key })} />
      </section>

      <div className="grid grid-cols-1 gap-sm sm:grid-cols-3">
        <Button variant="primary" iconStart={<Receipt size={16} />} onClick={() => openSheet({ kind: 'log' })}>Log expense</Button>
        <Button variant="neutral" iconStart={<CarFront size={16} />} onClick={() => openTestDrive()}>Test drive</Button>
        <Button variant="neutral" iconStart={<Zap size={16} />} onClick={() => openSheet({ kind: 'life' })}>Life happens</Button>
      </div>

      <Card title="When money moves" subtitle="Past days fill by spend against your daily pace.">
        <MonthStrip cells={monthCells(state, d, preview)} onDay={(day) => openSheet({ kind: 'day', day })} />
        <ul className="flex flex-wrap gap-x-lg gap-y-xs text-video-title text-text-secondary" aria-hidden>
          <li className="flex items-center gap-xs"><span className="size-2 rounded-corner-full bg-money-locked" />Bill</li>
          <li className="flex items-center gap-xs"><span className="size-2 rounded-corner-full border border-money-locked" />Subscription</li>
          <li className="flex items-center gap-xs"><span className="font-semibold text-money-goals">+</span>Goal transfer</li>
          <li className="flex items-center gap-xs"><Flag size={10} className="text-danger" />Trial converts</li>
          <li className="flex items-center gap-xs"><span className="size-2 rounded-corner-full bg-money-free" />Expected income</li>
        </ul>
      </Card>

      <div className="grid grid-cols-1 gap-xl md:grid-cols-2">
        <Card title="Coming up" subtitle="Next 7 days">
          {upcoming.length === 0 ? (
            <EmptyState icon={<CalendarDays size={20} />} title="Nothing due this week" body="No bills, renewals or goal transfers in the next 7 days." />
          ) : (
            <ul className="flex flex-col">
              {upcoming.map((u) => (
                <li key={`${u.id}-${u.day}`} className={cn('flex items-center justify-between gap-md border-b border-border-secondary py-md last:border-b-0', u.trial && 'rounded-corner-md border-b-0 bg-money-free px-md text-on-money')}>
                  <span className="flex min-w-0 flex-col gap-xs">
                    <span className="truncate text-label-sm font-medium">{u.name}</span>
                    <span className={cn('text-video-title', u.trial ? 'text-on-money' : 'text-text-secondary')}>{u.day === cd ? 'Today' : `Day ${u.day}`} · {u.trial ? 'Trial converts' : TYPE_LABEL[u.type]}</span>
                    {u.trial && (
                      <Button variant="neutral" size="small" className="mt-xs self-start" onClick={() => openTestDrive({ kind: 'subscription_cancel', subId: u.id })}>
                        Cancel before it converts
                      </Button>
                    )}
                  </span>
                  <span className="tabular text-label-sm font-semibold">{formatINR(u.amount)}</span>
                </li>
              ))}
            </ul>
          )}
        </Card>
        <Card title="Month-end forecast">
          <ForecastFan forecast={d.forecast} mini />
          <p className="text-label text-text-primary">Likely to end around <span className="tabular font-semibold">{formatINR(d.forecast.p50)}</span></p>
          <p className="text-label-sm text-text-secondary">Range {formatINR(d.forecast.p10)} to {formatINR(d.forecast.p90)}. Chance of running out: {formatPct(d.forecast.pBelowZero)}.</p>
        </Card>
      </div>

      {d.insights.length > 0 && (
        <Card title="Worth a look" action={<Badge label={`${Math.min(3, d.insights.length)} of ${d.insights.length}`} variant="secondary" />}>
          {d.insights.slice(0, 3).map((ins, i) => (
            <InsightCard key={ins.id} insight={ins} emoji={i === 0 ? '👀' : undefined} onTry={ins.preset ? () => openTestDrive(ins.preset) : undefined} />
          ))}
        </Card>
      )}
      {d.insights.length === 0 && <EmptyState icon={<Sparkles size={20} />} title="Nothing needs you right now" body="Nudges show up here when a trial is about to convert or a category runs hot." />}
    </div>
  )
}
