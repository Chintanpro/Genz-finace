import { InputField, SelectField, SwitchField } from '@figma/astraui'
import type { AppState, Category, Decision, Derived } from '../types/finance'
import { formatINR } from '../lib/finance/format'
import { categoryLabel } from '../lib/finance/insights'
import { CATEGORIES } from '../lib/finance/ledger'
import AmountInput from '../components/AmountInput'
import Chip from '../components/ui/Chip'
import Range from '../components/ui/Range'

export type Kind = 'purchase' | 'subscription_add' | 'subscription_cancel' | 'goal_adjust' | 'surprise' | 'income' | 'lifestyle_cut'

export interface FormState {
  label: string
  amount: number
  day: number
  category: Category
  necessity: 'need' | 'want'
  subName: string
  trialDays: number
  subId: string
  goalId: string
  weekly: number
  paused: boolean
  confidence: number
  cutCategory: Category | 'wants'
  percent: number
}

export const SURPRISES = [
  { label: 'Phone screen repair', amount: 2500 },
  { label: 'Dental visit', amount: 1200 },
  { label: "Friend's gift", amount: 800 },
  { label: 'Bike service', amount: 600 },
]

export function toDecision(kind: Kind, f: FormState, state: AppState): Decision | null {
  switch (kind) {
    case 'purchase':
      return f.amount > 0 ? { kind, label: f.label || 'Purchase', amount: f.amount, day: f.day, category: f.category, necessity: f.necessity, payment: 'now' } : null
    case 'subscription_add':
      return f.amount > 0 ? { kind, name: f.subName || 'New subscription', amount: f.amount, startDay: f.day, trialDays: f.trialDays } : null
    case 'subscription_cancel':
      return state.subscriptions.some((s) => s.id === f.subId) ? { kind, subId: f.subId } : null
    case 'goal_adjust':
      return state.goals.some((g) => g.id === f.goalId) ? { kind, goalId: f.goalId, weekly: f.weekly, paused: f.paused } : null
    case 'surprise':
      return f.amount > 0 ? { kind, label: f.label || 'Surprise expense', amount: f.amount, day: f.day } : null
    case 'income':
      return f.amount > 0 ? { kind, amount: f.amount, day: f.day, confidence: f.confidence } : null
    case 'lifestyle_cut':
      return { kind, category: f.cutCategory, percent: f.percent }
  }
}

function DaySelect({ value, onChange, state, allowNext = true }: { value: number; onChange: (d: number) => void; state: AppState; allowNext?: boolean }) {
  const { currentDay: cd, cycleDays } = state.settings
  const opts = Array.from({ length: cycleDays - cd + 1 }, (_, i) => ({ value: String(cd + i), label: i === 0 ? `Today, Day ${cd}` : `Day ${cd + i}` }))
  if (allowNext) opts.push({ value: '31', label: 'Next cycle' })
  return <SelectField label="When" options={opts} value={String(value)} onChange={(v) => onChange(Number(v))} />
}

function Row({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="flex flex-col gap-sm">
      <span className="text-label-sm font-medium text-text-primary">{label}</span>
      <div className="flex flex-wrap gap-sm">{children}</div>
    </div>
  )
}

export default function DecisionForm({ kind, f, set, state, derived }: { kind: Kind; f: FormState; set: (p: Partial<FormState>) => void; state: AppState; derived: Derived }) {
  const cd = state.settings.currentDay
  switch (kind) {
    case 'purchase':
      return (
        <>
          <InputField label="What is it" placeholder="Concert ticket, earbuds, dinner out" value={f.label} onChange={(v) => set({ label: v })} />
          <AmountInput value={f.amount} onChange={(amount) => set({ amount })} />
          <DaySelect value={f.day} onChange={(day) => set({ day })} state={state} />
          <Row label="Category">
            {CATEGORIES.map((c) => <Chip key={c} selected={f.category === c} onClick={() => set({ category: c })}>{categoryLabel(c)}</Chip>)}
          </Row>
          <Row label="Need or want">
            <Chip selected={f.necessity === 'need'} onClick={() => set({ necessity: 'need' })}>Need</Chip>
            <Chip selected={f.necessity === 'want'} onClick={() => set({ necessity: 'want' })}>Want</Chip>
          </Row>
        </>
      )
    case 'subscription_add':
      return (
        <>
          <InputField label="Name" placeholder="Language app, cloud storage" value={f.subName} onChange={(v) => set({ subName: v })} />
          <AmountInput label="Monthly price" value={f.amount} onChange={(amount) => set({ amount })} max={1000} quick={[49, 99, 149, 299]} step={10} />
          <DaySelect value={f.day} onChange={(day) => set({ day })} state={state} allowNext={false} />
          <Row label="Free trial">
            {[0, 7, 14, 30].map((t) => <Chip key={t} selected={f.trialDays === t} onClick={() => set({ trialDays: t })}>{t === 0 ? 'None' : `${t} days`}</Chip>)}
          </Row>
        </>
      )
    case 'subscription_cancel': {
      const subs = state.subscriptions.filter((s) => s.status === 'active' || s.status === 'trial')
      const pick = subs.find((s) => s.id === f.subId)
      const renews = pick && pick.renewDay >= cd && !state.transactions.some((t) => t.sourceId === pick.id)
      return (
        <>
          <Row label="Which one">
            {subs.map((s) => <Chip key={s.id} selected={f.subId === s.id} onClick={() => set({ subId: s.id })}>{s.name.split(',')[0]} · {formatINR(s.amount)}</Chip>)}
          </Row>
          {pick && (
            <p className="text-label-sm text-text-secondary">
              {renews ? `It renews on Day ${pick.renewDay}, so cancelling keeps ${formatINR(pick.amount)} with you this cycle.` : `Already paid this cycle, so this saves ₹0 now and ${formatINR(pick.amount)} a month from next cycle. Nothing is refunded.`}
            </p>
          )}
        </>
      )
    }
    case 'goal_adjust': {
      const g = derived.goals.find((x) => x.id === f.goalId)
      return (
        <>
          <Row label="Goal">
            {state.goals.map((x) => <Chip key={x.id} selected={f.goalId === x.id} onClick={() => set({ goalId: x.id, weekly: x.weekly, paused: x.paused })}>{x.name}</Chip>)}
          </Row>
          <div className="flex flex-col gap-xs">
            <span className="flex justify-between text-label-sm font-medium text-text-primary">Weekly amount <span className="tabular">{formatINR(f.weekly)}</span></span>
            <Range label="Weekly amount" min={0} max={500} step={10} value={f.weekly} onChange={(weekly) => set({ weekly })} valueText={formatINR(f.weekly)} />
            {g && <span className="text-label-sm text-text-secondary">Needed per week to hit the deadline: {formatINR(g.requiredWeekly)}</span>}
          </div>
          <SwitchField key={f.goalId} label="Pause this goal" description="Contributions stop until you resume." defaultSelected={f.paused} onChange={(paused) => set({ paused })} />
        </>
      )
    }
    case 'surprise':
      return (
        <>
          <Row label="What happened">
            {SURPRISES.map((s) => <Chip key={s.label} selected={f.label === s.label} onClick={() => set({ label: s.label, amount: s.amount })}>{s.label} · {formatINR(s.amount)}</Chip>)}
            <Chip selected={!SURPRISES.some((s) => s.label === f.label)} onClick={() => set({ label: '', amount: 0 })}>Custom</Chip>
          </Row>
          {!SURPRISES.some((s) => s.label === f.label) && (
            <>
              <InputField label="Label" placeholder="Laptop charger" value={f.label} onChange={(v) => set({ label: v })} />
              <AmountInput value={f.amount} onChange={(amount) => set({ amount })} />
            </>
          )}
          <DaySelect value={f.day} onChange={(day) => set({ day })} state={state} />
        </>
      )
    case 'income':
      return (
        <>
          <AmountInput value={f.amount} onChange={(amount) => set({ amount })} quick={[500, 1000, 1500, 2000]} />
          <DaySelect value={f.day} onChange={(day) => set({ day })} state={state} />
          <Row label="How sure are you">
            {[{ v: 1, l: 'Confirmed' }, { v: 0.6, l: 'Likely, 60%' }, { v: 0.3, l: 'Long shot, 30%' }].map((o) => <Chip key={o.v} selected={f.confidence === o.v} onClick={() => set({ confidence: o.v })}>{o.l}</Chip>)}
          </Row>
        </>
      )
    case 'lifestyle_cut':
      return (
        <>
          <Row label="Cut back on">
            <Chip selected={f.cutCategory === 'wants'} onClick={() => set({ cutCategory: 'wants' })}>All wants</Chip>
            {CATEGORIES.map((c) => <Chip key={c} selected={f.cutCategory === c} onClick={() => set({ cutCategory: c })}>{categoryLabel(c)}</Chip>)}
          </Row>
          <div className="flex flex-col gap-xs">
            <span className="flex justify-between text-label-sm font-medium text-text-primary">Cut for the remaining days <span className="tabular">{f.percent}%</span></span>
            <Range label="Cut percent" min={10} max={60} step={5} value={f.percent} onChange={(percent) => set({ percent })} valueText={`${f.percent}%`} />
          </div>
        </>
      )
  }
}
