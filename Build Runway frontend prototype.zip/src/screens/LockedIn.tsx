import { useState } from 'react'
import { ChevronDown, Flag } from 'lucide-react'
import { Badge, Button, cn } from '@figma/astraui'
import { useStore } from '../state/store'
import { formatINR, formatPct } from '../lib/finance/format'
import Card from '../components/ui/Card'
import Pressable from '../components/ui/Pressable'

const C_STATUS = { paid: 'success', upcoming: 'default', failed: 'danger', deferred: 'warning' } as const
const USAGE_DOT = { high: 'bg-money-goals', medium: 'bg-money-free', low: 'bg-money-danger' }

export default function LockedIn() {
  const { state, derived, openTestDrive } = useStore()
  const [open, setOpen] = useState<string | null>(null)
  const cd = state.settings.currentDay
  const budget = state.settings.budget
  return (
    <div className="flex flex-col gap-xl pt-lg">
      <div className="flex flex-col gap-xs rounded-corner-lg bg-surface-bg p-xl">
        <span className="text-heading font-semibold text-text-primary">
          Locked in {formatINR(derived.locked.total)} of {formatINR(budget)} ({formatPct(derived.locked.total / budget)})
        </span>
        <span className="text-label-sm text-text-secondary">Subscriptions take {formatPct(derived.subscriptionCycleTotal / budget)} of your budget this cycle.</span>
      </div>
      <Card title="Commitments">
        <ul className="flex flex-col">
          {state.commitments.map((c) => {
            const inst = c.name.match(/instalment (\d) of (\d)/)
            return (
              <li key={c.id} className="flex items-center justify-between gap-md border-b border-border-secondary py-md last:border-b-0">
                <span className="flex min-w-0 flex-col gap-xs">
                  <span className="text-label-sm font-medium text-text-primary">{c.name}</span>
                  <span className="flex flex-wrap items-center gap-sm text-video-title text-text-secondary">
                    Due Day {c.dueDay}
                    <Badge label={c.status} variant={C_STATUS[c.status]} />
                    {c.flexible && <Badge label="flexible" variant="secondary" />}
                  </span>
                  {inst && (
                    <span className="flex gap-xs" aria-label={`Instalment ${inst[1]} of ${inst[2]}`}>
                      {Array.from({ length: Number(inst[2]) }, (_, i) => <span key={i} className={cn('h-1 w-6 rounded-corner-full', i < Number(inst[1]) - (c.status === 'paid' ? 0 : 1) ? 'bg-money-locked' : 'bg-bg-hover')} />)}
                    </span>
                  )}
                </span>
                <span className="tabular text-label-sm font-semibold text-text-primary">{formatINR(c.amount)}</span>
              </li>
            )
          })}
        </ul>
      </Card>
      <Card title="Subscriptions">
        <ul className="flex flex-col gap-sm">
          {state.subscriptions.map((s) => {
            const live = s.status === 'active' || s.status === 'trial'
            const days = s.renewDay - cd
            return (
              <li key={s.id} className="flex flex-col rounded-corner-md bg-bg-faint">
                {s.status === 'trial' && days >= 0 && (
                  <span className="flex items-center gap-sm rounded-t-corner-md bg-money-free px-lg py-sm text-label-sm font-medium text-on-money">
                    <Flag size={14} aria-hidden /> Trial converts {days === 0 ? 'today' : `in ${days} day${days === 1 ? '' : 's'}`} for {formatINR(s.amount)}
                  </span>
                )}
                <Pressable onClick={() => setOpen(open === s.id ? null : s.id)} aria-expanded={open === s.id} className="flex min-h-touch items-center justify-between gap-md px-lg py-md">
                  <span className="flex min-w-0 flex-col gap-xs">
                    <span className="flex items-center gap-sm text-label-sm font-medium text-text-primary">
                      <span className={cn('size-2 rounded-corner-full', USAGE_DOT[s.usage])} aria-label={`${s.usage} use`} />
                      {s.name}
                    </span>
                    <span className="flex flex-wrap items-center gap-sm text-video-title text-text-secondary">
                      {live ? `Renews on Day ${s.renewDay}` : s.status === 'cancelled' ? 'Cancelled' : 'Paused'}
                      {s.usage === 'low' && live && <Badge label="low use" variant="warning" />}
                    </span>
                  </span>
                  <span className="flex items-center gap-sm">
                    <span className="tabular text-label-sm font-semibold text-text-primary">{formatINR(s.amount)}</span>
                    <ChevronDown size={16} className={cn('text-text-secondary', open === s.id && 'rotate-180')} aria-hidden />
                  </span>
                </Pressable>
                {open === s.id && (
                  <div className="flex flex-wrap items-center justify-between gap-md px-lg pb-md">
                    <span className="text-label-sm text-text-secondary">{formatINR(s.amount * 12)} a year{s.note ? ` · ${s.note}` : ''}</span>
                    {live && (
                      <span className="flex gap-sm">
                        <Button variant="neutral" size="small" onClick={() => openTestDrive({ kind: 'subscription_cancel', subId: s.id })}>Cancel</Button>
                      </span>
                    )}
                  </div>
                )}
              </li>
            )
          })}
        </ul>
      </Card>
    </div>
  )
}
