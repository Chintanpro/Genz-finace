import { useState, type ReactNode } from 'react'
import { ChevronDown } from 'lucide-react'
import { cn } from '@figma/astraui'
import Pressable from './ui/Pressable'

export default function ImpactRow({ title, now, after, chip, line, children, preview = true }: {
  title: string; now: ReactNode; after: ReactNode; chip: ReactNode; line: string; children?: ReactNode; preview?: boolean
}) {
  const [open, setOpen] = useState(false)
  return (
    <div className="border-b border-border-secondary last:border-b-0">
      <Pressable onClick={() => setOpen((o) => !o)} aria-expanded={open} className="flex min-h-touch w-full flex-col gap-xs py-lg">
        <span className="flex w-full items-center justify-between gap-md">
          <span className="text-label-sm font-medium text-text-secondary">{title}</span>
          <span className="flex items-center gap-sm">
            {chip}
            <ChevronDown size={16} aria-hidden className={cn('text-text-secondary transition-transform', open && 'rotate-180')} />
          </span>
        </span>
        <span className="flex flex-wrap items-center gap-sm text-label font-semibold text-text-primary">
          <span className="tabular">{now}</span>
          <span aria-hidden className="text-text-tertiary">to</span>
          <span className={cn('tabular rounded-corner-sm px-xs', preview && 'preview-edge')}>{after}</span>
        </span>
        <span className="text-label-sm text-text-secondary">{line}</span>
      </Pressable>
      {open && children && <div className="flex flex-col gap-sm pb-lg">{children}</div>}
    </div>
  )
}
