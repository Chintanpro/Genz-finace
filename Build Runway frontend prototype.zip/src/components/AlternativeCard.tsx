import { Button } from '@figma/astraui'
import type { Alternative, Derived } from '../types/finance'
import DeltaChip from './DeltaChip'
import { VerdictChip } from './VerdictBanner'

export default function AlternativeCard({ alt, before, onTry }: { alt: Alternative; before: Derived; onTry: () => void }) {
  const deltas = [
    { label: 'Daily allowance', v: alt.after.dailyAllowance - before.dailyAllowance, unit: 'money' as const, scale: 10 },
    { label: 'Month end', v: alt.after.forecast.p50 - before.forecast.p50, unit: 'money' as const, scale: 1 },
    { label: 'Chance of running out', v: (alt.after.forecast.pBelowZero - before.forecast.pBelowZero) * 100, unit: 'pct' as const, scale: 20, inverse: true },
    { label: 'Health', v: alt.after.health.score - before.health.score, unit: 'points' as const, scale: 20 },
  ]
    .filter((d) => Math.round(d.v) !== 0)
    .sort((a, b) => Math.abs(b.v * b.scale) - Math.abs(a.v * a.scale))
    .slice(0, 2)
  return (
    <div className="preview-edge flex flex-col gap-md rounded-corner-lg p-lg">
      <div className="flex items-start justify-between gap-md">
        <span className="text-label font-semibold text-text-primary">{alt.label}</span>
        <VerdictChip level={alt.verdictLevel} />
      </div>
      <div className="flex flex-wrap gap-md">
        {deltas.map((d) => (
          <span key={d.label} className="flex items-center gap-xs text-label-sm text-text-secondary">
            {d.label} <DeltaChip delta={d.v} unit={d.unit} higherIsBetter={!d.inverse} />
          </span>
        ))}
        {deltas.length === 0 && <span className="text-label-sm text-text-secondary">Same numbers as now.</span>}
      </div>
      <Button variant="neutral" size="small" className="self-start" onClick={onTry}>
        Try this
      </Button>
    </div>
  )
}
