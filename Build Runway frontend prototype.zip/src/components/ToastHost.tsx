import { Button, Toast } from '@figma/astraui'
import type { ToastItem } from '../state/store'

export default function ToastHost({ toasts, onUndo, onDismiss }: { toasts: ToastItem[]; onUndo: (id: string) => void; onDismiss: (id: string) => void }) {
  return (
    <div className="pointer-events-none fixed inset-x-0 bottom-24 z-50 flex flex-col items-center gap-sm px-xl lg:bottom-2xl" aria-live="polite">
      {toasts.map((t) => (
        <div key={t.id} className="pointer-events-auto flex items-center gap-sm">
          <Toast message={t.message} variant={t.tone === 'warning' ? 'warning' : 'success'} progress={100} showCancel={false} onDismiss={() => onDismiss(t.id)} />
          {t.undo && (
            <Button variant="neutral" size="small" onClick={() => onUndo(t.id)}>
              Undo
            </Button>
          )}
        </div>
      ))}
    </div>
  )
}
