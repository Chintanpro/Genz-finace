import { ArrowDown, ArrowUp, Minus } from 'lucide-react'
import { motion } from 'motion/react'
import { cn } from '@figma/astraui'
import { formatSigned } from '../lib/finance/format'

type Unit = 'money' | 'points' | 'pct' | 'days'

function text(delta: number, unit: Unit) {
  const r = Math.round(delta)
  const sign = r > 0 ? '+' : r < 0 ? '−' : ''
  if (unit === 'money') return formatSigned(delta)
  if (unit === 'pct') return `${sign}${Math.abs(r)} pts`
  if (unit === 'days') return Math.abs(r) >= 999 ? 'No date' : `${sign}${Math.abs(r)} d`
  return `${sign}${Math.abs(r)}`
}

/** Shared vocabulary for change: sign, arrow icon and colour. */
export default function DeltaChip({ delta, unit = 'money', higherIsBetter = true, className }: { delta: number; unit?: Unit; higherIsBetter?: boolean; className?: string }) {
  const r = Math.round(delta)
  const good = r === 0 ? null : (r > 0) === higherIsBetter
  const Icon = r > 0 ? ArrowUp : r < 0 ? ArrowDown : Minus
  return (
    <motion.span
      initial={{ scale: 0.85, opacity: 0 }}
      animate={{ scale: 1, opacity: 1 }}
      transition={{ duration: 0.24 }}
      className={cn(
        'tabular inline-flex shrink-0 items-center gap-xs rounded-corner-full px-md py-xs text-label-sm font-semibold',
        good === null ? 'bg-bg-subtle text-text-secondary' : good ? 'bg-money-goals text-on-money' : 'bg-money-danger text-on-brand',
        className,
      )}
    >
      <Icon size={14} strokeWidth={2} aria-hidden />
      <span>{text(delta, unit)}</span>
      <span className="sr-only">{good === null ? 'no change' : good ? 'better' : 'worse'}</span>
    </motion.span>
  )
}
