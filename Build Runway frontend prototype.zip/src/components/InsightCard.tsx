import { Button } from '@figma/astraui'
import { cn } from '@figma/astraui'
import type { Insight } from '../types/finance'

const EMOJI_FREE_ICON = { warn: 'bg-money-free', win: 'bg-money-goals', tip: 'bg-money-paid' }

export default function InsightCard({ insight, onTry, emoji }: { insight: Insight; onTry?: () => void; emoji?: string }) {
  return (
    <div className="flex items-start gap-lg rounded-corner-lg bg-bg-faint p-lg">
      <span className={cn('mt-xs size-3 shrink-0 rounded-corner-full', EMOJI_FREE_ICON[insight.tone])} aria-hidden />
      <div className="flex min-w-0 flex-1 flex-col gap-xs">
        <p className="text-label font-semibold text-text-primary">
          {emoji && <span aria-hidden>{emoji} </span>}
          {insight.headline}
        </p>
        <p className="text-label-sm text-text-secondary">{insight.detail}</p>
      </div>
      {insight.preset && onTry && (
        <Button variant="neutral" size="small" onClick={onTry}>
          Test drive
        </Button>
      )}
    </div>
  )
}
