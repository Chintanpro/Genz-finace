import { Minus, Plus } from 'lucide-react'
import { IconButton, InputField } from '@figma/astraui'
import { clampAmount, formatINR } from '../lib/finance/format'
import Chip from './ui/Chip'
import Range from './ui/Range'

export default function AmountInput({ value, onChange, label = 'Amount', max = 5000, quick = [100, 250, 500, 1000], step = 50 }: {
  value: number; onChange: (v: number) => void; label?: string; max?: number; quick?: number[]; step?: number
}) {
  const set = (v: number) => onChange(clampAmount(v))
  return (
    <div className="flex flex-col gap-md">
      <div className="flex items-end gap-sm">
        <IconButton icon={<Minus size={16} />} variant="neutral" aria-label={`Decrease by ${formatINR(step)}`} onClick={() => set(value - step)} />
        <InputField
          className="flex-1"
          label={label}
          prefix="₹"
          inputMode="numeric"
          value={value ? String(value) : ''}
          placeholder="0"
          onChange={(v) => set(Number(v.replace(/[^0-9]/g, '')))}
        />
        <IconButton icon={<Plus size={16} />} variant="neutral" aria-label={`Increase by ${formatINR(step)}`} onClick={() => set(value + step)} />
      </div>
      <Range label={label} min={0} max={max} step={step} value={Math.min(value, max)} onChange={set} valueText={formatINR(value)} />
      <div className="flex flex-wrap gap-sm">
        {quick.map((q) => (
          <Chip key={q} selected={value === q} onClick={() => set(q)}>
            {formatINR(q)}
          </Chip>
        ))}
      </div>
      {value <= 0 && <p className="text-label-sm text-danger">Enter an amount above ₹0.</p>}
    </div>
  )
}
