import { useEffect, useRef, useState } from 'react'
import { Area, ComposedChart, Line, ReferenceLine, Tooltip, XAxis, YAxis } from 'recharts'
import type { Forecast } from '../types/finance'
import { formatINR } from '../lib/finance/format'

interface Props {
  forecast: Forecast
  scenario?: Forecast | null
  reserve?: number
  today?: number
  outflowDays?: number[]
  mini?: boolean
}

export default function ForecastFan({ forecast, scenario, reserve, today, outflowDays = [], mini }: Props) {
  const data = forecast.path.map((p, i) => ({ day: p.day, band: [p.p10, p.p90], p50: p.p50, s50: scenario?.path[i]?.p50 }))
  const label = `Forecast: likely to end around ${formatINR(forecast.p50)}, range ${formatINR(forecast.p10)} to ${formatINR(forecast.p90)}${scenario ? `. With this decision around ${formatINR(scenario.p50)}` : ''}.`
  const ref = useRef<HTMLDivElement>(null)
  const [size, setSize] = useState({ w: 0, h: 0 })
  useEffect(() => {
    const el = ref.current
    if (!el) return
    const ro = new ResizeObserver(([e]) => setSize({ w: Math.floor(e.contentRect.width), h: Math.floor(e.contentRect.height) }))
    ro.observe(el)
    return () => ro.disconnect()
  }, [])
  return (
    <div ref={ref} role="img" aria-label={label} className={mini ? 'h-16 w-full min-w-0' : 'h-56 w-full min-w-0'}>
      {size.w > 0 && size.h > 0 && (
        <ComposedChart width={size.w} height={size.h} data={data} margin={{ top: 4, right: 4, bottom: 0, left: mini ? 4 : 0 }}>
          {!mini && <XAxis dataKey="day" tickLine={false} axisLine={false} tick={{ fontSize: 12, fill: 'var(--text-secondary)' }} interval="preserveStartEnd" />}
          {!mini && <YAxis tickLine={false} axisLine={false} width={48} tick={{ fontSize: 12, fill: 'var(--text-secondary)' }} tickFormatter={(v: number) => formatINR(v)} />}
          {!mini && <Tooltip formatter={(v: number | number[]) => (Array.isArray(v) ? `${formatINR(v[0])} to ${formatINR(v[1])}` : formatINR(v))} labelFormatter={(d) => `Day ${d}`} />}
          <Area dataKey="band" stroke="none" fill="var(--money-locked)" fillOpacity={0.14} isAnimationActive={false} />
          <ReferenceLine y={0} stroke="var(--border-primary)" />
          {reserve !== undefined && !mini && <ReferenceLine y={reserve} stroke="var(--text-secondary)" strokeDasharray="2 4" label={{ value: 'Safety reserve', fontSize: 11, fill: 'var(--text-secondary)', position: 'insideTopRight' }} />}
          {today !== undefined && !mini && <ReferenceLine x={today} stroke="var(--border-selected)" />}
          {!mini && outflowDays.map((d) => <ReferenceLine key={d} x={d} stroke="var(--money-locked)" strokeOpacity={0.25} />)}
          <Line dataKey="p50" stroke="var(--money-locked)" strokeWidth={2} dot={false} isAnimationActive={false} />
          {scenario && <Line dataKey="s50" stroke="var(--money-preview)" strokeWidth={2.5} strokeDasharray="6 4" dot={false} isAnimationActive={false} />}
        </ComposedChart>
      )}
    </div>
  )
}
