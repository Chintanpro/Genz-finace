import { motion } from 'motion/react'
import { cn } from '@figma/astraui'
import { useReducedMotion } from '../hooks/useReducedMotion'

export default function HealthRing({ score, band, size = 'md', preview }: { score: number; band?: string; size?: 'sm' | 'md' | 'lg'; preview?: boolean }) {
  const reduced = useReducedMotion()
  const r = 42
  const c = 2 * Math.PI * r
  const frac = Math.max(0, Math.min(100, score)) / 100
  const dims = { sm: 'size-12', md: 'size-16', lg: 'size-40' }[size]
  const textCls = { sm: 'text-label-sm', md: 'text-label', lg: 'text-numeral-l' }[size]
  return (
    <div className={cn('relative shrink-0', dims)} role="img" aria-label={`Health score ${score} of 100${band ? `, ${band}` : ''}`}>
      <svg viewBox="0 0 100 100" className="size-full -rotate-90">
        <circle cx="50" cy="50" r={r} fill="none" strokeWidth="10" className="stroke-bg-subtle" />
        <motion.circle
          cx="50" cy="50" r={r} fill="none" strokeWidth="10" strokeLinecap="round"
          strokeDasharray={preview ? '6 6' : c}
          className={preview ? 'stroke-money-preview' : 'stroke-money-goals'}
          initial={false}
          animate={{ strokeDashoffset: preview ? 0 : c * (1 - frac) }}
          transition={{ duration: reduced ? 0 : 0.48, ease: 'easeOut' }}
        />
      </svg>
      <span className={cn('tabular absolute inset-0 flex items-center justify-center font-semibold text-text-primary', textCls)}>{score}</span>
    </div>
  )
}
