import { cn } from '@figma/astraui'

/** Native range input styled with Astra tokens; arrow keys work out of the box. */
export default function Range({ value, min, max, step = 1, onChange, label, className, valueText }: {
  value: number; min: number; max: number; step?: number; onChange: (v: number) => void; label: string; className?: string; valueText?: string
}) {
  return (
    <input
      type="range"
      aria-label={label}
      aria-valuetext={valueText}
      min={min}
      max={max}
      step={step}
      value={value}
      onChange={(e) => onChange(Number(e.target.value))}
      className={cn('h-touch w-full cursor-pointer accent-brand-primary', className)}
    />
  )
}
