import type { ReactNode } from 'react'
import { cn } from '@figma/astraui'

const STYLES = {
  1: 'text-title font-semibold tracking-display',
  2: 'text-heading font-semibold',
  3: 'text-label font-semibold',
} as const

export default function Heading({ level = 2, children, className, id }: { level?: 1 | 2 | 3; children: ReactNode; className?: string; id?: string }) {
  return (
    <div role="heading" aria-level={level} id={id} className={cn(STYLES[level], 'text-text-primary', className)}>
      {children}
    </div>
  )
}
