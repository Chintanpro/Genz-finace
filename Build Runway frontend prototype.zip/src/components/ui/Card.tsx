import type { ReactNode } from 'react'
import { cn } from '@figma/astraui'
import Heading from './Heading'

export default function Card({ title, action, children, className, subtitle }: { title?: string; subtitle?: string; action?: ReactNode; children: ReactNode; className?: string }) {
  return (
    <section className={cn('flex flex-col gap-lg rounded-corner-lg bg-surface-bg p-xl', className)}>
      {(title || action) && (
        <div className="flex items-start justify-between gap-md">
          <div className="flex min-w-0 flex-col gap-xs">
            {title && <Heading level={3}>{title}</Heading>}
            {subtitle && <p className="text-label-sm text-text-secondary">{subtitle}</p>}
          </div>
          {action}
        </div>
      )}
      {children}
    </section>
  )
}
