import type { ReactNode } from 'react'
import { Modal } from '@figma/astraui'

/** Every sheet uses Astra's Modal: focus handling, Escape to close, scrim. */
export default function Sheet({ open, onClose, title, children, footer, size = 'medium' }: {
  open: boolean; onClose: () => void; title: string; children: ReactNode; footer?: ReactNode; size?: 'small' | 'medium' | 'large'
}) {
  return (
    <Modal isOpen={open} onClose={onClose} title={title} footer={footer} size={size}>
      <div className="flex max-h-[70vh] flex-col gap-lg overflow-y-auto">{children}</div>
    </Modal>
  )
}
