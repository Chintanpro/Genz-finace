import type { ButtonHTMLAttributes } from 'react'
import { cn } from '@figma/astraui'

/**
 * Unstyled tappable surface for custom shapes (Money Map segments, day cells,
 * list rows) that Astra's pill Button cannot express. Styling comes from tokens.
 */
export default function Pressable({ className, type = 'button', ...rest }: ButtonHTMLAttributes<HTMLButtonElement>) {
  return <button type={type} className={cn('cursor-pointer text-left disabled:cursor-not-allowed disabled:opacity-50', className)} {...rest} />
}
