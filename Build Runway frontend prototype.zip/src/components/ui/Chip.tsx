import type { ReactNode } from 'react'
import { cn } from '@figma/astraui'
import Pressable from './Pressable'

export default function Chip({ selected, onClick, children, className, label }: { selected?: boolean; onClick: () => void; children: ReactNode; className?: string; label?: string }) {
  return (
    <Pressable
      aria-pressed={selected}
      aria-label={label}
      onClick={onClick}
      className={cn(
        'inline-flex min-h-touch shrink-0 items-center gap-xs rounded-corner-full px-lg text-label-sm font-medium transition-colors',
        selected ? 'border-2 border-border-selected bg-surface-bg text-text-primary' : 'border border-border-primary bg-surface-bg text-text-secondary hover:bg-surface-hover',
        className,
      )}
    >
      {children}
    </Pressable>
  )
}
