import type { ReactNode } from 'react'

export default function EmptyState({ icon, title, body, action }: { icon: ReactNode; title: string; body?: string; action?: ReactNode }) {
  return (
    <div className="flex flex-col items-center gap-md rounded-corner-lg bg-bg-faint p-2xl text-center">
      <span className="text-text-secondary">{icon}</span>
      <p className="text-label font-semibold text-text-primary">{title}</p>
      {body && <p className="max-w-sm text-label-sm text-text-secondary">{body}</p>}
      {action}
    </div>
  )
}
