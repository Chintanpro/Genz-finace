import type { Derived, SimulationResult } from '../types/finance'
import { formatPct } from '../lib/finance/format'
import { useRecentDelta } from '../hooks/useCountUp'
import Amount from './Amount'
import DeltaChip from './DeltaChip'
import ForecastFan from './ForecastFan'
import HealthRing from './HealthRing'
import ImpactGrid from './ImpactGrid'
import MoneyMap from './MoneyMap'
import RiskChip from './RiskChip'
import Heading from './ui/Heading'
import Pressable from './ui/Pressable'

function Big({ label, value, suffix }: { label: string; value: number; suffix?: string }) {
  const delta = useRecentDelta(value)
  return (
    <div className="flex flex-col gap-xs">
      <span className="text-label-sm text-text-secondary">{label}</span>
      <span className="flex flex-wrap items-center gap-sm">
        <Amount value={value} className="text-title font-semibold tracking-display text-text-primary" iconSize={20} />
        {suffix && <span className="text-label-sm text-text-secondary">{suffix}</span>}
        {delta !== 0 && <DeltaChip delta={delta} />}
      </span>
    </div>
  )
}

export default function ImpactPanel({ derived, sim, onHealth }: { derived: Derived; sim: SimulationResult | null; onHealth: () => void }) {
  return (
    <aside aria-label="Impact panel" className="sticky top-0 hidden h-screen w-panel shrink-0 flex-col gap-xl overflow-y-auto p-2xl pl-0 lg:flex">
      {sim ? (
        <div className="flex flex-col gap-lg rounded-corner-lg bg-surface-bg p-xl">
          <Heading level={3}>What moves</Heading>
          <ImpactGrid result={sim} />
          <div className="flex flex-col gap-sm">
            <span className="text-label-sm text-text-secondary">Money Map, now and after</span>
            <MoneyMap derived={sim.before} after={sim.after} compact />
          </div>
          <div className="flex flex-col gap-sm">
            <span className="text-label-sm text-text-secondary">Forecast, current solid and scenario dashed</span>
            <ForecastFan forecast={sim.before.forecast} scenario={sim.after.forecast} reserve={sim.before.reserve} />
          </div>
        </div>
      ) : (
        <div className="flex flex-col gap-xl rounded-corner-lg bg-surface-bg p-xl" aria-live="polite">
          <Big label="Balance" value={derived.wallet} />
          <Big label="Daily allowance" value={derived.dailyAllowance} suffix={`for ${derived.daysLeft} days`} />
          <MoneyMap derived={derived} compact />
          <div className="flex flex-col gap-xs">
            <span className="text-label-sm text-text-secondary">Month-end forecast</span>
            <ForecastFan forecast={derived.forecast} mini />
          </div>
          <Pressable onClick={onHealth} className="flex items-center justify-between gap-md rounded-corner-md bg-bg-faint p-lg" aria-label="Open Health">
            <span className="flex flex-col gap-xs">
              <RiskChip level={derived.risk.level} />
              <span className="text-video-title text-text-secondary">{formatPct(derived.forecast.pBelowZero)} chance of running out</span>
            </span>
            <span className="flex items-center gap-sm">
              <span className="text-label-sm text-text-secondary">{derived.health.band}</span>
              <HealthRing score={derived.health.score} band={derived.health.band} size="sm" />
            </span>
          </Pressable>
        </div>
      )}
    </aside>
  )
}
