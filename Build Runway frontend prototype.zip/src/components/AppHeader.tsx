import { Settings } from 'lucide-react'
import { IconButton, cn } from '@figma/astraui'
import { APP_NAME } from '../lib/finance/seed'

export default function AppHeader({ day, cycleDays, onSettings }: { day: number; cycleDays: number; onSettings: () => void }) {
  return (
    <header className="flex flex-col gap-sm bg-brand-tertiary px-xl pt-lg pb-sm lg:px-2xl">
      <div className="flex items-center justify-between gap-md">
        <div className="flex items-baseline gap-lg">
          <span className="text-heading font-semibold tracking-display text-text-primary">{APP_NAME}</span>
          <span className="tabular text-label-sm text-text-secondary">
            Day {Math.min(day, cycleDays)} of {cycleDays}
          </span>
        </div>
        <IconButton icon={<Settings size={20} strokeWidth={1.75} />} variant="subtle" aria-label="Settings and demo controls" onClick={onSettings} className="lg:hidden" />
      </div>
      <div className="flex gap-0.5" aria-hidden>
        {Array.from({ length: cycleDays }, (_, i) => (
          <span key={i} className={cn('h-0.5 flex-1 rounded-corner-full', i + 1 < day ? 'bg-text-primary' : i + 1 === day ? 'bg-money-free' : 'bg-border-primary')} />
        ))}
      </div>
    </header>
  )
}
