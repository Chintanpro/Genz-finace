import { Flag, Plus } from 'lucide-react'
import { cn } from '@figma/astraui'
import type { DayCell } from '../state/selectors'
import { formatINR } from '../lib/finance/format'
import Pressable from './ui/Pressable'

function describe(c: DayCell) {
  const bits = [`Day ${c.day}`]
  if (c.state !== 'future') bits.push(`spent ${formatINR(c.spend)}${c.over ? ', over pace' : ''}`)
  if (c.bills) bits.push('bill due')
  if (c.subs) bits.push('subscription renews')
  if (c.trial) bits.push('trial converts')
  if (c.goals) bits.push('goal transfer')
  if (c.income) bits.push('expected income')
  if (c.preview) bits.push('previewed decision')
  return bits.join(', ')
}

export default function MonthStrip({ cells, onDay }: { cells: DayCell[]; onDay: (d: number) => void }) {
  return (
    <div className="grid grid-cols-6 gap-xs lg:grid-cols-10" role="list" aria-label="Month strip, 30 days">
      {cells.map((c) => (
        <div role="listitem" key={c.day}>
          <Pressable
            onClick={() => onDay(c.day)}
            aria-label={describe(c)}
            className={cn(
              'relative flex h-14 w-full flex-col justify-between overflow-hidden rounded-corner-md p-xs',
              c.state === 'future' ? 'bg-bg-faint' : 'bg-bg-subtle',
              c.state === 'today' && 'outline-2 outline-border-selected',
              c.preview && 'preview-edge',
            )}
          >
            {c.state !== 'future' && (
              <span className={cn('absolute inset-x-0 bottom-0', c.over ? 'bg-money-danger' : 'bg-money-spent')} style={{ height: `${Math.round(c.fill * 100)}%` }} aria-hidden />
            )}
            <span className={cn('tabular relative text-video-title', c.state === 'today' ? 'font-semibold text-text-primary' : 'text-text-secondary')}>{c.day}</span>
            <span className="relative flex items-center gap-0.5" aria-hidden>
              {c.bills && <span className="size-2 rounded-corner-full bg-money-locked" />}
              {c.subs && <span className="size-2 rounded-corner-full border border-money-locked" />}
              {c.goals && <Plus size={10} strokeWidth={3} className="text-money-goals" />}
              {c.trial && <Flag size={10} strokeWidth={2.5} className="text-danger" />}
              {c.income && <span className="size-2 rounded-corner-full bg-money-free" />}
              {c.preview && <span className="size-2 rounded-corner-full bg-money-preview" />}
            </span>
          </Pressable>
        </div>
      ))}
    </div>
  )
}
