import { Bus, CircleDot, HandCoins, HeartPulse, Package, PartyPopper, PiggyBank, Receipt, Repeat, ShoppingBag, TriangleAlert, Utensils, Zap } from 'lucide-react'
import { Badge } from '@figma/astraui'
import type { Transaction } from '../types/finance'
import { formatINR } from '../lib/finance/format'
import { categoryLabel } from '../lib/finance/insights'
import Pressable from './ui/Pressable'

const CAT_ICON = { food: Utensils, transport: Bus, fun: PartyPopper, shopping: ShoppingBag, health: HeartPulse, other: Package }
const KIND_ICON = { income: HandCoins, bill: Receipt, subscription: Repeat, goal_transfer: PiggyBank, surprise: Zap, late_fee: TriangleAlert, expense: CircleDot }
const KIND_LABEL = { income: 'Income', bill: 'Bill', subscription: 'Subscription', goal_transfer: 'Goal transfer', surprise: 'Surprise', late_fee: 'Late fee', expense: 'Expense' }

export default function TransactionRow({ tx, onOpen }: { tx: Transaction; onOpen: () => void }) {
  const Icon = tx.kind === 'expense' && tx.category ? CAT_ICON[tx.category] : KIND_ICON[tx.kind]
  const inflow = tx.kind === 'income'
  return (
    <Pressable onClick={onOpen} className="flex min-h-touch w-full items-center gap-lg rounded-corner-md px-sm py-md hover:bg-surface-hover">
      <span className="flex size-10 shrink-0 items-center justify-center rounded-corner-full bg-bg-subtle text-text-primary">
        <Icon size={20} strokeWidth={1.75} aria-hidden />
      </span>
      <span className="flex min-w-0 flex-1 flex-col gap-xs">
        <span className="truncate text-label-sm font-medium text-text-primary">{tx.label}</span>
        <span className="flex flex-wrap items-center gap-xs text-video-title text-text-secondary">
          {tx.kind === 'expense' && tx.category ? `${categoryLabel(tx.category)} · ${tx.necessity === 'want' ? 'Want' : 'Need'}` : KIND_LABEL[tx.kind]}
          {tx.auto && <Badge label="auto" variant="secondary" />}
          {tx.simulated && <Badge label="typical day" variant="secondary" />}
        </span>
      </span>
      <span className={`tabular text-label-sm font-semibold ${inflow ? 'text-text-primary' : 'text-text-primary'}`}>
        {inflow ? '+' : '−'}
        {formatINR(tx.amount)}
      </span>
    </Pressable>
  )
}
