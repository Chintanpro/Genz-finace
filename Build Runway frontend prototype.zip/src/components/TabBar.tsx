import { CarFront, Gauge, PiggyBank, Sun, Wallet } from 'lucide-react'
import { SidebarButton, SidebarNavigation, Tooltip, cn } from '@figma/astraui'
import { Settings } from 'lucide-react'
import type { TabId } from '../state/store'
import Pressable from './ui/Pressable'

export const TABS: { id: TabId; label: string; Icon: typeof Sun }[] = [
  { id: 'today', label: 'Today', Icon: Sun },
  { id: 'money', label: 'Money', Icon: Wallet },
  { id: 'drive', label: 'Test drive', Icon: CarFront },
  { id: 'goals', label: 'Goals', Icon: PiggyBank },
  { id: 'health', label: 'Health', Icon: Gauge },
]

const Dot = () => <span className="absolute top-1 right-1 size-2 rounded-corner-full bg-money-preview ring-2 ring-surface-bg" aria-hidden />

interface Props {
  tab: TabId
  dots: Set<TabId>
  onTab: (t: TabId) => void
  onSettings: () => void
}

export function Rail({ tab, dots, onTab, onSettings }: Props) {
  return (
    <SidebarNavigation
      className="sticky top-0 hidden h-screen lg:flex"
      footer={
        <Tooltip content="Settings" position="right">
          <SidebarButton aria-label="Settings and demo controls" icon={<Settings className="size-full" strokeWidth={1.5} />} onClick={onSettings} />
        </Tooltip>
      }
    >
      {TABS.map(({ id, label, Icon }) => (
        <Tooltip key={id} content={label} position="right">
          <span className="relative block">
            <SidebarButton
              aria-label={`${label}${dots.has(id) ? ', has updates' : ''}`}
              aria-current={tab === id ? 'page' : undefined}
              active={tab === id}
              onClick={() => onTab(id)}
              className={cn(id === 'drive' && tab !== id && 'bg-money-preview-fill')}
              icon={<Icon className="size-full" strokeWidth={1.5} />}
            />
            {dots.has(id) && <Dot />}
          </span>
        </Tooltip>
      ))}
    </SidebarNavigation>
  )
}

export default function TabBar({ tab, dots, onTab }: Omit<Props, 'onSettings'>) {
  return (
    <nav aria-label="Main" className="fixed inset-x-0 bottom-0 z-30 border-t border-border-primary bg-surface-bg pb-[env(safe-area-inset-bottom)] lg:hidden">
      <ul className="mx-auto flex max-w-main items-stretch justify-between px-sm">
        {TABS.map(({ id, label, Icon }) => {
          const active = tab === id
          const centre = id === 'drive'
          return (
            <li key={id} className="flex-1">
              <Pressable
                onClick={() => onTab(id)}
                aria-current={active ? 'page' : undefined}
                aria-label={`${label}${dots.has(id) ? ', has updates' : ''}`}
                className={cn('relative flex min-h-touch w-full flex-col items-center gap-xs py-sm text-video-title', active ? 'text-text-primary' : 'text-text-secondary')}
              >
                <span className={cn('relative flex items-center justify-center rounded-corner-full', centre ? 'size-10 bg-text-primary text-surface-bg' : 'size-6', centre && active && 'outline-2 outline-offset-2 outline-money-preview')}>
                  <Icon size={centre ? 22 : 20} strokeWidth={1.75} aria-hidden />
                  {dots.has(id) && <Dot />}
                </span>
                <span className={cn(active && 'font-semibold')}>{label}</span>
              </Pressable>
            </li>
          )
        })}
      </ul>
    </nav>
  )
}
