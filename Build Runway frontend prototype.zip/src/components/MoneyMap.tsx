import { motion } from 'motion/react'
import { cn } from '@figma/astraui'
import type { Derived, SegmentKey } from '../types/finance'
import { formatINR } from '../lib/finance/format'
import { useReducedMotion } from '../hooks/useReducedMotion'
import Pressable from './ui/Pressable'

export const SEGMENT_STYLE: Record<SegmentKey, { fill: string; text: string }> = {
  spent: { fill: 'bg-money-spent', text: 'text-text-primary' },
  paidBills: { fill: 'bg-money-paid', text: 'text-on-reverse' },
  saved: { fill: 'bg-money-goals', text: 'text-on-money' },
  locked: { fill: 'bg-money-locked', text: 'text-on-brand' },
  reserve: { fill: 'bg-hatch', text: 'text-text-primary' },
  free: { fill: 'bg-money-free', text: 'text-on-money' },
}

interface Props {
  derived: Derived
  after?: Derived | null
  onSegment?: (key: SegmentKey) => void
  compact?: boolean
}

export default function MoneyMap({ derived, after, onSegment, compact }: Props) {
  const reduced = useReducedMotion()
  const spring = reduced ? { duration: 0.12 } : { type: 'spring' as const, stiffness: 260, damping: 30, duration: 0.48 }
  const short = Math.max(0, -derived.freeToSpend)
  const total = derived.moneyTotal + short
  const summary = derived.moneyMap.map((s) => `${s.label} ${formatINR(s.amount)}`).join(', ')
  const visible = derived.moneyMap.filter((s) => s.amount > 0)
  return (
    <div className="flex flex-col gap-md">
      <div
        role="group"
        aria-label={`Money Map of ${formatINR(derived.moneyTotal)}: ${summary}${short ? `, short by ${formatINR(short)}` : ''}`}
        className={cn('flex w-full gap-0.5 overflow-hidden rounded-corner-lg bg-brand-tertiary', compact ? 'h-14' : 'h-24 lg:h-30')}
      >
        {visible.map((s) => {
          const share = s.amount / Math.max(1, total)
          const st = SEGMENT_STYLE[s.key]
          return (
            <motion.div key={s.key} layout initial={false} animate={{ flexGrow: s.amount }} transition={spring} className="min-w-1 basis-0">
              <Pressable
                disabled={!onSegment}
                onClick={() => onSegment?.(s.key)}
                aria-label={`${s.label}: ${formatINR(s.amount)}. Open details`}
                className={cn('flex size-full flex-col justify-end overflow-hidden p-md disabled:opacity-100', st.fill, st.text, s.key === 'free' && 'ring-inset hover:ring-2 hover:ring-border-selected')}
              >
                {!compact && share > 0.13 && (
                  <>
                    <span className="tabular truncate text-label font-semibold">{formatINR(s.amount)}</span>
                    <span className="truncate text-video-title">{s.label}</span>
                  </>
                )}
              </Pressable>
            </motion.div>
          )
        })}
        {short > 0 && (
          <motion.div layout animate={{ flexGrow: short }} transition={spring} className="min-w-8 basis-0">
            <Pressable onClick={() => onSegment?.('free')} className="flex size-full flex-col justify-end bg-money-danger p-md text-on-brand" aria-label={`Short by ${formatINR(short)}`}>
              {!compact && <span className="truncate text-label-sm font-semibold">Short by {formatINR(short)}</span>}
            </Pressable>
          </motion.div>
        )}
      </div>
      {after && (
        <motion.div initial={reduced ? { opacity: 0 } : { y: -8, opacity: 0 }} animate={{ y: 0, opacity: 1 }} transition={{ duration: reduced ? 0.12 : 0.28 }} className="flex flex-col gap-xs">
          <span className="text-video-title text-text-secondary">After this decision</span>
          <div className="preview-edge flex h-8 w-full gap-0.5 overflow-hidden rounded-corner-md p-0.5" aria-label={`After: ${after.moneyMap.map((s) => `${s.label} ${formatINR(s.amount)}`).join(', ')}`}>
            {after.moneyMap.filter((s) => s.amount > 0).map((s) => (
              <motion.div key={s.key} layout initial={false} animate={{ flexGrow: s.amount }} transition={spring} className={cn('min-w-1 basis-0 rounded-corner-sm', SEGMENT_STYLE[s.key].fill)} />
            ))}
            {after.freeToSpend < 0 && <motion.div animate={{ flexGrow: -after.freeToSpend }} className="min-w-2 basis-0 rounded-corner-sm bg-money-danger" />}
          </div>
        </motion.div>
      )}
      {!compact && (
        <ul className="flex flex-wrap gap-x-lg gap-y-sm" aria-hidden>
          {derived.moneyMap.map((s) => (
            <li key={s.key} className="flex items-center gap-xs text-video-title text-text-secondary">
              <span className={cn('size-3 rounded-corner-sm', SEGMENT_STYLE[s.key].fill)} />
              {s.label} <span className="tabular font-semibold text-text-primary">{formatINR(s.amount)}</span>
            </li>
          ))}
        </ul>
      )}
      <table className="sr-only">
        <caption>Money Map</caption>
        <tbody>
          {derived.moneyMap.map((s) => (
            <tr key={s.key}>
              <th scope="row">{s.label}</th>
              <td>{formatINR(s.amount)}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}
