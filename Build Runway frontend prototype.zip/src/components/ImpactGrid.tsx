import type { HealthPart, SimulationResult } from '../types/finance'
import { formatINR, formatPct, weeksLabel } from '../lib/finance/format'
import { HEALTH_LABELS } from '../lib/finance/health'
import DeltaChip from './DeltaChip'
import ForecastFan from './ForecastFan'
import ImpactRow from './ImpactRow'
import RiskChip, { riskLabel } from './RiskChip'

const STATUS: Record<string, string> = { on_track: 'On track', behind: 'Behind', off_track: 'Off track', paused: 'Paused', done: 'Done' }

export default function ImpactGrid({ result, preview = true }: { result: SimulationResult; preview?: boolean }) {
  const { before: b, after: a } = result
  const slips = result.goalSlips.filter((s) => s.days > 0)
  const riskDelta = a.forecast.pBelowZero - b.forecast.pBelowZero
  const moved = (Object.keys(a.health.parts) as HealthPart[]).filter((k) => a.health.parts[k] !== b.health.parts[k])
  const days = result.costInAllowanceDays
  return (
    <div aria-live="polite" className="flex flex-col">
      <ImpactRow
        preview={preview}
        title="Balance"
        now={formatINR(b.freeToSpend)}
        after={formatINR(a.freeToSpend)}
        chip={<DeltaChip delta={a.freeToSpend - b.freeToSpend} />}
        line={result.outsideCycle ? 'Outside this cycle, so nothing moves now.' : 'Free to spend after everything locked in and your reserve.'}
      >
        <p className="text-label-sm text-text-secondary">Wallet today {formatINR(b.wallet)} to {formatINR(a.wallet)}. Locked in ahead {formatINR(b.locked.total)} to {formatINR(a.locked.total)}.</p>
      </ImpactRow>
      <ImpactRow
        preview={preview}
        title="Daily allowance"
        now={`${formatINR(b.dailyAllowance)} a day`}
        after={`${formatINR(a.dailyAllowance)} a day`}
        chip={<DeltaChip delta={a.dailyAllowance - b.dailyAllowance} />}
        line={days > 0 && Number.isFinite(days) ? `Costs about ${days.toFixed(1)} ${result.outsideCycle ? 'next-cycle ' : ''}allowance-days.` : 'No direct cost in allowance-days.'}
      />
      <ImpactRow
        preview={preview}
        title="Goals"
        now={`${b.goals.filter((g) => g.status === 'on_track' || g.status === 'done').length} on track`}
        after={`${a.goals.filter((g) => g.status === 'on_track' || g.status === 'done').length} on track`}
        chip={<DeltaChip delta={-slips.length} unit="points" />}
        line={slips.length ? `${slips.length} goal${slips.length === 1 ? '' : 's'} slip.` : 'No goals move later.'}
      >
        {a.goals.map((g) => {
          const before = b.goals.find((x) => x.id === g.id)
          const slip = result.goalSlips.find((s) => s.goalId === g.id)?.days ?? 0
          return (
            <div key={g.id} className="flex items-center justify-between gap-md text-label-sm">
              <span className="text-text-primary">{g.name}</span>
              <span className="flex items-center gap-sm text-text-secondary">
                {STATUS[before?.status ?? g.status]} to {STATUS[g.status]}, {weeksLabel(g.etaDay === null ? null : g.etaDay - (31 - a.daysLeft))}
                {slip !== 0 && <DeltaChip delta={slip} unit="days" higherIsBetter={false} />}
              </span>
            </div>
          )
        })}
      </ImpactRow>
      <ImpactRow
        preview={preview}
        title="Month-end forecast"
        now={formatINR(b.forecast.p50)}
        after={formatINR(a.forecast.p50)}
        chip={<DeltaChip delta={a.forecast.p50 - b.forecast.p50} />}
        line={`Likely range ${formatINR(a.forecast.p10)} to ${formatINR(a.forecast.p90)}.`}
      >
        <ForecastFan forecast={b.forecast} scenario={a.forecast} mini />
      </ImpactRow>
      <ImpactRow
        preview={preview}
        title="Risk"
        now={riskLabel(b.risk.level)}
        after={riskLabel(a.risk.level)}
        chip={<DeltaChip delta={riskDelta * 100} unit="pct" higherIsBetter={false} />}
        line={`In about ${formatPct(a.forecast.pBelowZero)} of simulated months you run out before Day 30.`}
      >
        <div className="flex items-center gap-sm">
          <RiskChip level={b.risk.level} />
          <span className="text-label-sm text-text-secondary">to</span>
          <RiskChip level={a.risk.level} />
        </div>
        {a.forecast.expectedZeroDay && <p className="text-label-sm text-text-secondary">When it happens, it is usually around Day {a.forecast.expectedZeroDay}.</p>}
      </ImpactRow>
      <ImpactRow
        preview={preview}
        title="Health"
        now={`${b.health.score}, ${b.health.band}`}
        after={`${a.health.score}, ${a.health.band}`}
        chip={<DeltaChip delta={a.health.score - b.health.score} unit="points" />}
        line={moved.length ? `Moved: ${moved.map((k) => HEALTH_LABELS[k].label.toLowerCase()).join(', ')}.` : 'No sub-scores move.'}
      >
        {moved.map((k) => (
          <div key={k} className="flex items-center justify-between text-label-sm">
            <span className="text-text-primary">{HEALTH_LABELS[k].label}</span>
            <span className="flex items-center gap-sm tabular text-text-secondary">
              {b.health.parts[k]} to {a.health.parts[k]}
              <DeltaChip delta={a.health.parts[k] - b.health.parts[k]} unit="points" />
            </span>
          </div>
        ))}
      </ImpactRow>
    </div>
  )
}
