import { CircleCheck, CircleHelp, OctagonX, Wrench } from 'lucide-react'
import { cn } from '@figma/astraui'
import type { VerdictLevel } from '../types/finance'

const MAP = {
  go: { cls: 'bg-money-goals text-on-money', Icon: CircleCheck },
  tweak: { cls: 'bg-money-free text-on-money', Icon: Wrench },
  think: { cls: 'bg-risk-high text-on-money', Icon: CircleHelp },
  nope: { cls: 'bg-money-danger text-on-brand', Icon: OctagonX },
} as const

export function VerdictChip({ level }: { level: VerdictLevel }) {
  const { cls, Icon } = MAP[level]
  const label = { go: 'Go', tweak: 'Tweak', think: 'Think', nope: 'Not now' }[level]
  return (
    <span className={cn('inline-flex items-center gap-xs rounded-corner-full px-md py-xs text-label-sm font-semibold', cls)}>
      <Icon size={14} aria-hidden /> {label}
    </span>
  )
}

export default function VerdictBanner({ level, headline, reason }: { level: VerdictLevel; headline: string; reason: string }) {
  const { cls, Icon } = MAP[level]
  return (
    <div role="status" className={cn('flex items-start gap-lg rounded-corner-lg p-xl', cls)}>
      <Icon size={24} strokeWidth={1.75} aria-hidden className="mt-0.5 shrink-0" />
      <div className="flex flex-col gap-xs">
        <span className="text-heading font-semibold">{headline}</span>
        <span className="text-label">{reason}</span>
      </div>
    </div>
  )
}
