import { cn } from '@figma/astraui'
import type { Derived } from '../types/finance'
import { formatINR } from '../lib/finance/format'
import { useRecentDelta } from '../hooks/useCountUp'
import Amount from './Amount'
import DeltaChip from './DeltaChip'
import RiskChip from './RiskChip'

function Metric({ label, value, after, suffix = '' }: { label: string; value: number; after?: number; suffix?: string }) {
  const delta = useRecentDelta(value)
  return (
    <div className="flex min-w-0 flex-col gap-xs">
      <span className="text-video-title text-text-secondary">{label}</span>
      <span className="flex flex-wrap items-center gap-xs text-label font-semibold text-text-primary">
        <Amount value={value} />
        {suffix && <span className="text-video-title font-normal text-text-secondary">{suffix}</span>}
        {after !== undefined && Math.round(after) !== Math.round(value) && (
          <span className="preview-edge tabular rounded-corner-sm px-xs text-label-sm">{formatINR(after)}</span>
        )}
        {delta !== 0 && after === undefined && <DeltaChip delta={delta} />}
      </span>
    </div>
  )
}

export default function ImpactRibbon({ derived, after }: { derived: Derived; after?: Derived | null }) {
  return (
    <div aria-live="polite" className={cn('sticky top-0 z-20 flex items-center justify-between gap-md bg-surface-bg px-xl py-md lg:hidden')}>
      <Metric label="Balance" value={derived.wallet} after={after?.wallet} />
      <Metric label="Daily allowance" value={derived.dailyAllowance} after={after?.dailyAllowance} />
      <div className="flex flex-col items-end gap-xs">
        <span className="text-video-title text-text-secondary">Risk</span>
        <span className="flex items-center gap-xs">
          <RiskChip level={derived.risk.level} />
          {after && after.risk.level !== derived.risk.level && <RiskChip level={after.risk.level} preview />}
        </span>
      </div>
    </div>
  )
}
