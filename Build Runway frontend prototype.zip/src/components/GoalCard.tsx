import { Badge } from '@figma/astraui'
import type { GoalStatus } from '../types/finance'
import { formatINR, weeksLabel } from '../lib/finance/format'
import HealthRing from './HealthRing'
import Pressable from './ui/Pressable'

export const GOAL_STATUS = {
  on_track: { label: 'On track', variant: 'success' },
  behind: { label: 'Behind', variant: 'warning' },
  off_track: { label: 'Off track', variant: 'danger' },
  paused: { label: 'Paused', variant: 'secondary' },
  done: { label: 'Done', variant: 'success' },
} as const

export default function GoalCard({ goal, currentDay, onOpen, priority }: { goal: GoalStatus; currentDay: number; onOpen: () => void; priority: number }) {
  const pct = Math.round((goal.saved / Math.max(1, goal.target)) * 100)
  const st = GOAL_STATUS[goal.status]
  return (
    <Pressable onClick={onOpen} className="flex w-full items-center gap-lg rounded-corner-lg bg-surface-bg p-xl hover:bg-surface-hover" aria-label={`${goal.name}, ${pct}% saved, ${st.label}. Open details`}>
      <HealthRing score={pct} size="md" />
      <span className="flex min-w-0 flex-1 flex-col gap-xs">
        <span className="flex flex-wrap items-center gap-sm">
          <span className="text-label font-semibold text-text-primary">{goal.name}</span>
          <Badge label={st.label} variant={st.variant} />
        </span>
        <span className="tabular text-label-sm text-text-secondary">
          {formatINR(goal.saved)} of {formatINR(goal.target)} · {formatINR(goal.weekly)} a week
        </span>
        <span className="text-video-title text-text-secondary">
          Priority {priority} · ETA {goal.status === 'paused' ? 'on hold' : weeksLabel(goal.etaDay === null ? null : goal.etaDay - currentDay)}
        </span>
      </span>
    </Pressable>
  )
}
