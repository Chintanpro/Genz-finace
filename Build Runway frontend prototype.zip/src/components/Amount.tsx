import { CircleMinus } from 'lucide-react'
import { cn } from '@figma/astraui'
import { useCountUp } from '../hooks/useCountUp'
import { formatINR } from '../lib/finance/format'

/** Rupee value with tween; negatives get a minus, the danger colour and an icon. */
export default function Amount({ value, className, tween = true, iconSize = 16 }: { value: number; className?: string; tween?: boolean; iconSize?: number }) {
  const v = useCountUp(value)
  const shown = tween ? v : value
  const neg = Math.round(value) < 0
  return (
    <span className={cn('tabular inline-flex items-center gap-xs', neg && 'text-danger', className)}>
      {neg && <CircleMinus size={iconSize} aria-hidden />}
      <span aria-label={formatINR(value).replace('−', 'minus ')}>{formatINR(shown)}</span>
    </span>
  )
}
