import { Eye, OctagonAlert, ShieldCheck, TriangleAlert } from 'lucide-react'
import { cn } from '@figma/astraui'
import type { RiskLevel } from '../types/finance'

const MAP = {
  low: { label: 'Low', cls: 'bg-risk-low text-on-money', Icon: ShieldCheck },
  watch: { label: 'Watch', cls: 'bg-risk-watch text-on-money', Icon: Eye },
  high: { label: 'High', cls: 'bg-risk-high text-on-money', Icon: TriangleAlert },
  critical: { label: 'Critical', cls: 'bg-risk-critical text-on-brand', Icon: OctagonAlert },
} as const

export const riskLabel = (l: RiskLevel) => MAP[l].label

export default function RiskChip({ level, preview, className }: { level: RiskLevel; preview?: boolean; className?: string }) {
  const { label, cls, Icon } = MAP[level]
  return (
    <span className={cn('inline-flex items-center gap-xs rounded-corner-full px-md py-xs text-label-sm font-semibold', preview ? 'preview-edge text-text-primary' : cls, className)}>
      <Icon size={14} strokeWidth={2} aria-hidden />
      <span>
        <span className="sr-only">Risk </span>
        {label}
      </span>
    </span>
  )
}
