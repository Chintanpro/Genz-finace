import { FlaskConical } from 'lucide-react'
import { Button } from '@figma/astraui'

export default function PreviewBanner({ onCancel, outside }: { onCancel: () => void; outside?: boolean }) {
  return (
    <div className="preview-edge flex items-center justify-between gap-md rounded-corner-lg px-xl py-md" role="note">
      <span className="flex items-center gap-sm text-label-sm font-medium text-text-primary">
        <FlaskConical size={18} aria-hidden />
        {outside ? 'Previewing. Outside this cycle.' : 'Previewing. Nothing is saved until you commit.'}
      </span>
      <Button variant="subtle" size="small" onClick={onCancel}>
        Cancel
      </Button>
    </div>
  )
}
