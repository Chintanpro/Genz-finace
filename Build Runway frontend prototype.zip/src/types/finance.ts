export type RiskLevel = 'low' | 'watch' | 'high' | 'critical'
export type Category = 'food' | 'transport' | 'fun' | 'shopping' | 'health' | 'other'
export type TxKind = 'expense' | 'income' | 'bill' | 'subscription' | 'goal_transfer' | 'surprise' | 'late_fee'

export interface Transaction {
  id: string
  day: number
  label: string
  kind: TxKind
  amount: number
  category?: Category
  necessity?: 'need' | 'want'
  sourceId?: string
  auto?: boolean
  simulated?: boolean
  /** One-off purchase from Test drive: excluded from the daily habit baseline. */
  oneOff?: boolean
}

export interface Commitment {
  id: string
  name: string
  amount: number
  dueDay: number
  status: 'paid' | 'upcoming' | 'failed' | 'deferred'
  flexible?: boolean
  lateFee: number
}

export interface Subscription {
  id: string
  name: string
  amount: number
  renewDay: number
  status: 'active' | 'trial' | 'cancelled' | 'paused'
  usage: 'high' | 'medium' | 'low'
  note?: string
}

export interface Goal {
  id: string
  name: string
  target: number
  savedBeforeCycle: number
  weekly: number
  deadlineDay: number
  priority: 1 | 2 | 3
  paused: boolean
}

export interface Income {
  id: string
  name: string
  amount: number
  day: number
  status: 'received' | 'expected'
  confidence: number
  countInBaseline: boolean
}

export interface Settings {
  budget: number
  cycleDays: number
  currentDay: number
  reserve: number
  categorySplit: Record<Category, number>
  theme: 'light' | 'dark' | 'system'
  surprises: boolean
}

/** A spending cut on a category (or all wants) for a range of days. */
export interface Cut {
  id: string
  category: Category | 'wants'
  percent: number
  fromDay: number
  toDay: number
}

export type Decision =
  | { kind: 'purchase'; label: string; amount: number; day: number; category: Category; necessity: 'need' | 'want'; payment: 'now' | 'pay_later_3' }
  | { kind: 'subscription_add'; name: string; amount: number; startDay: number; trialDays: number }
  | { kind: 'subscription_cancel'; subId: string }
  | { kind: 'goal_adjust'; goalId: string; weekly: number; paused: boolean }
  | { kind: 'surprise'; label: string; amount: number; day: number }
  | { kind: 'income'; amount: number; day: number; confidence: number }
  | { kind: 'lifestyle_cut'; category: Category | 'wants'; percent: number; days?: number }
  | { kind: 'goal_withdraw'; goalId: string; amount: number }
  | { kind: 'goal_add_money'; goalId: string; amount: number }
  | { kind: 'commitment_defer'; commitmentId: string; days: number }
  | { kind: 'combo'; label: string; parts: Decision[] }

export interface Snapshot {
  wallet: number
  dailyAllowance: number
  closingP50: number
  riskLevel: RiskLevel
  pBelowZero: number
  healthScore: number
  goalEtas: Record<string, number>
}

export interface LogEntry {
  id: string
  decision: Decision
  day: number
  before: Snapshot
  after: Snapshot
}

export interface AppState {
  settings: Settings
  transactions: Transaction[]
  commitments: Commitment[]
  subscriptions: Subscription[]
  goals: Goal[]
  incomes: Income[]
  cuts: Cut[]
  decisionLog: LogEntry[]
}

export type SegmentKey = 'spent' | 'paidBills' | 'saved' | 'locked' | 'reserve' | 'free'
export interface Segment {
  key: SegmentKey
  label: string
  amount: number
}

export type GoalStatusKind = 'on_track' | 'behind' | 'off_track' | 'paused' | 'done'
export interface GoalStatus {
  id: string
  name: string
  saved: number
  target: number
  weekly: number
  requiredWeekly: number
  status: GoalStatusKind
  etaDay: number | null
  schedule: { day: number; state: 'paid' | 'scheduled' | 'skipped' }[]
}

export type HealthPart = 'runway' | 'discipline' | 'commitment_load' | 'savings_momentum' | 'risk_resilience' | 'consistency'

export interface Insight {
  id: string
  tone: 'warn' | 'win' | 'tip'
  severity: number
  headline: string
  detail: string
  preset?: Decision
}

export interface ForecastPoint {
  day: number
  p10: number
  p50: number
  p90: number
}

export interface Forecast {
  p10: number
  p50: number
  p90: number
  pBelowZero: number
  pBelowReserve: number
  expectedZeroDay?: number
  path: ForecastPoint[]
}

export interface Derived {
  wallet: number
  spentToday: number
  daysLeft: number
  dayStartAllowance: number
  dailyAllowance: number
  leftToday: number
  locked: { commitments: number; subscriptions: number; goals: number; planned: number; total: number }
  reserve: number
  freeToSpend: number
  moneyMap: Segment[]
  moneyTotal: number
  expectedDaily: number
  discretionaryPool: number
  categoryPace: Record<Category, { budget: number; pace: number; spent: number }>
  forecast: Forecast
  risk: { level: RiskLevel; index: number }
  goals: GoalStatus[]
  health: { score: number; band: string; parts: Record<HealthPart, number> }
  maxAbsorbable: number
  insights: Insight[]
  wantsShare: number
  subscriptionCycleTotal: number
  commitmentCycleTotal: number
  dailySpend: number[]
}

export type VerdictLevel = 'go' | 'tweak' | 'think' | 'nope'

export interface Alternative {
  label: string
  decision: Decision
  after: Derived
  verdictLevel: VerdictLevel
}

export interface SimulationResult {
  before: Derived
  after: Derived
  verdict: { level: VerdictLevel; headline: string; reason: string }
  costInAllowanceDays: number
  outsideCycle: boolean
  goalSlips: { goalId: string; days: number }[]
  alternatives: Alternative[]
  tip?: string
}
